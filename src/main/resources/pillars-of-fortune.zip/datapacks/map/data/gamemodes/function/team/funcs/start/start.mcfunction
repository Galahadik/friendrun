execute if score #teams.teams_count settings matches 1 run function gamemodes:team/choose_teams_count/random

tag @a remove have_team
tag @a remove not_have_team

fill -25 150 24 24 -64 -25 air
gamerule mob_drops false
execute as @e[type=minecraft:slime] at @s run data merge entity @s {Size:0}
execute as @e[type=minecraft:magma_cube] at @s run data merge entity @s {Size:0}
kill @e[type=!player,tag=!lobby]
kill @e[type=!player,tag=!lobby]
gamerule mob_drops true

data merge storage minecraft:map {pre_start:true}

function gamemodes:team/funcs/teams_count


execute if data storage minecraft:settings {gamemodes:{params:{assign_teams_method:"random"}}} run return run function gamemodes:team/funcs/start/random_players_in_teams/start

title @a times 0 35s 0
title @a title ""

scoreboard players set $teams.select timer 0
scoreboard players set $teams.select.sec timer 30
function gamemodes:team/funcs/start/tick

execute as @a[tag=not_have_team] run function gamemodes:team/choose_team/select
