scoreboard players reset @s teams.join_random
scoreboard players reset @s teams.join_alpha
scoreboard players reset @s teams.join_beta
scoreboard players reset @s teams.join_gamma
scoreboard players reset @s teams.join_delta
scoreboard players reset @s teams.join_omega

team join Beta @s
tag @s remove not_have_team
tag @s add have_team
tellraw @s [{text:"Вы присоеденились к команде ",color:"aqua"},{text:"\"Бета\"",color:red}]
execute at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.75
function gamemodes:team/funcs/teams_count

execute as @a[tag=not_have_team] run function gamemodes:team/choose_team/select
function gamemodes:team/funcs/leave