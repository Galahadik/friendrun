scoreboard players reset @s teams.join_cant
execute at @s run playsound entity.villager.no hostile @s ~ ~ ~ 0.5