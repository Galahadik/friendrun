tag @a add not_have_team

scoreboard players set $pre_start timer 15

title @a title ""
title @a subtitle [{text:"Игра начнется через ",color:green},{text:"15",bold:true,italic:true}," секунд..."]

tellraw @a[tag=Admin] ["\n",{text:"[Нажмите чтобы остановить отсчет]",color:red,hover_event:{action:"show_text",value:{text:"Нажмите, чтобы остановить\n15-ти секундный отсчет перед\nначалом игры",color:red}},click_event:{action:"run_command",command:"/function gamemodes:team/choose_team/stop"}},"\n"]

function gamemodes:team/funcs/start/random_players_in_teams/timer