execute unless data storage minecraft:map {pre_start:true} run return fail

schedule clear gamemodes:team/funcs/start/tick
schedule clear gamemodes:team/funcs/start/random_players_in_teams/timer
title @a reset

execute as @a at @s run playsound minecraft:entity.villager.no hostile @s ~ ~ ~ 0.75
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{selector:"@s",color:blue},{text:" — Остановил выбор команд",color:red}]

tag @a remove not_have_team
tag @a remove have_team

team join lobby @a

data merge storage minecraft:map {all_select_team:false}

data merge storage minecraft:map {pre_start:false}

scoreboard players enable @a[tag=Admin] force_start.trigger
scoreboard players enable @a[tag=Mod] force_start.trigger

execute if data storage minecraft:map {teams_count:1} run scoreboard players set #teams.teams_count settings 1
execute if data storage minecraft:map {teams_count:1} run data merge storage minecraft:map {teams_count:0}