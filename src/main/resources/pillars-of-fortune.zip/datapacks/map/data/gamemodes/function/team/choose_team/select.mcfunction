tellraw @s "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
tellraw @s ["<",[{text:"          ",strikethrough:true},{text:"> Выберете Команду <",strikethrough:false},"          "],">"]
tellraw @s {text:"(Нажмите чтобы вступить в команду)",color:dark_gray}
execute if entity @s[tag=Admin] run tellraw @s ["   ",{text:"[Остановить подбор]",color:red,hover_event:{action:"show_text",value:{text:"Нажмите, чтобы остановить\nвыбор команд",color:red}},click_event:{action:"run_command",command:"/function gamemodes:team/choose_team/stop"}}]
function gamemodes:team/choose_team/team/random
function gamemodes:team/choose_team/team/alpha
function gamemodes:team/choose_team/team/beta
execute if score #teams.teams_count settings matches 3.. run function gamemodes:team/choose_team/team/gamma
execute if score #teams.teams_count settings matches 4.. run function gamemodes:team/choose_team/team/delta
execute if score #teams.teams_count settings matches 5.. run function gamemodes:team/choose_team/team/omega

tellraw @s ["\n<",{text:"                                                ",strikethrough:true},">"]