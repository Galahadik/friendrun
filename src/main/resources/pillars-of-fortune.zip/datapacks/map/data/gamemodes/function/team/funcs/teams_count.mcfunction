scoreboard players operation #teams.players_per_team .temp = #players_count settings

execute if score #teams.teams_count settings matches 2 run execute store result score #teams.players_per_team settings run scoreboard players operation #teams.players_per_team .temp /= 2 const
execute if score #teams.teams_count settings matches 3 run execute store result score #teams.players_per_team settings run scoreboard players operation #teams.players_per_team .temp /= 3 const
execute if score #teams.teams_count settings matches 4 run execute store result score #teams.players_per_team settings run scoreboard players operation #teams.players_per_team .temp /= 4 const
execute if score #teams.teams_count settings matches 5 run execute store result score #teams.players_per_team settings run scoreboard players operation #teams.players_per_team .temp /= 5 const

scoreboard players operation #teams.players_per_team.odd .temp = #players_count settings
scoreboard players operation #teams.players_per_team.odd .temp %= 2 const

execute unless score #teams.players_per_team.odd .temp matches 0 run scoreboard players operation #teams.players_per_team settings += 1 const



execute store result score #teams.random_count settings if entity @a[team=Random]
execute store result score #teams.alpha_count settings if entity @a[team=Alpha]
execute store result score #teams.beta_count settings if entity @a[team=Beta]
execute if score #teams.teams_count settings matches 3.. run execute store result score #teams.gamma_count settings if entity @a[team=Gamma]
execute if score #teams.teams_count settings matches 4.. run execute store result score #teams.delta_count settings if entity @a[team=Delta]
execute if score #teams.teams_count settings matches 5.. run execute store result score #teams.omega_count settings if entity @a[team=Omega]