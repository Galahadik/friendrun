scoreboard players add &pass_count .temp 1

execute store result score #teams.alpha_count settings if entity @a[team=Alpha]
execute if score #teams.alpha_count settings <= &pass_count .temp run execute as @r[team=Random] run function gamemodes:team/funcs/join/alpha

execute store result score #teams.beta_count settings if entity @a[team=Beta]
execute if score #teams.beta_count settings <= &pass_count .temp run execute as @r[team=Random] run function gamemodes:team/funcs/join/beta
execute if score #teams.teams_count settings = 2 const run return run function gamemodes:team/funcs/distribute_random_players/loop

execute store result score #teams.gamma_count settings if entity @a[team=Gamma]
execute if score #teams.gamma_count settings <= &pass_count .temp run execute as @r[team=Random] run function gamemodes:team/funcs/join/gamma
execute if score #teams.teams_count settings = 3 const run return run function gamemodes:team/funcs/distribute_random_players/loop

execute store result score #teams.delta_count settings if entity @a[team=Delta]
execute if score #teams.delta_count settings <= &pass_count .temp run execute as @r[team=Random] run function gamemodes:team/funcs/join/delta
execute if score #teams.teams_count settings = 4 const run return run function gamemodes:team/funcs/distribute_random_players/loop

execute store result score #teams.omega_count settings if entity @a[team=Omega]
execute if score #teams.omega_count settings <= &pass_count .temp run execute as @r[team=Random] run function gamemodes:team/funcs/join/omega
execute if score #teams.teams_count settings = 5 const run return run function gamemodes:team/funcs/distribute_random_players/loop