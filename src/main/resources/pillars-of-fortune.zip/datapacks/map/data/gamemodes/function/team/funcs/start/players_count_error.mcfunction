execute as @a at @s run playsound minecraft:entity.villager.no ambient @s ~ ~ ~

data merge storage minecraft:map {pre_start:false}
title @a reset

tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"Запуск игры был приостановлен т.к кол-во игроков неподходит для начала игры!",color:red}]]