execute as @a[tag=not_have_team] run function gamemodes:team/funcs/join/random

scoreboard players set &pass_count .temp -1
function gamemodes:team/funcs/distribute_random_players/loop

title @a reset

function admin:panel/show_panel

scoreboard players set $lobby_time_before_start timer 6
function cmd:map/lobby/start/check_conditions/countdown_before_start

scoreboard players reset @a teams.join_alpha
scoreboard players reset @a teams.join_beta
scoreboard players reset @a teams.join_gamma
scoreboard players reset @a teams.join_delta
scoreboard players reset @a teams.join_omega
scoreboard players reset @a teams.join_cant
scoreboard players reset @a teams.join_random
scoreboard players reset @a teams.leave

# team modify Alpha prefix [{text:"[",color:white},{text:"Альфа",color:dark_blue},"] "]
# team modify Beta prefix [{text:"[",color:white},{text:"Бета",color:dark_red},"] "]
# team modify Gamma prefix [{text:"[",color:white},{text:"Гамма",color:dark_green},"] "]
# team modify Delta prefix [{text:"[",color:white},{text:"Дельта",color:gold},"] "]
# team modify Omega prefix [{text:"[",color:white},{text:"Омега",color:dark_purple},"] "]

tag @a[team=Alpha] add team.alpha
tag @a[team=Beta] add team.beta
tag @a[team=Gamma] add team.gamma
tag @a[team=Delta] add team.delta
tag @a[team=Omega] add team.omega

tag @a remove have_team

data merge storage minecraft:map {all_select_team:false}

execute as @a at @s run playsound entity.player.levelup hostile @s ~ ~ ~ 0.8

execute unless entity @a[team=Random] run return run schedule function cmd:map/func/start 1s