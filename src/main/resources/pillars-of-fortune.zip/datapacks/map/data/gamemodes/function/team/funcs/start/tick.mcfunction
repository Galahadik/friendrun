scoreboard players enable @a teams.join_cant
scoreboard players enable @a[tag=not_have_team] teams.join_random
scoreboard players enable @a[tag=not_have_team] teams.join_alpha
scoreboard players enable @a[tag=not_have_team] teams.join_beta
execute if score #teams.teams_count settings matches 3.. run scoreboard players enable @a[tag=not_have_team] teams.join_gamma
execute if score #teams.teams_count settings matches 4.. run scoreboard players enable @a[tag=not_have_team] teams.join_delta
execute if score #teams.teams_count settings matches 5.. run scoreboard players enable @a[tag=not_have_team] teams.join_omega

execute as @a[scores={teams.join_cant=1..}] run function gamemodes:team/funcs/join/cant_join
execute as @a[scores={teams.join_random=1..}] run function gamemodes:team/funcs/join/random
execute as @a[scores={teams.join_alpha=1..}] run function gamemodes:team/funcs/join/alpha
execute as @a[scores={teams.join_beta=1..}] run function gamemodes:team/funcs/join/beta
execute as @a[scores={teams.join_gamma=1..}] run function gamemodes:team/funcs/join/gamma
execute as @a[scores={teams.join_delta=1..}] run function gamemodes:team/funcs/join/delta
execute as @a[scores={teams.join_omega=1..}] run function gamemodes:team/funcs/join/omega

execute as @a[scores={teams.leave=1..}] run function gamemodes:team/funcs/leave_team

execute unless score #players_count settings matches 2..30 run return run function gamemodes:team/funcs/start/players_count_error

scoreboard players add $teams.select timer 1
execute if score $teams.select timer matches 20.. run scoreboard players remove $teams.select.sec timer 1
execute if score $teams.select timer matches 20.. if score $teams.select.sec timer matches ..3 run execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.8
execute if score $teams.select timer matches 20.. run scoreboard players set $teams.select timer 0

execute if score $teams.select.sec timer matches 15..30 run title @a subtitle [{score:{name:"$teams.select.sec",objective:"timer"},color:"green"}]
execute if score $teams.select.sec timer matches 4..14 run title @a subtitle [{score:{name:"$teams.select.sec",objective:"timer"},color:"yellow"}]
execute if score $teams.select.sec timer matches ..3 run title @a subtitle [{score:{name:"$teams.select.sec",objective:"timer"},color:"red"}]


tag @a[tag=!have_team,tag=!not_have_team] add not_have_team

execute if data storage minecraft:map {all_select_team:false} unless entity @a[tag=not_have_team] unless score $teams.select.sec timer matches ..5 run function gamemodes:team/funcs/start/force_finish


execute if score $teams.select.sec timer matches ..0 run return run function gamemodes:team/funcs/start/stop
execute if score $teams.select.sec timer matches 1.. run schedule function gamemodes:team/funcs/start/tick 1t