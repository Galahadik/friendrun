data merge storage minecraft:map {all_select_team:true}

title @a title {text:"Команды выбраны!",color:red}
execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.8

scoreboard players set $teams.select.sec timer 5
scoreboard players set $teams.select timer 0
