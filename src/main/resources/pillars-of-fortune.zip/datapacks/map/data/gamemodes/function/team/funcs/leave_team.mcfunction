scoreboard players reset @s teams.leave
team join lobby @s
tag @s remove have_team
tag @s add not_have_team

function gamemodes:team/funcs/teams_count
execute as @a[tag=not_have_team] run function gamemodes:team/choose_team/select