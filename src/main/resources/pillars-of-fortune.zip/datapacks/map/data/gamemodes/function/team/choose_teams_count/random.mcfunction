execute if score #players_count settings matches 2..5 run scoreboard players set #teams.teams_count settings 2
execute if score #players_count settings matches 6..8 run function gamemodes:team/choose_teams_count/func {max_teams:3}
execute if score #players_count settings matches 9.. run function gamemodes:team/choose_teams_count/func {max_teams:5}

data merge storage minecraft:map {teams_count:1}