tellraw @s "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"

scoreboard players enable @s teams.leave

tellraw @s ["<",[{text:"          ",strikethrough:true},{text:"> Выберете Команду <",strikethrough:false},"          "],">\n"]

tellraw @s[team=Random] ["",{text:" ➥ ",color:gray,bold:true},{text:"Вы находитесь в команде ",color:"aqua"},{text:"\"Случайная\"",color:gold}]
tellraw @s[team=Alpha] ["",{text:" ➥ ",color:gray,bold:true},{text:"Вы находитесь в команде ",color:"aqua"},{text:"\"АЛЬФА\"",color:blue}]
tellraw @s[team=Beta] ["",{text:" ➥ ",color:gray,bold:true},{text:"Вы находитесь в команде ",color:"aqua"},{text:"\"Бета\"",color:red}]
tellraw @s[team=Gamma] ["",{text:" ➥ ",color:gray,bold:true},{text:"Вы находитесь в команде ",color:"aqua"},{text:"\"Гамма\"",color:green}]
tellraw @s[team=Delta] ["",{text:" ➥ ",color:gray,bold:true},{text:"Вы находитесь в команде ",color:"aqua"},{text:"\"Дельта\"",color:yellow}]
tellraw @s[team=Omega] ["",{text:" ➥ ",color:gray,bold:true},{text:"Вы находитесь в команде ",color:"aqua"},{text:"\"Омега\"",color:light_purple}]

execute if data storage settings {gamemodes:{params:{assign_teams_method:"choice"}}} run tellraw @s ["",{text:" ➥ ",color:gray,bold:true},{text:"[Выйти из команды]",color:red,click_event:{action:"run_command",command:"/trigger teams.leave"},hover_event:{action:"show_text",value:{text:"Нажмите, чтобы выйти из команды",color:red}}}]

tellraw @s ["\n<",{text:"                                                ",strikethrough:true},">"]