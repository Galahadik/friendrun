setblock 0 -58 0 dirt
setblock 0 -57 0 dirt
fill 0 -56 0 0 -47 0 air destroy
summon creeper 0 -50 0