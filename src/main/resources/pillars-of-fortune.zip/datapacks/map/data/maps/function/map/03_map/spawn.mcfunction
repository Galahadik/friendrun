place template maps:map_03 -16 -59 -16

summon minecraft:villager -9 -58 0 {VillagerData:{profession:"minecraft:toolsmith",level:2}}
summon minecraft:villager 9 -58 0 {VillagerData:{profession:"minecraft:armorer",level:2}}
summon minecraft:villager 0 -58 -9 {VillagerData:{profession:"minecraft:butcher",level:2}}
summon minecraft:villager 0 -58 9 {VillagerData:{profession:"minecraft:weaponsmith",level:2}}

fill -1 -57 0 1 -58 0 air replace minecraft:bedrock
fill 0 -57 1 0 -58 -1 air replace minecraft:bedrock

# LOOT
setblock 0 -58 0 chest{LootTable:"maps:map_3/chest_1"}