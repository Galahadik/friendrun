place template maps:map_06 -16 -61 -16

summon skeleton -9 -56 -7 {PersistenceRequired:1b,equipment:{feet:{id:"minecraft:netherite_boots"},legs:{id:"minecraft:netherite_leggings"},chest:{id:"minecraft:netherite_chestplate"},head:{id:"minecraft:netherite_helmet"},mainhand:{id:"minecraft:netherite_sword"},offhand:{id:"minecraft:shield"}},drop_chances:{feet:0,legs:0,chest:0,head:0,mainhand:0,offhand:0}}
summon minecraft:cave_spider -4 -51 -1 {PersistenceRequired:1b}

summon minecraft:chicken -8 -56.5 9
summon minecraft:chicken -8 -56.5 9
summon minecraft:chicken -8 -56.5 9
summon minecraft:chicken -8 -56.5 9

summon cow 3 -56 -5
summon cow 3 -56 -5

summon pig -4 -56.5 -13
summon pig -4 -56.5 -13
summon pig -4 -56.5 -13

summon minecraft:sheep 12 -56.5 -4