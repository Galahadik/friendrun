place template maps:map_01 -18 -59 -18

setblock 0 -57 0 minecraft:observer[facing=up,powered=false]
schedule function maps:map/01_map/func 3s append