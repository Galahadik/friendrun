setblock 0 -55 0 minecraft:crying_obsidian
setblock 0 -56 0 minecraft:barrel[facing=up]{Items:[{Slot:0b,count:1,id:"minecraft:totem_of_undying"},{Slot:2b,components:{"minecraft:custom_data":{Tags:["decor"]},"minecraft:lore":['""','{"color":"gray","italic":false,"text":"Фантомная."}','{"color":"gray","italic":false,"text":"Нельзя использовать."}','""']},count:1,id:"minecraft:cobweb"},{Slot:6b,components:{"minecraft:max_damage":20},count:1,id:"minecraft:iron_sword"},{Slot:7b,components:{"minecraft:custom_data":{Tags:["decor"]},"minecraft:lore":['""','{"color":"gray","italic":false,"text":"Фантомная."}','{"color":"gray","italic":false,"text":"Нельзя использовать."}','""']},count:1,id:"minecraft:cobweb"},{Slot:14b,count:1,id:"minecraft:wind_charge"},{Slot:17b,count:1,id:"minecraft:wind_charge"},{Slot:19b,components:{"minecraft:custom_data":{Tags:["decor"]},"minecraft:lore":['""','{"color":"gray","italic":false,"text":"Фантомная."}','{"color":"gray","italic":false,"text":"Нельзя использовать."}','""']},count:1,id:"minecraft:cobweb"},{Slot:21b,count:1,id:"minecraft:enchanted_golden_apple"},{Slot:22b,count:1,id:"minecraft:wind_charge"},{Slot:25b,components:{"minecraft:custom_data":{Tags:["decor"]},"minecraft:lore":['""','{"color":"gray","italic":false,"text":"Фантомная."}','{"color":"gray","italic":false,"text":"Нельзя использовать."}','""']},count:2,id:"minecraft:cobweb"}]}
setblock 38 104 -56 air

place template maps:map_02 -16 -59 -16

summon minecraft:strider 0 -54 -4 {equipment:{saddle:{id:"minecraft:saddle"}}}
summon minecraft:strider 0 -54 4 {equipment:{saddle:{id:"minecraft:saddle"}}}
summon minecraft:strider 4 -54 0 {equipment:{saddle:{id:"minecraft:saddle"}}}
