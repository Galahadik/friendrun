place template maps:map_07 -16 -59 -16
schedule function maps:map/07_map/func 3s