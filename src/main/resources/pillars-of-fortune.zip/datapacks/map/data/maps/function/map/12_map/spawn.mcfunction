place template maps:map_12 -17 -61 -17

summon minecraft:rabbit 1 -57 -6
summon minecraft:rabbit 1 -57 -6
summon minecraft:rabbit 1 -57 -6

summon minecraft:camel -8 -57 3 {equipment:{saddle:{id:"minecraft:saddle"}}}

summon minecraft:husk -1 -57 9 {equipment:{chest:{id:"minecraft:copper_chestplate"},feet:{id:"minecraft:copper_boots"},head:{id:"minecraft:copper_helmet"},legs:{id:"minecraft:copper_leggings"},mainhand:{id:wooden_axe}},PersistenceRequired:true}