execute store result score #random_map rng run random value 1..12

execute if data storage minecraft:settings {maps:{empty_maps:true}} unless data storage minecraft:temp {disable_empty:true} store result score #random_map rng run random value -1..12

execute if score #random_map rng matches -1..0 run return fail

execute if score #random_map rng matches 1 run return run function maps:map/01_map/spawn
execute if score #random_map rng matches 2 run return run function maps:map/02_map/spawn
execute if score #random_map rng matches 3 run return run function maps:map/03_map/spawn
execute if score #random_map rng matches 4 run return run function maps:map/04_map/spawn
execute if score #random_map rng matches 5 run return run function maps:map/05_map/spawn
execute if score #random_map rng matches 6 run return run function maps:map/06_map/spawn
execute if score #random_map rng matches 7 run return run function maps:map/07_map/spawn
execute if score #random_map rng matches 8 run return run function maps:map/08_map/spawn
execute if score #random_map rng matches 9 run return run function maps:map/09_map/spawn
execute if score #random_map rng matches 10 run return run function maps:map/10_map/spawn
execute if score #random_map rng matches 11 run return run function maps:map/11_map/spawn
execute if score #random_map rng matches 12 run return run function maps:map/12_map/spawn