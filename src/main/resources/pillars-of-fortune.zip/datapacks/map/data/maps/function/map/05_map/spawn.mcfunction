place template maps:map_05 -16 -59 -16

schedule function maps:map/05_map/func 3s append