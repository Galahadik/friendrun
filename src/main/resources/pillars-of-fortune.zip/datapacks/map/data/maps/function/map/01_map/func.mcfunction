fill 0 -51 0 0 -56 0 oak_log
fill -16 -52 0 -16 -56 0 oak_log
fill 0 -56 -16 0 -52 -16 oak_log
fill 16 -56 0 16 -53 0 oak_log
fill 0 -56 16 0 -53 16 oak_log

setblock 0 -58 0 minecraft:command_block{Command:"function maps:map/01_map/func2"}

summon bee -7 -55 -8
summon bee -6 -55 -5
summon bee -5 -55 -10
summon bee -4 -55 -8
summon bee -3 -55 -6
summon bee -2 -55 -9

summon frog 7 -56 -5 {variant:"warm"}
summon frog 5 -56 5 {variant:"cold"}

summon bogged 0 -56 1 {equipment:{head:{id:"minecraft:chainmail_helmet"}},PersistenceRequired:1b}