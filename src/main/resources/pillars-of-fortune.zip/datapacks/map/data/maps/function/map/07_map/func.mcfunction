setblock 7 -42 0 air destroy
setblock 0 -42 7 air destroy
setblock -7 -42 0 air destroy
setblock 0 -42 -7 air destroy

setblock 9 -50 0 air destroy
setblock 0 -50 9 air destroy
setblock -9 -50 0 air destroy
setblock 0 -50 -9 air destroy

setblock 11 -58 0 air destroy
setblock 0 -58 11 air destroy
setblock -11 -58 0 air destroy
setblock 0 -58 -11 air destroy

kill @e[type=minecraft:item,nbt={Item:{id:"minecraft:barrel"}}]