place template maps:map_04 -16 -59 -16

setblock -7 -58 1 minecraft:tnt[unstable=true]
setblock -7 -58 -1 minecraft:tnt[unstable=true]

setblock 7 -58 -1 minecraft:tnt[unstable=true]
setblock 7 -58 1 minecraft:tnt[unstable=true]

summon minecraft:husk 5 -55 5 {equipment:{feet:{id:"minecraft:golden_boots"},legs:{id:"minecraft:golden_leggings"},chest:{id:"minecraft:golden_chestplate"},head:{id:"minecraft:golden_helmet"}},PersistenceRequired:1b}
summon minecraft:husk -5 -55 -5 {equipment:{feet:{id:"minecraft:golden_boots"},legs:{id:"minecraft:golden_leggings"},chest:{id:"minecraft:golden_chestplate"},head:{id:"minecraft:golden_helmet"}},PersistenceRequired:1b}

summon minecraft:rabbit 2.0 -55 0
summon minecraft:rabbit 2.0 -55 0
summon minecraft:rabbit 2.0 -55 0
summon minecraft:rabbit 2.0 -55 0
summon minecraft:rabbit 2.0 -55 0

setblock 38 104 -60 air

# LOOT
setblock -8 -56 0 minecraft:trapped_chest[facing=east]{LootTable:"maps:map_4/chest_1_2"}
setblock 8 -56 0 minecraft:trapped_chest[facing=west]{LootTable:"maps:map_4/chest_1_2"}