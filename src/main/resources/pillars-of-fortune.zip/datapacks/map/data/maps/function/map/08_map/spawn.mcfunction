place template maps:map_08 -16 -59 -16

# overworld
summon minecraft:frog -4.0 -40.0 9 {variant:"warm"}
summon minecraft:frog -3 -40.0 8 {variant:"cold"}
summon minecraft:bee 0.50 -39.00 8.50
summon minecraft:bee 0.50 -39.00 8.50
summon minecraft:bee 0.50 -39.00 8.50
summon bogged -1 -39.5 9 {equipment:{head:{id:"minecraft:chainmail_helmet"}},PersistenceRequired:1b}

# Netherite
summon minecraft:strider -6.0 -48.5 -7.0 {equipment:{saddle:{id:"minecraft:saddle"}}}
summon minecraft:strider -6.0 -48.5 -7.0 {equipment:{saddle:{id:"minecraft:saddle"}}}
summon minecraft:magma_cube -6.0 -48 9 {Size:2,PersistenceRequired:1b}
summon minecraft:zombified_piglin 0.50 -49.00 5.50 {PersistenceRequired:1b}
summon minecraft:zombified_piglin 3.50 -49.13 -0.50 {PersistenceRequired:1b}
summon minecraft:enderman 5 -48 9 {PersistenceRequired:1b}

# END
summon minecraft:end_crystal -8.50 -56.50 -6.50
summon minecraft:end_crystal 7.50 -54.50 9.50
summon minecraft:end_crystal 0.50 -55.50 12.50
summon minecraft:end_crystal -7.50 -55.50 9.50
summon minecraft:end_crystal -12.50 -53.50 0.50
summon minecraft:end_crystal 0.50 -54.50 -11.50
summon minecraft:end_crystal 7.50 -54.50 -7.50
summon minecraft:bat 0 -53 0 {Invulnerable:true,CustomNameVisible:true,CustomName:{text:"Ender Dragon",color:dark_purple},Glowing:true}
summon minecraft:enderman 3.50 -58.00 8.50 {PersistenceRequired:1b}
summon minecraft:enderman -3.73 -58.00 -5.73 {PersistenceRequired:1b}
summon minecraft:enderman 4.50 -58.00 -5.50 {PersistenceRequired:1b}
summon minecraft:enderman -8 -58 4 {PersistenceRequired:1b}

schedule function maps:map/08_map/func 3s