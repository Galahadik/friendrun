place template maps:map_10 -17 -61 -17
