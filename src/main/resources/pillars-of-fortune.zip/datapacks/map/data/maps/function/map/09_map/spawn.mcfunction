place template maps:map_09 -17 -61 -17

summon minecraft:cave_spider 8 -50 -8 {attributes:[{base:3.5,id:"minecraft:scale"},{base:30,id:"minecraft:max_health"},{id:"minecraft:fall_damage_multiplier",base:0},{id:"minecraft:attack_damage",base:4.25}],active_effects:[{id:"minecraft:regeneration",amplifier:255,duration:30}],PersistenceRequired:1b}

summon minecraft:skeleton -4 -55 -9 {equipment:{head:{id:"chainmail_helmet"},mainhand:{id:"stick"}},PersistenceRequired:1b}
summon minecraft:skeleton -4 -55 -9 {equipment:{head:{id:"chainmail_helmet"},mainhand:{id:"stick"}},PersistenceRequired:1b}

summon minecraft:zombie_villager -6 -56 -4 {equipment:{head:{id:"minecraft:chainmail_helmet"},mainhand:{id:wooden_sword}},PersistenceRequired:1b}

summon minecraft:witch -11 -56 -5 {PersistenceRequired:1b}

summon minecraft:wither_skeleton -10 -53 -9 {PersistenceRequired:1b}

summon minecraft:zombie -7 -55 12 {IsBaby:true,PersistenceRequired:1b,equipment:{head:{id:"minecraft:chainmail_helmet"},mainhand:{id:stick}}}