execute unless data storage minecraft:settings {modificators:{enable:true}} unless data storage minecraft:settings {modificators:{enable:false}} run return run function settings:changes/modificators/enable_disable/reset

function settings:pages/modificators/page_1