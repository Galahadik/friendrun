data modify storage minecraft:settings events.enable set value false

function settings:changes/events/enable_disable/check