data merge storage minecraft:settings {maps:{empty_maps:false}}

function settings:changes/maps/enable_disable/empty/check