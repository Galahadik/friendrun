execute unless data storage minecraft:settings {maps:{empty_maps:false}} unless data storage minecraft:settings {maps:{empty_maps:true}} run return run function settings:changes/maps/enable_disable/empty/reset

function settings:pages/maps/page_1