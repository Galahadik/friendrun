execute unless data storage minecraft:settings {events:{who_got_op_sword:true}} unless data storage minecraft:settings {events:{who_got_op_sword:false}} run return run function settings:changes/events/event/op_sword/player_notification/enable_disable/reset

function settings:pages/events/page_1