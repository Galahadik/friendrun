data merge storage minecraft:settings {maps:{enable:true}}

function settings:changes/maps/enable_disable/check