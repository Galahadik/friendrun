execute unless score #players_count settings matches 3.. run return run function settings:changes/game/gamemode/team/nope

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function cmd:map/lobby/start/hologram/game_info/teams/respawn
execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run data modify storage minecraft:settings gamemodes.gamemode set value teams


data modify storage minecraft:settings gamemodes.sub_gamemodes.gamemode set value none
execute if data storage minecraft:map {clicker:["game_info"]} run kill @e[tag=game_info_sub_gamemode_holo]


function settings:changes/game/gamemode/team/check