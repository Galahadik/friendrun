execute unless data storage minecraft:settings {gamemodes:{params:{assign_teams_method:"choice"}}} unless data storage minecraft:settings {gamemodes:{params:{assign_teams_method:"random"}}} run return run function settings:changes/game/gamemode/team/random_players_in_teams/reset

function settings:pages/game/page_1