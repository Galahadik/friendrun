
execute if data storage minecraft:settings {kits:{kit:1}} run data merge storage minecraft:settings {kits:{kit:0}}
execute if data storage minecraft:settings {kits:{kit:2}} run data merge storage minecraft:settings {kits:{kit:1}}
execute if data storage minecraft:settings {kits:{kit:3}} run data merge storage minecraft:settings {kits:{kit:2}}
execute if data storage minecraft:settings {kits:{kit:4}} run data merge storage minecraft:settings {kits:{kit:3}}
execute if data storage minecraft:settings {kits:{kit:5}} run data merge storage minecraft:settings {kits:{kit:4}}


function settings:changes/items/kits/funcs/func_1
function settings:changes/items/kits/check