tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{text:"\"",color:green},{text:"4 в ряд",bold:true},"\" Разблокирован!"]]

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65

function settings:changes/lobby/clicker/unlock_lock/door/unlock

data modify storage minecraft:map clicker append value "connect_4"
function cmd:map/lobby/clicker/stats/modify_text