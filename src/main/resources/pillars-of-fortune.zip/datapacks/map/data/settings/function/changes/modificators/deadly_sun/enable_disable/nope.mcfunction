playsound minecraft:entity.villager.no ambient @s ~ ~ ~

function settings:pages/modificators/page_1 with storage minecraft:temp {nope:true}