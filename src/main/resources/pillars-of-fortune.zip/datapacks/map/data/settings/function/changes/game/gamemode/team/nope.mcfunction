playsound minecraft:entity.villager.no ambient @s ~ ~ ~

function settings:pages/game/page_1 with storage minecraft:temp {nope:true}

tellraw @s ["<",{text:"Столбы",color:gray},"> ",{text:"Невозможно поменять режим т.к игроков слишком мало",color:red}]