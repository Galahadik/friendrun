data merge storage minecraft:settings {kits:{enable:false}}

function settings:pages/items/page_1