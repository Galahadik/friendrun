fill -11 28 -98 -12 27 -100 air
fill -12 29 -100 -12 32 -98 air
fill -11 29 -99 -11 29 -98 air
setblock -11 30 -98 air

tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{text:"\"",color:green},{text:"Бар",bold:true},"\" Разблокирован!"]]

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65

data modify storage minecraft:map clicker append value "bar"
function cmd:map/lobby/entities/seats/spawn
function cmd:map/lobby/clicker/stats/modify_text