execute if score #teams.teams_count settings matches 1..5 run scoreboard players add #teams.teams_count settings 1
execute if score #teams.teams_count settings matches 6 run scoreboard players set #teams.teams_count settings 1

function settings:changes/game/gamemode/team/check