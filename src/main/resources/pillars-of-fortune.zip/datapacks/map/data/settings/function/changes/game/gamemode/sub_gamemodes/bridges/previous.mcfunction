execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["circle"]}}}}} run data modify storage minecraft:settings gamemodes.sub_gamemodes.params.bridges.structure append value plus

function settings:changes/game/gamemode/sub_gamemodes/bridges/check