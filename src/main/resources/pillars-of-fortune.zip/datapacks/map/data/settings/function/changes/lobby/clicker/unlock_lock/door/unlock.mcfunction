setblock -4 28 -99 dark_oak_door[open=true]
setblock -4 30 -99 dark_oak_trapdoor[open=true]
execute as @a at @s run playsound block.wooden_door.open hostile @s ~ ~ ~ 1
