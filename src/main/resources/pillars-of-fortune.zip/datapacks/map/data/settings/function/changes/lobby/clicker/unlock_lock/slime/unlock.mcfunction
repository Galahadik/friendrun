tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{text:"\"",color:green},{text:"Слайми",bold:true},"\" Разблокирован!"]]

data modify storage minecraft:map clicker append value "slime"
function cmd:map/lobby/clicker/stats/modify_text

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65

setblock 5 26 -104 minecraft:slime_block
setblock 6 26 -104 minecraft:slime_block
setblock 6 26 -105 minecraft:slime_block

setblock 6 27 -103 minecraft:lime_carpet
setblock 4 27 -104 minecraft:lime_carpet
setblock 5 27 -105 minecraft:lime_carpet

function cmd:map/lobby/lobby_entities