function settings:changes/lobby/clicker/unlock_lock/slime/lock

function settings:changes/lobby/clicker/unlock_lock/door/lock

function settings:changes/lobby/clicker/unlock_lock/parkour/lock
function settings:changes/lobby/clicker/unlock_lock/chairs/default/lock

function settings:changes/lobby/clicker/unlock_lock/connect_4/lock
function settings:changes/lobby/clicker/unlock_lock/chairs/king/lock
function settings:changes/lobby/clicker/unlock_lock/game_info/lock
function settings:changes/lobby/clicker/unlock_lock/mob_arena/lock
function settings:changes/lobby/clicker/unlock_lock/death_hole/lock
function settings:changes/lobby/clicker/unlock_lock/bar/lock

function cmd:map/lobby/lobby_entities