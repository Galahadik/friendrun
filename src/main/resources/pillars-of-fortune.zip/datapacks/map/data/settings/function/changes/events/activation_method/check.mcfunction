execute unless data storage minecraft:settings {events:{activation_method:"timer"}} unless data storage minecraft:settings {events:{activation_method:"button"}} run return run function settings:changes/events/activation_method/reset

function settings:pages/events/page_1