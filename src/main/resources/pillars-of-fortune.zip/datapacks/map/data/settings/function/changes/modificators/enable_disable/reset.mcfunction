data modify storage minecraft:settings modificators.enable set value true

function settings:pages/modificators/page_1