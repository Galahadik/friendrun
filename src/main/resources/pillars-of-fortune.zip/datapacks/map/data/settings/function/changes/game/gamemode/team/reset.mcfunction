data modify storage minecraft:settings gamemodes.gamemode set value default

function settings:pages/game/page_1