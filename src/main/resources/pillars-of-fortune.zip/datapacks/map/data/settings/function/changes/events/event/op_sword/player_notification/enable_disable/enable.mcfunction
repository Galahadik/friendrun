data modify storage minecraft:settings events.who_got_op_sword set value true


function settings:changes/events/event/op_sword/player_notification/enable_disable/check