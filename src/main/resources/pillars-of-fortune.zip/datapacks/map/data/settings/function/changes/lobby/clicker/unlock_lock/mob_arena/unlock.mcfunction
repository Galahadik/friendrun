tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{text:"\"",color:green},{text:"Арена монстров",bold:true},"\" Разблокирована!"]]

gamerule block_drops false
fill 15 30 -86 17 28 -86 air destroy
fill 15 27 -86 17 27 -86 minecraft:spruce_stairs[facing=south,half=top] destroy
gamerule block_drops true

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65


data modify storage minecraft:map clicker append value "mob_arena"
function cmd:map/lobby/clicker/stats/modify_text