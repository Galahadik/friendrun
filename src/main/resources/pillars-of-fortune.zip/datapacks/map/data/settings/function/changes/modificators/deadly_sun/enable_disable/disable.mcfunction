data modify storage minecraft:settings modificators.sun_burning_modificator set value false

function settings:changes/modificators/deadly_sun/enable_disable/check
