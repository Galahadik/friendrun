execute unless data storage minecraft:settings {lobby:{pvp:true}} unless data storage minecraft:settings {lobby:{pvp:false}} run return run function settings:changes/lobby/pvp/enable_disable/reset

function settings:pages/lobby/page_1