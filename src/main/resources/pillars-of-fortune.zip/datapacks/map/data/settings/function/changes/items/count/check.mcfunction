execute unless score #items_give_count settings matches 1..16 run return run function settings:changes/items/count/reset

function settings:pages/items/page_1