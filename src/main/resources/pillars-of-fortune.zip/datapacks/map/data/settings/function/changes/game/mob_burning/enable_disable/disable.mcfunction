data merge storage minecraft:settings {mobs:{burning:false}}

function settings:changes/game/mob_burning/enable_disable/check