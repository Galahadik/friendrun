fill 16 27 -90 3 28 -89 air

fill 0 28 -93 1 27 -93 air

fill 7 27 -93 10 28 -93 air

fill 19 28 -93 18 27 -93 air

fill 1 28 -105 0 27 -105 air

kill @e[type=item,nbt={Item:{id:"minecraft:oak_sign"}}]

scoreboard players set &lobby.chair settings 0