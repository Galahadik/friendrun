data merge storage minecraft:settings {kits:{enable:true}}

function settings:changes/items/kits/enable_disable/check