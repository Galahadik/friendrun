scoreboard players add &lobby.chair settings 1

tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{score:{name:"&lobby.chair",objective:"settings"},color:green},"-й \"",{text:"Стул",bold:true},"\" Разблокирован!"]]

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65


execute if score &lobby.chair settings matches 1 run place template cmd:lobby/chair 0 27 -104 counterclockwise_90

execute if score &lobby.chair settings matches 2 run place template cmd:lobby/chair 15 27 -90

execute if score &lobby.chair settings matches 3 run place template cmd:lobby/chair 11 27 -90

execute if score &lobby.chair settings matches 4 run place template cmd:lobby/chair 3 27 -90

execute if score &lobby.chair settings matches 5 run place template cmd:lobby/chair 1 27 -94 clockwise_90

execute if score &lobby.chair settings matches 6 run place template cmd:lobby/chair 18 27 -92 counterclockwise_90

execute if score &lobby.chair settings matches 7 run place template cmd:lobby/chair 10 27 -94 clockwise_90

execute if score &lobby.chair settings matches 8 run place template cmd:lobby/chair 7 27 -92 counterclockwise_90

function cmd:map/lobby/entities/seats/spawn
function cmd:map/lobby/clicker/stats/modify_text