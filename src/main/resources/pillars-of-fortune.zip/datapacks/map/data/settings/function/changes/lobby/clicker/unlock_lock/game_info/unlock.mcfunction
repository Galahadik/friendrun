setblock 19 27 -95 minecraft:polished_andesite_slab

tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{text:"\"",color:green},{text:"Панель с настройками",bold:true},"\" Разблокирована!"]]

data modify storage minecraft:map clicker append value "game_info"
function cmd:map/lobby/clicker/stats/modify_text

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65


function cmd:map/lobby/start/hologram/game_info/respawn