data merge storage minecraft:map {clicker:[]}

function settings:changes/lobby/clicker/unlock_lock/lock_all
function admin:menu

tellraw @a[tag=Admin] ["<",{"text":"Столбы","color":"gray"},"> ",{"text":"Кол-во нажатий в кликере было успешно очищено. Прошлое кол-во нажатий","color":"green"},{"text":" » ","color":"gray","bold":true},{"score":{"name":"&lobby_clicker","objective":"settings"},"bold":true,"color":"yellow"}]

execute if score &lobby_clicker2 settings matches ..-1 run scoreboard players operation &lobby_clicker settings = &lobby_clicker2 settings
execute if score &lobby_clicker2 settings matches 0.. run scoreboard players set &lobby_clicker2 settings 0
execute if score &lobby_clicker2 settings matches 0.. run scoreboard players set &lobby_clicker settings 0

function cmd:map/lobby/clicker/stats/modify_text_clicks