data modify storage minecraft:settings lobby.perm_to_start set value false

function settings:pages/lobby/page_1