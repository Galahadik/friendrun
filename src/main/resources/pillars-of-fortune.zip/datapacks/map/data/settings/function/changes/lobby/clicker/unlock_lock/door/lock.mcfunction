setblock -4 28 -99 dark_oak_door[open=false] replace
setblock -4 30 -99 dark_oak_trapdoor[open=true,facing=west]
playsound block.wooden_door.close hostile @a -4 28 -99 1