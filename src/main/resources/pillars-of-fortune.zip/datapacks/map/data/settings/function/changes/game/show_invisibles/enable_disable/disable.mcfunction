data merge storage minecraft:settings {show_invisibles:false}

team modify player seeFriendlyInvisibles false

function settings:changes/game/show_invisibles/enable_disable/check