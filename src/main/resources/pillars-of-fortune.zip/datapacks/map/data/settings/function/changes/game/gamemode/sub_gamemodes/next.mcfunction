function settings:changes/game/gamemode/sub_gamemodes/next2

execute unless data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"none"}}} run function cmd:map/lobby/start/hologram/game_info/sub_gamemodes/respawn
execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"none"}}} run kill @e[tag=game_info_sub_gamemode_holo]

function settings:changes/game/gamemode/sub_gamemodes/check