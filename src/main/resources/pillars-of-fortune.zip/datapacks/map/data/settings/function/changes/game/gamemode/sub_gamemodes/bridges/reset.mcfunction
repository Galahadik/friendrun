data modify storage minecraft:settings gamemodes.sub_gamemodes.params.bridges.structure set value ["plus"]

function settings:pages/game/page_2