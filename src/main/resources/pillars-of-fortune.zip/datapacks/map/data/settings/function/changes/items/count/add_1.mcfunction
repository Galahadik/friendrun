scoreboard players add #items_give_count settings 1

function settings:changes/items/count/check
