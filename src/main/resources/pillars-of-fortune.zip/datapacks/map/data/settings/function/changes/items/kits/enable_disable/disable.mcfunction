data merge storage minecraft:settings {kits:{enable:false}}

function settings:changes/items/kits/enable_disable/check