execute unless data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["plus","circle"]}}}}} if data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["plus"]}}}}} run data modify storage minecraft:settings gamemodes.sub_gamemodes.params.bridges.structure set value ["circle"]

execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["plus","circle"]}}}}} run data modify storage minecraft:settings gamemodes.sub_gamemodes.params.bridges.structure set value ["plus"]


function settings:changes/game/gamemode/sub_gamemodes/bridges/check