scoreboard players add &lobby.parkour settings 1

tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{score:{name:"&lobby.parkour",objective:"settings"},color:green},"-й \"",{text:"Паркур",bold:true},"\" Разблокирован!"]]

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65

execute if score &lobby.parkour settings matches 1 run function cmd:map/lobby/clicker/stats/modify_text
execute if score &lobby.parkour settings matches 1 run fill 25 30 -94 24 27 -92 air replace black_wool

execute if score &lobby.parkour settings matches 2 run function cmd:map/lobby/clicker/stats/modify_text
execute if score &lobby.parkour settings matches 2 run fill 24 34 -84 24 36 -84 air

execute if score &lobby.parkour settings matches 3 run function cmd:map/lobby/clicker/stats/modify_text
execute if score &lobby.parkour settings matches 3 run place template cmd:lobby/parkour_trap 9 37 -93
execute if score &lobby.parkour settings matches 3 run setblock 10 41 -91 air
execute if score &lobby.parkour settings matches 3 run fill 24 40 -84 24 38 -84 air
execute if score &lobby.parkour settings matches 3 run fill -4 53 -83 0 47 -79 air replace minecraft:black_wool