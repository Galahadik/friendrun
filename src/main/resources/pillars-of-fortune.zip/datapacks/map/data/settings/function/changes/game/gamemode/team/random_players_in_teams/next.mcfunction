data modify storage minecraft:settings gamemodes.params.assign_teams_method set value "random"

function settings:changes/game/gamemode/team/random_players_in_teams/check