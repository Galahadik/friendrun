playsound minecraft:entity.villager.no ambient @s ~ ~ ~

function settings:pages/lobby/page_1 with storage minecraft:temp {nope:true}