data modify storage minecraft:settings events.activation_method set value "timer"

function settings:changes/events/activation_method/check