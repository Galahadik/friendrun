setblock -2 26 -95 air

tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{text:"\"",color:green},{text:"Яма смерти",bold:true},"\" Разблокирована!"]]

data modify storage minecraft:map clicker append value "death_hole"
function cmd:map/lobby/clicker/stats/modify_text

function cmd:map/lobby/lobby_entities

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65
