data merge storage minecraft:settings {maps:{empty_maps:false}}

function settings:pages/events/page_1