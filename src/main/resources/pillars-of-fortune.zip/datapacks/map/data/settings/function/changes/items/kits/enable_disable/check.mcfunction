execute unless data storage minecraft:settings {kits:{enable:true}} unless data storage minecraft:settings {kits:{enable:false}} run return run function settings:changes/items/kits/enable_disable/reset


function settings:pages/items/page_1
