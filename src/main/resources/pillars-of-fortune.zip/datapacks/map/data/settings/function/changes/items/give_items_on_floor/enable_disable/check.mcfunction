execute unless data storage minecraft:settings {give_items_on_floor:true} unless data storage minecraft:settings {give_items_on_floor:false} run return run function settings:changes/events/enable_disable/reset

function settings:pages/items/page_1