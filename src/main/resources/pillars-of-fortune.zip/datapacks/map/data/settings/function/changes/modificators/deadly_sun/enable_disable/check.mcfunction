execute unless data storage minecraft:settings {modificators:{sun_burning_modificator:true}} unless data storage minecraft:settings {modificators:{sun_burning_modificator:false}} run return run function settings:changes/modificators/deadly_sun/enable_disable/reset

function settings:pages/modificators/page_1