execute unless data storage minecraft:settings {lobby:{perm_to_start:true}} unless data storage minecraft:settings {lobby:{perm_to_start:false}} run return run function settings:changes/lobby/start_button/start_button_permission/enable_disable/reset

function settings:pages/lobby/page_1