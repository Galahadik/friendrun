data merge storage minecraft:settings {mobs:{teleport_to_deathmatch:true}}

function settings:changes/game/mobs_teleport_to_deathmatch/enable_disable/check