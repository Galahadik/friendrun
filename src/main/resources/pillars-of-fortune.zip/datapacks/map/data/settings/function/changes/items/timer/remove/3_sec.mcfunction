scoreboard players remove #items_give_timer settings 60
scoreboard players remove #items_give_timer.sec settings 3

function settings:changes/items/timer/check