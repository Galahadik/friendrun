data modify storage minecraft:settings lobby.pvp set value true

gamerule pvp true


function settings:changes/lobby/pvp/enable_disable/check