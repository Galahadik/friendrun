data modify storage minecraft:settings events.enable set value true

function settings:changes/events/enable_disable/check