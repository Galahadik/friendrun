data modify storage minecraft:settings lobby.perm_to_start set value false

function settings:changes/lobby/start_button/start_button_permission/enable_disable/check