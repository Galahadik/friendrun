tellraw @a ["<",{text:"Столбы",color:gray},"> ","<",{text:"Кликер",color:gold},"> ",[{text:"\"",color:green},{text:"Королевский трон",bold:true},"\" Разблокирован!"]]

place template cmd:lobby/king_throne 9 27 -111

data modify storage minecraft:map clicker append value "throne"
function cmd:map/lobby/clicker/stats/modify_text

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.65