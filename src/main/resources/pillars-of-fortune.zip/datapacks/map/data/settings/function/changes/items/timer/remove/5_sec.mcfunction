scoreboard players remove #items_give_timer settings 100
scoreboard players remove #items_give_timer.sec settings 5

function settings:changes/items/timer/check