data merge storage minecraft:settings {show_invisibles:false}

team modify player seeFriendlyInvisibles false

function settings:pages/game/page_3
