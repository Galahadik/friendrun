scoreboard players add #items_give_timer settings 20
scoreboard players add #items_give_timer.sec settings 1

function settings:changes/items/timer/check