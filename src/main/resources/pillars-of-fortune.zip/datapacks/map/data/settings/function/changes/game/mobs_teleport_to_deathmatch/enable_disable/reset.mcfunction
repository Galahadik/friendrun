data merge storage minecraft:settings {mobs:{teleport_to_deathmatch:true}}

function settings:pages/game/page_3