data merge storage minecraft:settings {mobs:{burning:true}}

function settings:pages/game/page_3