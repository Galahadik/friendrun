data merge storage minecraft:settings {give_items_on_floor:false}

function settings:pages/items/page_1