execute unless data storage minecraft:settings {mobs:{burning:false}} unless data storage minecraft:settings {mobs:{burning:true}} run return run function settings:changes/game/mob_burning/enable_disable/reset

function settings:pages/game/page_3
