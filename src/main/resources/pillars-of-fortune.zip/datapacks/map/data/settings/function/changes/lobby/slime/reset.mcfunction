data modify storage minecraft:settings lobby.slime set value true

function settings:pages/lobby/page_1