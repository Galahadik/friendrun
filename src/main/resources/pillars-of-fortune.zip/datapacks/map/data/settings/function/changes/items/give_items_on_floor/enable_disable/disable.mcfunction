data merge storage minecraft:settings {give_items_on_floor:false}

function settings:changes/items/give_items_on_floor/enable_disable/check