data modify block 1 21 -89 Items set from block 1 23 -89 Items
data modify block 1 21 -88 Items set from block 1 23 -88 Items
data modify block 1 21 -87 Items set from block 1 23 -87 Items

tellraw @s ["<",{text:"Столбы",color:gray},"> ",{text:"Бекап набора №2 был успешно загружен.",color:green}]
playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.75
function settings:pages/kits/page_1