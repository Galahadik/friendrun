data modify storage minecraft:settings events.who_got_op_sword set value false

function settings:pages/events/page_1