setblock 19 27 -95 air

kill @e[tag=game_info_holo]
kill @e[tag=game_info_teams_holo]
kill @e[tag=game_info_sub_gamemode_holo]