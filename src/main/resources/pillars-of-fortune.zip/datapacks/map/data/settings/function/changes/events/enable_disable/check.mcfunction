execute unless data storage minecraft:settings {events:{enable:true}} unless data storage minecraft:settings {events:{enable:false}} run return run function settings:changes/events/enable_disable/reset

function settings:pages/events/page_1