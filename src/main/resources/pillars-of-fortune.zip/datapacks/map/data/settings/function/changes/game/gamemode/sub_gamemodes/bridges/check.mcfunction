execute unless data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["plus"]}}}}} unless data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["circle"]}}}}} run return run function settings:changes/game/gamemode/sub_gamemodes/bridges/reset

function settings:pages/game/page_2