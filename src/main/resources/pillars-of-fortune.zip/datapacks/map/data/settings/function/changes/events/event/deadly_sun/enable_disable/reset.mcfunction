data modify storage minecraft:settings events.sun_burning_events set value true

function settings:pages/modificators/page_1