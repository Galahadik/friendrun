data merge storage minecraft:settings {kits:{kit:1}}

function settings:pages/items/page_1