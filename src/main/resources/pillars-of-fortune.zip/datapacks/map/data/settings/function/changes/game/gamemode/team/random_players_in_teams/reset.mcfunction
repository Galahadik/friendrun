data modify storage minecraft:settings gamemodes.params.assign_teams_method set value "choice"

function settings:pages/game/page_1