data merge storage minecraft:settings {mobs:{burning:true}}

function settings:changes/game/mob_burning/enable_disable/check