data modify storage minecraft:settings lobby.pvp set value false

gamerule pvp false

function settings:changes/lobby/pvp/enable_disable/check