scoreboard players set #items_give_count settings 1

function settings:pages/items/page_1