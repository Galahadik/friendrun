data merge storage minecraft:settings {show_invisibles:true}

team modify player seeFriendlyInvisibles true

function settings:changes/game/show_invisibles/enable_disable/check