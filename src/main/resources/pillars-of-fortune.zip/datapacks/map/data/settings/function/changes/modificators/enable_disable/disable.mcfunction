data modify storage minecraft:settings modificators.enable set value false

function settings:changes/modificators/enable_disable/check
