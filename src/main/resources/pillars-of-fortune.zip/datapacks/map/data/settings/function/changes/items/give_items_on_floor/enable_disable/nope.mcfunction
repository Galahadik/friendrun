playsound minecraft:entity.villager.no ambient @s ~ ~ ~

function settings:pages/items/page_1 with storage minecraft:temp {nope:true}