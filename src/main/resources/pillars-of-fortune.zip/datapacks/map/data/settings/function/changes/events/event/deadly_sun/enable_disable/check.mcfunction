execute unless data storage minecraft:settings {events:{sun_burning_event:true}} unless data storage minecraft:settings {events:{sun_burning_event:false}} run return run function settings:changes/events/event/deadly_sun/enable_disable/reset

function settings:pages/events/page_1