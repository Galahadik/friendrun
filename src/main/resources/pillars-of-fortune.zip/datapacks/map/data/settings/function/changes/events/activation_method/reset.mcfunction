data modify storage minecraft:settings events.activation_method set value "button"

function settings:pages/events/page_1