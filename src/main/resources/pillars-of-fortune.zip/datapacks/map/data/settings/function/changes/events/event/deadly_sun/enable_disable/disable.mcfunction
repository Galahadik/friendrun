data modify storage minecraft:settings events.sun_burning_event set value false

function settings:changes/events/event/deadly_sun/enable_disable/check
