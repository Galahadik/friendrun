data modify storage minecraft:settings events.enable set value true

function settings:pages/events/page_1