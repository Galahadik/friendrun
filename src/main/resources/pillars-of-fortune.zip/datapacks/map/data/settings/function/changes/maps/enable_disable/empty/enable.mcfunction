data merge storage minecraft:settings {maps:{empty_maps:true}}

function settings:changes/maps/enable_disable/empty/check