execute unless data storage minecraft:settings {lobby:{slime:true}} unless data storage minecraft:settings {lobby:{slime:false}} run return run function settings:changes/lobby/slime/reset

function settings:pages/lobby/page_1