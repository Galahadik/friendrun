execute unless data storage minecraft:settings {gamemodes:{gamemode:default}} unless data storage minecraft:settings {gamemodes:{gamemode:teams}} run return run function settings:changes/game/gamemode/team/reset

function settings:pages/game/page_1