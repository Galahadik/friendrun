

execute unless data storage minecraft:settings {kits:{kit:1}} unless data storage minecraft:settings {kits:{kit:2}} unless data storage minecraft:settings {kits:{kit:3}} unless data storage minecraft:settings {kits:{kit:4}} unless data storage minecraft:settings {kits:{kit:5}} run return run function settings:changes/items/kits/reset

function settings:pages/items/page_1