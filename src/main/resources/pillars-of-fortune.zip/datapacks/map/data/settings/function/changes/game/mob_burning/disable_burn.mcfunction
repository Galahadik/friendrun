execute if items entity @s armor.head * run tag @s add helmet

item replace entity @s[tag=!helmet] armor.head with minecraft:stone_button
data merge entity @s[tag=!helmet] {drop_chances:{head:0}}
tag @s add noBurn