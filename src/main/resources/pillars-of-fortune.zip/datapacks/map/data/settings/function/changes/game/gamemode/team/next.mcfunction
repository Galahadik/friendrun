execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run kill @e[tag=game_info_teams_holo]
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run data modify storage minecraft:settings gamemodes.gamemode set value default

data modify storage minecraft:settings gamemodes.sub_gamemodes.gamemode set value none
execute if data storage minecraft:map {clicker:["game_info"]} run kill @e[tag=game_info_sub_gamemode_holo]

function settings:changes/game/gamemode/team/check