data modify storage minecraft:settings gamemodes.sub_gamemodes.gamemode set value "none"

function settings:pages/game/page_2
