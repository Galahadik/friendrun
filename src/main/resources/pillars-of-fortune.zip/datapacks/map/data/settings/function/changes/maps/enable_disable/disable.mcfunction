data merge storage minecraft:settings {maps:{enable:false}}

function settings:changes/maps/enable_disable/check