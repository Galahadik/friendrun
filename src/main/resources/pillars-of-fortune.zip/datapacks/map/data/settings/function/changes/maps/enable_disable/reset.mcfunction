data merge storage minecraft:settings {give_items_on_floor:false}

function settings:pages/maps/page_1