execute unless data storage minecraft:settings {mobs:{teleport_to_deathmatch:false}} unless data storage minecraft:settings {mobs:{teleport_to_deathmatch:true}} run return run function settings:changes/game/mobs_teleport_to_deathmatch/enable_disable/reset

function settings:pages/game/page_3
