execute as @e[type=minecraft:zombie,tag=!noBurn] run function settings:changes/game/mob_burning/disable_burn
execute as @e[type=minecraft:zombie_villager,tag=!noBurn] run function settings:changes/game/mob_burning/disable_burn
execute as @e[type=minecraft:drowned,tag=!noBurn] run function settings:changes/game/mob_burning/disable_burn

execute as @e[type=minecraft:skeleton,tag=!noBurn] run function settings:changes/game/mob_burning/disable_burn
execute as @e[type=minecraft:stray,tag=!noBurn] run function settings:changes/game/mob_burning/disable_burn
execute as @e[type=minecraft:bogged,tag=!noBurn] run function settings:changes/game/mob_burning/disable_burn