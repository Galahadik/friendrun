execute unless data storage minecraft:settings {give_items_on_floor:true} unless data storage minecraft:settings {give_items_on_floor:false} run return run function settings:changes/maps/enable_disable/reset

function settings:pages/maps/page_1