execute unless score #teams.teams_count settings matches 1..5 run return run function settings:changes/game/gamemode/team/reset

function settings:pages/game/page_1