fill -11 28 -98 -12 27 -100 black_wool
fill -12 29 -100 -12 32 -98 black_wool
fill -11 29 -99 -11 29 -98 black_wool
setblock -11 30 -98 black_wool