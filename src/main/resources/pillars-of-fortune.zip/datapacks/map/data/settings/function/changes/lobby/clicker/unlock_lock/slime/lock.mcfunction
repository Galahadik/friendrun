fill 6 27 -103 4 27 -105 air replace minecraft:lime_carpet
setblock 6 26 -105 minecraft:mangrove_wood
fill 5 26 -104 6 26 -104 minecraft:stripped_dark_oak_wood