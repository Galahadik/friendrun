data modify storage minecraft:settings modificators.sun_burning_modificator set value true

function settings:pages/modificators/page_1