data modify storage minecraft:settings lobby.slime set value true

function cmd:map/lobby/lobby_entities

function settings:changes/lobby/slime/check