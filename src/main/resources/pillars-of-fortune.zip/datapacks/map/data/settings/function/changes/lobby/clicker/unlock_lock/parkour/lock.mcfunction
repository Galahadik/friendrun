scoreboard players set &lobby.parkour settings 0

fill 24 28 -94 25 27 -92 black_wool replace air
fill 25 29 -92 25 30 -94 black_wool replace air
setblock 24 29 -94 minecraft:black_wool

fill 24 34 -84 24 36 -84 black_wool

fill 9 37 -93 11 40 -89 air
setblock 10 41 -91 minecraft:oak_planks
fill 24 40 -84 24 38 -84 black_wool

fill -4 53 -83 0 47 -79 black_wool replace air