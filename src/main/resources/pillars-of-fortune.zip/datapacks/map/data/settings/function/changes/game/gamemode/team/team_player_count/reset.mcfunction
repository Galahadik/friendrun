scoreboard players set #teams.teams_count settings 1

function settings:pages/game/page_1