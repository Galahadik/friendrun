execute unless score #items_give_timer.sec settings matches 1..60 run return run function settings:changes/items/timer/reset
execute unless score #items_give_timer settings matches 20..1200 run return run function settings:changes/items/timer/reset


function settings:pages/items/page_1