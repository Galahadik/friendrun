data modify storage minecraft:settings modificators.enable set value true

function settings:changes/modificators/enable_disable/check