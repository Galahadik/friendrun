scoreboard players set #items_give_timer settings 100
scoreboard players set #items_give_timer.sec settings 5

function settings:pages/items/page_1