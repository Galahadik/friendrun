data modify storage minecraft:settings lobby.pvp set value true

function settings:pages/lobby/page_1