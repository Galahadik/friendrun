execute unless data storage minecraft:settings {show_invisibles:false} unless data storage minecraft:settings {show_invisibles:true} run return run function settings:changes/game/show_invisibles/enable_disable/reset

function settings:pages/game/page_3