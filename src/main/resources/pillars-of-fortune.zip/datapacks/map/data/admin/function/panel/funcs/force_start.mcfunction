execute if data storage map {game_running:true} run return fail

scoreboard players reset @a force_start.trigger

function cmd:map/lobby/start/check_conditions/check

