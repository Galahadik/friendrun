function events:event/15_rebith_all/reive

attribute @s max_health modifier remove rebirth