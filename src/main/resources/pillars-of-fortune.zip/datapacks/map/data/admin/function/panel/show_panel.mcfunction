scoreboard players reset @s panel.trigger

execute if data storage minecraft:map {game_running:false} run return run function admin:panel/lobby_panel
execute if data storage minecraft:map {game_running:true} run return run function admin:panel/game_panel