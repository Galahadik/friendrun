execute if entity @s[tag=alive] run tellraw @s ["<",{text:"Столбы",color:gray},"> ",{text:"Данную функцию можно выполнить только если вы мертвы.",color:red}]
execute if entity @s[tag=alive] run playsound entity.villager.no hostile @s ~ ~ ~ 0.75
execute if entity @s[tag=alive] run return fail

function admin:fun/ride/funcs/func

execute at @s run summon happy_ghast ~ ~ ~ {Tags:["fun","ride"],Silent:true,attributes:[{id:"minecraft:scale",base:0.15d}]}
execute at @s run ride @s mount @e[type=happy_ghast,limit=1,sort=nearest,tag=ride]