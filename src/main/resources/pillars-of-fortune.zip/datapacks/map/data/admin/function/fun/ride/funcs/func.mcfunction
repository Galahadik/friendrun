tag @s add ghost
execute if data storage minecraft:map {modificators:{modificators:["x0.5_scale"]}} run attribute @s scale modifier add fun_ride -0.25 add_value
execute if data storage minecraft:map {modificators:{modificators:["x2_scale"]}} run attribute @s scale modifier add fun_ride -1 add_value
execute unless data storage minecraft:map {modificators:{modificators:["x2_scale","x0.5_scale"]}} run attribute @s scale modifier add fun_ride -0.5 add_value
effect give @s minecraft:weakness infinite 255 true
gamemode adventure @s

execute unless predicate events:check_in_game_zone run tp @s 0 65 0
effect give @s saturation 1 255 true
