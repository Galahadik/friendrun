execute at @s run particle minecraft:elder_guardian ~ ~ ~
execute at @s run playsound entity.elder_guardian.curse master @s ~ ~ ~ 10