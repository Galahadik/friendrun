summon pig ~ ~ ~ {Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"],Passengers:[{id:"minecraft:pig",Tags:["mega_pig"]}]}]}]}]}]}]}]}]}]}

execute as @e[tag=mega_pig] run data merge entity @s {CustomName:{text:"Ты)",color:gold},DeathLootTable:""}

effect give @e[tag=mega_pig] speed infinite 1 true