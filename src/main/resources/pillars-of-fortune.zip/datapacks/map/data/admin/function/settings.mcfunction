function settings:menu
