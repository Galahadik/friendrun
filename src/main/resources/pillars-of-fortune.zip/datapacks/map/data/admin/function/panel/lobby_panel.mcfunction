execute if data storage minecraft:map {game_running:trye} run return fail

tellraw @s "\n\n\n\n\n\n\n\n\n\n\n\n"

tellraw @s ["<",[{strikethrough:true,text:"          "},[{text:">>   Панель   <<",strikethrough:false}],{text:"          "}],">"]
tellraw @s ""

tellraw @s ["",{text:" ➥ ",color:gray,bold:true},[{text:"",color:yellow,click_event:{action:run_command,command:"/trigger force_start.trigger"},hover_event:{action:show_text,value:{text:"Нажмите, чтобы начать игру",color:gold}}},"[Начать игру]"]]

tellraw @s[tag=Admin] ["\n",{text:" ➥ ",color:gray,bold:true},[{text:"",color:gold,click_event:{action:run_command,command:"/function admin:menu"},hover_event:{action:show_text,value:{text:"Нажмите, чтобы открыть настройки",color:gold}}},"[Настройки]"]]

tellraw @s ""
tellraw @s ["<",[{strikethrough:true,text:"                                        "}],">"]