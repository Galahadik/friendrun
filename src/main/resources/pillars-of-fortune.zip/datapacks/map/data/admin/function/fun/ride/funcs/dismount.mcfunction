attribute @s max_health modifier remove fun_ride
attribute @s scale modifier remove fun_ride
effect give @s regeneration 1 255 true
effect give @s saturation 1 255 true
effect clear @s weakness
execute at @s run kill @n[distance=..3,tag=fun,tag=ride]
tag @s remove ghost
gamemode spectator @s