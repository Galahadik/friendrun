execute if data storage minecraft:map {game_running:false} run return fail

tellraw @s "\n\n\n\n\n\n\n\n\n\n\n\n"

tellraw @s ["<",[{strikethrough:true,text:"          "},[{text:">>   Панель   <<",strikethrough:false}],{text:"          "}],">"]
tellraw @s ""

tellraw @s ["",{text:" ➥ ",color:gray,bold:true},[{text:"",color:red,click_event:{action:run_command,command:"/trigger force_stop.trigger"},hover_event:{action:show_text,value:{text:"Нажмите, чтобы остановить игру",color:red}}},"[Остановить игру]"]]

tellraw @s ""
tellraw @s ["<",[{strikethrough:true,text:"                                        "}],">"]