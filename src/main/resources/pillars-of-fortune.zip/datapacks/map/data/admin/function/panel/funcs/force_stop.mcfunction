execute if data storage map {game_running:false} run return fail

function cmd:map/func/stop

execute as @a at @s run playsound minecraft:entity.villager.no hostile @s ~ ~ ~ 0.75
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{selector:"@s",color:blue},{text:" — Остановил игру",color:green}]

scoreboard players reset @a force_stop.trigger
