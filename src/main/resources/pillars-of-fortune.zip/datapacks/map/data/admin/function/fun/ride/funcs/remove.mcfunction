execute as @a[tag=ghost] run function admin:fun/ride/funcs/dismount
kill @e[tag=fun,tag=ride]