execute if data storage minecraft:map {events:{events:["1_hp"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Приступ",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Пол сердца до конца игры","color":"green"}

execute as @a[tag=alive] at @s run attribute @s minecraft:max_health base set 1

data modify storage minecraft:map events.events append value "1_hp"