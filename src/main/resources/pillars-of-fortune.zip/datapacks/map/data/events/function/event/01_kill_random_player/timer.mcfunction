scoreboard players remove $event.random_kill timer 1

title @a actionbar [{text:"До события",color:green},{text:" » ",color:gray},{score:{name:"$event.random_kill",objective:"timer"},color:red}," секунд"]

execute if score $event.random_kill timer matches 1.. run schedule function events:event/01_kill_random_player/timer 1s
execute if score $event.random_kill timer matches ..0 run function events:event/01_kill_random_player/kill