tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Событие \"Дождь из стрел\" закончился!",color:red}]

schedule clear events:event/25_arrow_rain/loop
schedule clear events:event/25_arrow_rain/loop2
schedule clear events:event/25_arrow_rain/loop3

kill @e[tag=event.arrow_rain1,type=armor_stand]
kill @e[tag=event.arrow_rain2,type=armor_stand]
kill @e[tag=event.arrow_rain3,type=armor_stand]


schedule function events:event/25_arrow_rain/kill 5s