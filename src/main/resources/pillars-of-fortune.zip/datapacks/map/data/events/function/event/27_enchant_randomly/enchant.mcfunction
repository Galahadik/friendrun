execute store result score #event.enchant_randomly rng run random value 1..42



execute if items entity @s armor.head * if score #event.enchant_randomly rng matches 37 run return run item modify entity @s armor.head events:enchant_item_compatible
execute if items entity @s armor.chest * if score #event.enchant_randomly rng matches 38 run return run item modify entity @s armor.chest events:enchant_item_compatible
execute if items entity @s armor.legs * if score #event.enchant_randomly rng matches 39 run return run item modify entity @s armor.legs events:enchant_item_compatible
execute if items entity @s armor.feet * if score #event.enchant_randomly rng matches 40 run return run item modify entity @s armor.feet events:enchant_item_compatible
execute if items entity @s weapon.offhand * if score #event.enchant_randomly rng matches 41 run return run item modify entity @s weapon.offhand events:enchant_item_compatible
execute if items entity @s weapon.offhand * if score #event.enchant_randomly rng matches 42 run return run item modify entity @s weapon.mainhand events:enchant_item_compatible

execute if items entity @s container.0 * if score #event.enchant_randomly rng matches 1 run return run item modify entity @s container.0 events:enchant_item
execute if items entity @s container.1 * if score #event.enchant_randomly rng matches 2 run return run item modify entity @s container.1 events:enchant_item
execute if items entity @s container.2 * if score #event.enchant_randomly rng matches 3 run return run item modify entity @s container.2 events:enchant_item
execute if items entity @s container.3 * if score #event.enchant_randomly rng matches 4 run return run item modify entity @s container.3 events:enchant_item
execute if items entity @s container.4 * if score #event.enchant_randomly rng matches 5 run return run item modify entity @s container.4 events:enchant_item
execute if items entity @s container.5 * if score #event.enchant_randomly rng matches 6 run return run item modify entity @s container.5 events:enchant_item
execute if items entity @s container.6 * if score #event.enchant_randomly rng matches 7 run return run item modify entity @s container.6 events:enchant_item
execute if items entity @s container.7 * if score #event.enchant_randomly rng matches 8 run return run item modify entity @s container.7 events:enchant_item
execute if items entity @s container.8 * if score #event.enchant_randomly rng matches 9 run return run item modify entity @s container.8 events:enchant_item
execute if items entity @s container.9 * if score #event.enchant_randomly rng matches 10 run return run item modify entity @s container.9 events:enchant_item
execute if items entity @s container.10 * if score #event.enchant_randomly rng matches 11 run return run item modify entity @s container.10 events:enchant_item
execute if items entity @s container.11 * if score #event.enchant_randomly rng matches 12 run return run item modify entity @s container.11 events:enchant_item
execute if items entity @s container.12 * if score #event.enchant_randomly rng matches 13 run return run item modify entity @s container.12 events:enchant_item
execute if items entity @s container.13 * if score #event.enchant_randomly rng matches 14 run return run item modify entity @s container.13 events:enchant_item
execute if items entity @s container.14 * if score #event.enchant_randomly rng matches 15 run return run item modify entity @s container.14 events:enchant_item
execute if items entity @s container.15 * if score #event.enchant_randomly rng matches 16 run return run item modify entity @s container.15 events:enchant_item
execute if items entity @s container.16 * if score #event.enchant_randomly rng matches 17 run return run item modify entity @s container.16 events:enchant_item
execute if items entity @s container.17 * if score #event.enchant_randomly rng matches 18 run return run item modify entity @s container.17 events:enchant_item
execute if items entity @s container.18 * if score #event.enchant_randomly rng matches 19 run return run item modify entity @s container.18 events:enchant_item
execute if items entity @s container.19 * if score #event.enchant_randomly rng matches 20 run return run item modify entity @s container.19 events:enchant_item
execute if items entity @s container.20 * if score #event.enchant_randomly rng matches 21 run return run item modify entity @s container.20 events:enchant_item
execute if items entity @s container.21 * if score #event.enchant_randomly rng matches 22 run return run item modify entity @s container.21 events:enchant_item
execute if items entity @s container.22 * if score #event.enchant_randomly rng matches 23 run return run item modify entity @s container.22 events:enchant_item
execute if items entity @s container.23 * if score #event.enchant_randomly rng matches 24 run return run item modify entity @s container.23 events:enchant_item
execute if items entity @s container.24 * if score #event.enchant_randomly rng matches 25 run return run item modify entity @s container.24 events:enchant_item
execute if items entity @s container.25 * if score #event.enchant_randomly rng matches 26 run return run item modify entity @s container.25 events:enchant_item
execute if items entity @s container.26 * if score #event.enchant_randomly rng matches 27 run return run item modify entity @s container.26 events:enchant_item
execute if items entity @s container.27 * if score #event.enchant_randomly rng matches 28 run return run item modify entity @s container.27 events:enchant_item
execute if items entity @s container.28 * if score #event.enchant_randomly rng matches 29 run return run item modify entity @s container.28 events:enchant_item
execute if items entity @s container.29 * if score #event.enchant_randomly rng matches 30 run return run item modify entity @s container.29 events:enchant_item
execute if items entity @s container.30 * if score #event.enchant_randomly rng matches 31 run return run item modify entity @s container.30 events:enchant_item
execute if items entity @s container.31 * if score #event.enchant_randomly rng matches 32 run return run item modify entity @s container.31 events:enchant_item
execute if items entity @s container.32 * if score #event.enchant_randomly rng matches 33 run return run item modify entity @s container.32 events:enchant_item
execute if items entity @s container.33 * if score #event.enchant_randomly rng matches 34 run return run item modify entity @s container.33 events:enchant_item
execute if items entity @s container.34 * if score #event.enchant_randomly rng matches 35 run return run item modify entity @s container.34 events:enchant_item
execute if items entity @s container.35 * if score #event.enchant_randomly rng matches 36 run return run item modify entity @s container.35 events:enchant_item

function events:event/27_enchant_randomly/enchant