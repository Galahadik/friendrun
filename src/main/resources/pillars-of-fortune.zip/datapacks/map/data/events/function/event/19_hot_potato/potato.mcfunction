execute unless entity @a[tag=event.get_potato,tag=alive] run return run function events:event/19_hot_potato/player_died

scoreboard players remove $event.hot_potato timer 1

execute if score $event.hot_potato timer matches 30.. run title @a actionbar [{text:"Картошка взорвется через ",color:green},{score:{name:"$event.hot_potato",objective:"timer"},italic:true,bold:true,color:green}]
execute if score $event.hot_potato timer matches 6..29 run title @a actionbar [{text:"Картошка взорвется через ",color:green},{score:{name:"$event.hot_potato",objective:"timer"},italic:true,bold:true,color:yellow}]
execute if score $event.hot_potato timer matches ..5 run title @a actionbar [{text:"Картошка взорвется через ",color:green},{score:{name:"$event.hot_potato",objective:"timer"},italic:true,bold:true,color:red}]

execute if score $event.hot_potato timer matches 1..5 as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.2


title @a[tag=event.get_potato] title ""
title @a[tag=event.get_potato] subtitle {text:"У вас горячая картошка!",color:dark_red}

item replace entity @a[tag=event.get_potato] armor.head with tnt[enchantments={binding_curse:1},custom_data={hot_potato:true}] 1
item replace entity @a[tag=event.give_potato] armor.head with air 1
tag @a remove event.give_potato

execute if score $event.hot_potato timer matches ..0 run execute as @a[tag=event.get_potato,tag=alive] at @s run return run function events:event/19_hot_potato/potato_explosion
execute if score $event.hot_potato timer matches 1.. run schedule function events:event/19_hot_potato/potato 1s