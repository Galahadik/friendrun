execute if data storage minecraft:map {events:{events:["no_void_death"]}} run return run function events:random_event
execute if data storage minecraft:map {deathmatch_running:true} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Нет пустоте!",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Можно теперь не бояться пустоты","color":"green"}

data modify storage minecraft:map events.events append value "no_void_death"