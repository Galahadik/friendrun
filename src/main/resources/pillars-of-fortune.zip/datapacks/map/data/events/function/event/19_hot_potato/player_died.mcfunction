title @a reset

kill @e[type=item, nbt={Item:{id:"minecraft:written_book",components:{"minecraft:custom_data":{hot_potato:true}}}}]

tag @a remove target

tag @a remove event.get_potato
tag @a remove event.give_potato

schedule clear events:event/19_hot_potato/potato
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Событие закончилось! Игрок умер.",color:red}]