execute if data storage minecraft:map {modificators:{modificators:["peaceful"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Голод",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"На всех игроках голод","color":"green"}

effect give @a[tag=alive] minecraft:hunger 7 255 true