execute if data storage minecraft:settings {maps:{enable:false}} run return run function events:random_event
execute if data storage minecraft:settings {maps:{empty_maps:true}} if score #random_map rng matches 0 run return run function events:random_event
execute if data storage minecraft:settings {deathmatch_running:true} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Перемены",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Смена платформы","color":"green"}

fill 18 -64 -18 -18 -35 18 air replace #maps:all_maps

schedule function events:event/26_map_change/place 1t