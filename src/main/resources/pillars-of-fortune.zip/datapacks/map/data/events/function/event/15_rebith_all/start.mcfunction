execute if data storage minecraft:map {events:{events:["rebirth_all"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Реинкарнация?",color:green,bold:false}," ⚡"]
title @a subtitle {text:"Павших игроков возвращает к жизни",color:green}

execute if block 17 150 -19 minecraft:barrier run fill 24 150 -25 -25 150 24 air
fill -25 100 24 24 100 -25 air

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} as @a[tag=!alive] run function events:event/15_rebith_all/reive
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} as @a[tag=!alive] unless entity @s[tag=!team.alpha,tag=!team.beta,tag=!team.gamma,tag=!team.delta,tag=!team.omega] run function events:event/15_rebith_all/reive

execute if block 24 149 -25 minecraft:barrier run fill -25 150 24 24 150 -25 minecraft:barrier
fill -25 100 24 24 100 -25 barrier

data modify storage minecraft:map events.events append value "rebirth_all"