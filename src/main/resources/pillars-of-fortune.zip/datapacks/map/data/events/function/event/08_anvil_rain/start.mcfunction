title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Тяжелый дождь",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Дождь из наковален","color":"green"}

function events:event/08_anvil_rain/summon
schedule function events:event/08_anvil_rain/summon 4s append
schedule function events:event/08_anvil_rain/summon 8s append
schedule function events:event/08_anvil_rain/summon 12s append
schedule function events:event/08_anvil_rain/summon 16s append