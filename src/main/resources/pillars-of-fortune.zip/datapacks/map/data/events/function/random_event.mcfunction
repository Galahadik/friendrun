execute if data storage minecraft:settings {events:{activation_method:"timer"}} run schedule function events:random_event 60s replace

execute store result score #random_event rng run random value 1..28

# scoreboard players set #random_event rng 27

execute if score #random_event rng matches 1 run return run function events:event/01_kill_random_player/start
execute if score #random_event rng matches 2 run return run function events:event/02_random_items/start
execute if score #random_event rng matches 3 run return run function events:event/03_barrel/start
execute if score #random_event rng matches 4 run return run function events:event/04_spawn_random_mob/start
execute if score #random_event rng matches 5 run return run function events:event/05_hunger/start
execute if score #random_event rng matches 6 run return run function events:event/06_warden/start
execute if score #random_event rng matches 7 run return run function events:event/07_all_levitation/start
execute if score #random_event rng matches 8 run return run function events:event/08_anvil_rain/start
execute if score #random_event rng matches 9 run return run function events:event/09_no_void_death/start
execute if score #random_event rng matches 10 run return run function events:event/10_clear_all/start
execute if score #random_event rng matches 11 run return run function events:event/11_one_hp_allgame/start
execute if score #random_event rng matches 12 run return run function events:event/12_creeper_on_bat/start
execute if score #random_event rng matches 13 run return run function events:event/13_op_sword/start
execute if score #random_event rng matches 14 run return run function events:event/14_force_deathmatch/start
execute if score #random_event rng matches 15 run return run function events:event/15_rebith_all/start
execute if score #random_event rng matches 16 run return run function events:event/16_clear_gear/start
execute if score #random_event rng matches 17 run return run function events:event/17_tp_near_rand/start
execute if score #random_event rng matches 18 run return run function events:event/18_no_hunger/start
execute if score #random_event rng matches 19 run return run function events:event/19_hot_potato/start
execute if score #random_event rng matches 20 run return run function events:event/20_tnt_rain/start
execute if score #random_event rng matches 21 run return run function events:event/21_deadly_sun/start
execute if score #random_event rng matches 22 run return run function events:event/22_giant_warden/start
execute if score #random_event rng matches 23 run return run function events:event/23_remove_platform/start
execute if score #random_event rng matches 24 run return run function events:event/24_glowing/start
execute if score #random_event rng matches 25 run return run function events:event/25_arrow_rain/start
execute if score #random_event rng matches 26 run return run function events:event/26_map_change/start
execute if score #random_event rng matches 27 run return run function events:event/27_enchant_randomly/start
execute if score #random_event rng matches 28 run return run function events:event/28_last_write_life_die/start