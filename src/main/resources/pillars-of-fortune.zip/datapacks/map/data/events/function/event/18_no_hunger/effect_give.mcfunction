execute as @a[tag=alive] if data entity @s {foodSaturationLevel:1f} run effect give @s minecraft:saturation 1 0 true
execute as @a[tag=alive] if data entity @s {foodSaturationLevel:2f} run effect give @s minecraft:saturation 1 0 true
execute as @a[tag=alive] if data entity @s {foodSaturationLevel:0f} run effect give @s minecraft:saturation 2 0 true