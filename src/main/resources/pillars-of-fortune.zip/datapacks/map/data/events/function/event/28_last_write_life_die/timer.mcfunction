scoreboard players remove $event.last_write_life_die timer 1

execute as @a[scores={life=1..}] run function events:event/28_last_write_life_die/write

execute store result score #event.last_write_life_die settings if entity @a[tag=event.last_write_life_die]
execute if score #event.last_write_life_die settings matches ..1 run scoreboard players set $event.last_write_life_die timer 0

execute as @a[tag=event.last_write_life_die] if entity @s[tag=!alive] run tag @s remove event.last_write_life_die

execute if score $event.last_write_life_die timer matches 1.. run return run schedule function events:event/28_last_write_life_die/timer 1t
execute if score $event.last_write_life_die timer matches ..0 run return run function events:event/28_last_write_life_die/end