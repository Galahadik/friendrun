advancement revoke @s only events:hot_potato/give_potato
tag @s remove event.get_potato
tag @s add event.give_potato
effect give @s minecraft:resistance 5 1 true

title @s title ""
title @s subtitle {text:"Вы избавились от картошки",color:green}