execute store result score #event.random_mob rng run random value 1..53

execute if score #event.random_mob rng matches 1 run return run summon allay ^ ^1 ^3.5
execute if score #event.random_mob rng matches 2 run return run summon armadillo ~ ~ ~
execute if score #event.random_mob rng matches 3 run return run summon armor_stand ~ ~ ~
execute if score #event.random_mob rng matches 4 run return run summon axolotl ~ ~ ~
execute if score #event.random_mob rng matches 5 run return run summon bat ^ ^1 ^3.5
execute if score #event.random_mob rng matches 6 run return run summon bee ~ ~ ~
execute if score #event.random_mob rng matches 7 run return run summon camel ~ ~ ~
execute if score #event.random_mob rng matches 8 run return run summon camel_husk ~ ~ ~
execute if score #event.random_mob rng matches 9 run return run summon cat ~ ~ ~
execute if score #event.random_mob rng matches 10 run return run summon chicken ~ ~ ~
execute if score #event.random_mob rng matches 11 run return run summon cod ~ ~ ~
execute if score #event.random_mob rng matches 12 run return run summon copper_golem ~ ~ ~
execute if score #event.random_mob rng matches 13 run return run summon cow ~ ~ ~
execute if score #event.random_mob rng matches 14 run return run summon dolphin ~ ~ ~
execute if score #event.random_mob rng matches 15 run return run summon donkey ~ ~ ~
execute if score #event.random_mob rng matches 16 run return run summon fox ~ ~ ~
execute if score #event.random_mob rng matches 17 run return run summon frog ~ ~ ~
execute if score #event.random_mob rng matches 18 run return run summon glow_squid ~ ~ ~
execute if score #event.random_mob rng matches 19 run return run summon goat ~ ~ ~
execute if score #event.random_mob rng matches 20 run return run summon happy_ghast ^ ^1 ^5
execute if score #event.random_mob rng matches 21 run return run summon hoglin ~ ~ ~
execute if score #event.random_mob rng matches 22 run return run summon horse ~ ~ ~
execute if score #event.random_mob rng matches 23 run return run summon iron_golem ~ ~ ~
execute if score #event.random_mob rng matches 24 run return run summon llama ~ ~ ~
execute if score #event.random_mob rng matches 25 run return run summon mooshroom ~ ~ ~
execute if score #event.random_mob rng matches 26 run return run summon mule ~ ~ ~
execute if score #event.random_mob rng matches 27 run return run summon nautilus ~ ~ ~
execute if score #event.random_mob rng matches 28 run return run summon ocelot ~ ~ ~
execute if score #event.random_mob rng matches 29 run return run summon panda ~ ~ ~
execute if score #event.random_mob rng matches 30 run return run summon parrot ^ ^1 ^3.5
execute if score #event.random_mob rng matches 31 run return run summon pig ~ ~ ~
execute if score #event.random_mob rng matches 32 run return run summon piglin ~ ~ ~
execute if score #event.random_mob rng matches 33 run return run summon polar_bear ~ ~ ~
execute if score #event.random_mob rng matches 34 run return run summon pufferfish ~ ~ ~
execute if score #event.random_mob rng matches 35 run return run summon rabbit ~ ~ ~
execute if score #event.random_mob rng matches 36 run return run summon salmon ~ ~ ~
execute if score #event.random_mob rng matches 37 run return run summon sheep ~ ~ ~
execute if score #event.random_mob rng matches 38 run return run summon shulker ~ ~ ~
execute if score #event.random_mob rng matches 39 run return run summon skeleton_horse ~ ~ ~
execute if score #event.random_mob rng matches 40 run return run summon sniffer ~ ~ ~
execute if score #event.random_mob rng matches 41 run return run summon snow_golem ~ ~ ~
execute if score #event.random_mob rng matches 42 run return run summon squid ~ ~ ~
execute if score #event.random_mob rng matches 43 run return run summon strider ~ ~ ~
execute if score #event.random_mob rng matches 44 run return run summon tadpole ~ ~ ~
execute if score #event.random_mob rng matches 45 run return run summon trader_llama ~ ~ ~
execute if score #event.random_mob rng matches 46 run return run summon tropical_fish ~ ~ ~
execute if score #event.random_mob rng matches 47 run return run summon turtle ~ ~ ~
execute if score #event.random_mob rng matches 48 run return run summon villager ~ ~ ~
execute if score #event.random_mob rng matches 49 run return run summon wandering_trader ~ ~ ~
execute if score #event.random_mob rng matches 50 run return run summon wolf ~ ~ ~
execute if score #event.random_mob rng matches 51 run return run summon zombie_horse ~ ~ ~
execute if score #event.random_mob rng matches 52 run return run summon zombie_nautilus ~ ~ ~

execute if score #event.random_mob rng matches 53 run return run function events:event/04_spawn_random_mob/mobs/mannequin
execute if score #event.random_mob rng matches 54 run return run summon lightning_bolt ^ ^1 ^2.5
execute if score #event.random_mob rng matches 55 run return run summon tnt ~ ~ ~ {fuse:4s}
execute if score #event.random_mob rng matches 56 run return run summon wind_charge ~ ~ ~ {Motion:[0d, -1d, 0d]}
execute if score #event.random_mob rng matches 57 run return run summon end_crystal ~ ~ ~ {ShowBottom:false}