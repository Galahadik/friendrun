title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Горячая картошка",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Если не передать за 30 секунд, она взорвётся","color":"green"}

title @a times 0 5s 0

tag @a remove event.get_potato
tag @a remove event.give_potato

data modify storage minecraft:map events.events append value "hot_potato"

scoreboard players set $event.hot_potato timer 30

execute unless entity @a[tag=target,tag=alive] as @r[tag=alive] run function events:event/19_hot_potato/get_potato
execute if entity @a[tag=target,tag=alive] as @r[tag=target,tag=alive] run function events:event/19_hot_potato/get_potato
schedule function events:event/19_hot_potato/potato 1s