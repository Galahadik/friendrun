execute unless entity @a[tag=target,tag=alive] run tag @r[tag=alive,sort=random] add kill.event
execute if entity @a[tag=target,tag=alive] run tag @r[tag=alive,tag=target,sort=random] add kill.event
kill @r[tag=kill.event]
tag @r[tag=kill.event] remove alive
execute as @a[tag=kill.event] at @s run tellraw @a[tag=!kill.event] ["<",{text:"Столбы",color:gray},"> ",{selector:"@a[tag=kill.event]",color:gold},{text:" - ",color:dark_gray},{text:"Был выбран событием",color:green}]
execute as @a[tag=kill.event] at @s run tellraw @a[tag=kill.event] ["<",{text:"Столбы",color:gray},"> ",{text:"Вы были убиты событием",color:green}]
tag @a remove kill.event
tag @a remove target
