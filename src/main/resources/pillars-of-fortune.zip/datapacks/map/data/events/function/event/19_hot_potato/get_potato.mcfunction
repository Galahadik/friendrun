advancement revoke @s only events:hot_potato/get_potato
tag @s add event.get_potato

execute unless items entity @s armor.head tnt if items entity @s armor.head * run item replace entity @s player.crafting.0 from entity @s armor.head

effect give @s minecraft:weakness 1 255 true
effect give @s minecraft:resistance 5 255 true
tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"Игрок ",color:red},{selector:"@s",color:dark_red}," получил картошку"]]