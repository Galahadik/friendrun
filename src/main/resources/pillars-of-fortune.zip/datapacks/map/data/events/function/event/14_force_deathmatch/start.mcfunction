execute if data storage minecraft:map {events:{events:["force_deathmatch"]}} run return run function events:random_event
execute if data storage minecraft:map {deathmatch_running:true} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Часы спешат?",color:green,bold:false}," ⚡"]
title @a subtitle {text:"Через 5 секунд начнется дезматч",color:green}

scoreboard players set $event.force_deathmatch timer 5
schedule function events:event/14_force_deathmatch/timer 1s

schedule function settings:changes/game/fall_damage/disable 4s
schedule clear cmd:map/deathmatch/time_to_match

data modify storage minecraft:map events.events append value "force_deathmatch"