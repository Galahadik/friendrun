title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Нежданчик",color:green,bold:false}," ⚡"]
title @a subtitle {text:"Случайный моб возле игрока",color:green}

execute unless data storage minecraft:map {modificators:{modificators:["peaceful"]}} as @a[tag=alive,predicate=events:check_in_game_zone_all] at @s run function events:event/04_spawn_random_mob/spawn
execute if data storage minecraft:map {modificators:{modificators:["peaceful"]}} as @a[tag=alive,predicate=events:check_in_game_zone_all] at @s run function events:event/04_spawn_random_mob/spawn_peaceful