execute if data storage minecraft:map {modificators:{modificators:["peaceful"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Это БОМБА!",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Криперы в небе взрываются моментально","color":"green"}


execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
execute if data storage minecraft:map {deathmatch_running:true} run summon bat 0 128 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}

execute if data storage minecraft:map {deathmatch_running:true} run return fail


summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 120 0 {Tags:["eventMob"],Passengers:[{id:"minecraft:creeper",Fuse:1}]}

summon bat 5 -30 0 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 5 -30 0 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat -5 -30 0 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat -5 -30 0 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 -30 5 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 -30 5 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 -30 -5 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}
summon bat 0 -30 -5 {Passengers:[{id:"minecraft:creeper",Fuse:1}]}

tp @e[tag=eventMob] 0 75 0 facing entity @r[tag=alive]

tag @e[tag=eventMob,type=bat] remove eventMob