execute if score #random_map rng matches -1..0 run return run function events:random_event
execute if data storage minecraft:map {deathmatch_running:true} run return run function events:random_event


title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Уничтожение",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Удаление платформы снизу","color":"green"}

tp @a[predicate=events:check_on_floor] -3 -21 -10
setblock -3 -22 -10 minecraft:smooth_stone


execute if data storage minecraft:settings {gamemodes:{gamemode:"default"}} run spreadplayers 0 0 0 16 under 100 false @a[predicate=events:check_on_floor]
execute if data storage minecraft:settings {gamemodes:{gamemode:"teams"}} run spreadplayers 0 0 0 16 under 100 true @a[predicate=events:check_on_floor]


fill 20 -25 -20 -20 -64 20 air