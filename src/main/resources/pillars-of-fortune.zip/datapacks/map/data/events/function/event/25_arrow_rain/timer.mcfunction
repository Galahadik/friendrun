scoreboard players remove $event.arrow_rain timer 1

title @a actionbar [{text:"Дождь из стрел ",color:red},{text:" » ",color:gray,bold:true},{score:{name:"$event.arrow_rain",objective:timer}}]

execute if score $event.arrow_rain timer matches ..0 run return run function events:event/25_arrow_rain/end
schedule function events:event/25_arrow_rain/timer 1s