title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Обстрел!!!",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Дождь из стрел","color":"green"}

summon minecraft:armor_stand 0 0 0 {Invulnerable:true,Invisible:true,Tags:["event.arrow_rain1"]}
summon minecraft:armor_stand 0 0 0 {Invulnerable:true,Invisible:true,Tags:["event.arrow_rain2"]}
summon minecraft:armor_stand 0 0 0 {Invulnerable:true,Invisible:true,Tags:["event.arrow_rain3"]}


scoreboard players set $event.arrow_rain timer 61
schedule function events:event/25_arrow_rain/loop 1s
schedule function events:event/25_arrow_rain/loop2 1s
schedule function events:event/25_arrow_rain/loop3 1s
schedule function events:event/25_arrow_rain/timer 1s