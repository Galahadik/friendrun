execute as @e[type=armor_stand,tag=event.arrow_rain2] at @s run spreadplayers 0 0 0 23 false @s

execute if data storage minecraft:map {deathmatch_running:false} as @e[type=armor_stand,tag=event.arrow_rain2] at @s run summon arrow ~ 99 ~ {damage:4.5,Tags:["event.arrow_rain"]}
execute if data storage minecraft:map {deathmatch_running:true} as @e[type=armor_stand,tag=event.arrow_rain2] at @s run summon arrow ~ 149 ~ {damage:4.5,Tags:["event.arrow_rain"]}

schedule function events:event/25_arrow_rain/loop2 1t