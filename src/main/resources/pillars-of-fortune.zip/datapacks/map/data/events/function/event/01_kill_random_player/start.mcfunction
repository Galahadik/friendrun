title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Случайная смерть",color:green,bold:false}," ⚡"]
title @a subtitle [{"text":"Случайный игрок умрет через ","color":"green"},{"text":"10","color":"red","bold":true,"italic":true},{"text":" секунд","color":"green"}]

scoreboard players set $event.random_kill timer 10
schedule function events:event/01_kill_random_player/timer 1s