execute if data storage minecraft:map {deathmatch_running:false} as @a[tag=alive,predicate=events:anvil_rain/check_anvil_rain_event,predicate=events:check_in_game_zone] at @s run summon tnt ~ 98 ~ {fuse:100}
execute if data storage minecraft:map {deathmatch_running:false} as @a[tag=alive,predicate=!events:anvil_rain/check_anvil_rain_event,predicate=events:check_in_game_zone] at @s run summon tnt ~ ~45 ~ {fuse:100}


execute if data storage minecraft:map {deathmatch_running:true} as @a[tag=alive,predicate=events:check_in_game_zone_deathmatch] at @s run summon tnt ~ 149 ~ {fuse:85}