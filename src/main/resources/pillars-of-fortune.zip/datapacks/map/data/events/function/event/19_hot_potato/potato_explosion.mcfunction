clear @s tnt[minecraft:custom_data={hot_potato:true}]
damage @s 10000 minecraft:explosion

execute at @r[tag=event.get_potato,predicate=events:check_in_game_zone] run summon tnt ~ ~ ~ {explosion_power:1.35,fuse:0s}

execute at @s run playsound entity.generic.explode hostile @a ~ ~ ~ 1000000

tag @s remove event.get_potato
title @a reset

tag @a remove target