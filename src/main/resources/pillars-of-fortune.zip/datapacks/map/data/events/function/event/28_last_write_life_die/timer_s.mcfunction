scoreboard players remove $event.last_write_life_die.s timer 1

execute if score $event.last_write_life_die.s timer matches 16.. run title @a actionbar [{text:"До конца события",color:green},{text:" » ",color:gray},{score:{name:"$event.last_write_life_die.s",objective:"timer"},color:green}," секунд"]
execute if score $event.last_write_life_die.s timer matches 6..15 run title @a actionbar [{text:"До конца события",color:green},{text:" » ",color:gray},{score:{name:"$event.last_write_life_die.s",objective:"timer"},color:yellow}," секунд"]
execute if score $event.last_write_life_die.s timer matches ..5 run title @a actionbar [{text:"До конца события",color:green},{text:" » ",color:gray},{score:{name:"$event.last_write_life_die.s",objective:"timer"},color:red}," секунд"]
execute if score $event.last_write_life_die.s timer matches ..5 as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~ 0.25

execute if score $event.last_write_life_die.s timer matches 1.. run schedule function events:event/28_last_write_life_die/timer_s 1s