execute if data storage minecraft:map {events:{events:["glowing"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Да будет свет",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Все игроки светятся весь матч","color":"green"}

function events:event/24_glowing/effect

data modify storage minecraft:map events.events append value "glowing"