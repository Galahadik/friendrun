execute as @a[tag=event.tp_player] if entity @s[tag=team.alpha] run return run tag @r[tag=!team.alpha,tag=alive,tag=!event.tp_player] add event.tp_rand_player

execute as @a[tag=event.tp_player] if entity @s[tag=team.beta] run return run tag @r[tag=!team.omega,tag=alive,tag=!event.tp_player] add event.tp_rand_player

execute as @a[tag=event.tp_player] if entity @s[tag=team.gamma] run return run tag @r[tag=!team.gamma,tag=alive,tag=!event.tp_player] add event.tp_rand_player

execute as @a[tag=event.tp_player] if entity @s[tag=team.delta] run return run tag @r[tag=!team.delta,tag=alive,tag=!event.tp_player] add event.tp_rand_player

execute as @a[tag=event.tp_player] if entity @s[tag=team.omega] run return run tag @r[tag=!team.omega,tag=alive,tag=!event.tp_player] add event.tp_rand_player