title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Бочка",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Бочка с предметами","color":"green"}

execute store result score #random_barrel rng run random value 1..3

execute if score #random_barrel rng matches 1 run setblock 0 60 0 minecraft:barrel[facing=down]{LootTable:"items:events/03_barrel/01_shoot_pack"}
execute if score #random_barrel rng matches 1 run return run tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"В бочке: Лук и 12 стрел",color:green}]


execute if score #random_barrel rng matches 2 run setblock 0 60 0 minecraft:barrel[facing=down]{LootTable:"items:events/03_barrel/02_fly_pack"}
execute if score #random_barrel rng matches 2 run return run tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"В бочке: Элитры и 1-2 фейерверка",color:green}]


execute if score #random_barrel rng matches 3 run setblock 0 60 0 minecraft:barrel[facing=down]{LootTable:"items:events/03_barrel/03_mace_wind_charge_pack"}
execute if score #random_barrel rng matches 3 run return run tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"В бочке: ",color:green},{text:"Ветренная Булава",color:blue,underlined:true,hover_event:{action:"show_text",value:{text:"Зачарованная булава на \"Порыв ветра\" 15 ур.\nВсего на 5 прочности.",color:gray}}}," и 1-5 зарядов ветра."]]