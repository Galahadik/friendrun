tag @s add alive
scoreboard players set @s canGetItems 1

effect clear @s

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run team join player @s

attribute @s max_health modifier add rebirth -4 add_value
execute if data storage minecraft:map {modificators:{modificators:["without_jumps"]}} run function modificators:modificator/without_jumps/disable_jumps
execute if data storage minecraft:map {events:{events:["1_hp"]}} as @s run attribute @s minecraft:max_health base set 1

effect give @s minecraft:saturation 1 255 true
effect give @s minecraft:resistance 10 255 true

spreadplayers 0.0 0.0 1 27 under 100 false @s
gamemode survival @s