execute if data storage minecraft:settings {events:{sun_burning_event:false}} run return run function events:random_event
execute if data storage minecraft:map {events:{sun_damage:true}} run return run function events:random_event
execute if data storage minecraft:map {modificators:{modificator:["masquerade"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Аномальная жара",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Вы получаете урон находясь под солнцем","color":"green"}

tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Чтобы избежать урона, наденьте шлем, используйте эффект огнестойкости или встаньте под/в блок.",color:gray}]

execute as @a[tag=alive] at @s if predicate events:check_in_game_zone_all if predicate events:sun_damage_blocks_check run setblock ~ ~3 ~ smooth_stone

data merge storage minecraft:map {events:{sun_damage:true}}