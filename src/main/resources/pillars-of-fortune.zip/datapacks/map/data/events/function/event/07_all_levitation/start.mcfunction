title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"5 минут полет нормальный",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Всем игрокам выдана левитация","color":"green"}

effect give @a[tag=alive] minecraft:levitation 18 4 true