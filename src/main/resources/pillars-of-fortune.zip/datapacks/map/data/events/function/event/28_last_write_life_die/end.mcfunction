execute store result score #event.last_write_life_die settings if entity @a[tag=event.last_write_life_die]


execute if score #event.last_write_life_die settings matches 2.. run tellraw @a ["<",{text:"Столбы",color:gold},"> ",{selector:"@a[tag=event.last_write_life_die]",color:"aqua"},{text:" — ",color:dark_gray},{text:"Не ввели команду, за что и были убиты!",color:gray}]
execute if score #event.last_write_life_die settings matches 1 run tellraw @a ["<",{text:"Столбы",color:gold},"> ",{selector:"@a[tag=event.last_write_life_die]",color:"aqua"},{text:" — ",color:dark_gray},{text:"Был последним, кто ввел команду, за что был убит!",color:gray}]
execute if score #event.last_write_life_die settings matches 0 run tellraw @a ["<",{text:"Столбы",color:gold},"> ",{text:"Никто не был последним.",color:gray}]

kill @a[tag=event.last_write_life_die]
tellraw @a[tag=event.last_write_life_die] ["<",{text:"Столбы",color:gold},"> ",{text:"Вы били убиты за то что не выполнили либо провалили условие события!",color:dark_gray}]

tag @a remove event.last_write_life_die

scoreboard objectives remove life