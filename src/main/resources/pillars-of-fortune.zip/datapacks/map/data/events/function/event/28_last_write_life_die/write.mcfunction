tag @s remove event.last_write_life_die
tellraw @a ["<",{text:"Столбы",color:gold},"> ",{selector:"@s",color:"aqua"},{text:" — ",color:dark_gray},{text:"справился!",color:"green"}]
scoreboard players reset @s life