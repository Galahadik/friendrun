execute as @a at @s if predicate events:fall_void/check_in_void run effect give @s minecraft:slow_falling 18 4 true
execute as @a at @s if predicate events:fall_void/check_in_void run tp @s ~ 96 ~