execute if data storage minecraft:map {events:{events:["no_hunger"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Плотный завтрак",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Всем игрокам выданы положительные эффекты","color":"green"}

effect give @a[tag=alive] minecraft:regeneration 15 255 true
effect give @a[tag=alive] minecraft:saturation 1 255 true
effect give @a[tag=alive] minecraft:resistance 15 255 true
effect give @a[tag=alive] minecraft:slow_falling 15 0 true

data modify storage minecraft:map events.events append value "no_hunger"