# validation: disable

summon item_display ~ ~-1 ~ {Tags:["event.random_mobs"]}
loot replace entity @n[type=item_display,tag=event.random_mobs] container.0 kill @s
summon mannequin ~ ~ ~ {Tags:["event.random_mobs"],hide_description:true,CustomNameVisible:true,active_effects:[{id:"minecraft:resistance",duration:10s,amplifier:255}]}

execute if entity @s[team=player] run team join player @n[tag=event.random_mobs,type=mannequin]

execute if entity @s[team=Alpha] run team join Alpha @n[tag=event.random_mobs,type=mannequin]
execute if entity @s[team=Beta] run team join Beta @n[tag=event.random_mobs,type=mannequin]
execute if entity @s[team=Delta] run team join Delta @n[tag=event.random_mobs,type=mannequin]
execute if entity @s[team=Gamma] run team join Gamma @n[tag=event.random_mobs,type=mannequin]
execute if entity @s[team=Omega] run team join Omega @n[tag=event.random_mobs,type=mannequin]

data modify entity @n[type=mannequin,tag=event.random_mobs] equipment set from entity @s equipment
data modify entity @n[type=mannequin,tag=event.random_mobs] equipment.mainhand set from entity @s SelectedItem

rotate @n[tag=event.random_mobs,type=mannequin] facing entity @r[distance=..15,tag=alive]

data modify entity @n[tag=event.random_mobs,type=mannequin] profile.id set from entity @s UUID

data modify entity @n[tag=event.random_mobs,type=mannequin] CustomName set from entity @n[type=item_display,tag=event.random_mobs] item.components."minecraft:profile".name

kill @n[type=item_display,tag=event.random_mobs]