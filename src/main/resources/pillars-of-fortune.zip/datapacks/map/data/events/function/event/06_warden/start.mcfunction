execute if data storage minecraft:map {modificators:{modificators:["peaceful"]}} run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Хранитель",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"В случайной точке карты появился хранитель","color":"green"}

fill 24 150 -25 -25 150 24 air
fill -25 100 24 24 100 -25 air

summon minecraft:warden 0 150 0 {Tags:["eventMob"],PersistenceRequired:1b,Brain:{memories:{"minecraft:dig_cooldown":{value:{},ttl:1200L}}}}
spreadplayers 0.0 0.0 1 27 under 111 false @e[tag=eventMob]
tag @e[tag=eventMob,type=minecraft:warden] remove eventMob

fill -25 150 24 24 150 -25 minecraft:barrier
fill -25 100 24 24 100 -25 barrier