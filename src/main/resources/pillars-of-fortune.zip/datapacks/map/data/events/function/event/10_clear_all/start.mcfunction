title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Уборщик",color:green,bold:false}," ⚡"]

execute store result score #event.clear rng run random value 1..3

clear @a[tag=alive]
execute if score #event.clear rng matches 1 run return run title @a subtitle {"text":"Очистка предметов игроков","color":"green"}

kill @e[type=minecraft:item]
execute if score #event.clear rng matches 2 run return run title @a subtitle {"text":"Очистка предметов","color":"green"}

kill @e[type=!player]
execute if score #event.clear rng matches 3 run return run title @a subtitle {"text":"Очистка предметов и мобов","color":"green"}
