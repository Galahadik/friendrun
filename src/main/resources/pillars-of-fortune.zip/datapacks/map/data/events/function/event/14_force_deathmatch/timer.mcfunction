scoreboard players remove $event.force_deathmatch timer 1

title @a actionbar [{text:"До события",color:green},{text:" » ",color:gray},{score:{name:"$event.force_deathmatch",objective:"timer"},color:red}," секунд"]

execute if score $event.force_deathmatch timer matches ..0 run return run function events:event/14_force_deathmatch/timer_end
execute if score $event.force_deathmatch timer matches 1.. run schedule function events:event/14_force_deathmatch/timer 1s