execute as @r[tag=alive] run tag @s add event.tp_player

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run tag @r[tag=alive,tag=!event.tp_player] add event.tp_rand_player

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run function events:event/17_tp_near_rand/tags_give

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Телепортация",color:green,bold:false}," ⚡"]

title @a subtitle [{"selector":"@a[tag=event.tp_player]","color":"gold"},{"text":" телепортируется к игроку","color":"green"}]

tp @r[tag=event.tp_player] @r[tag=event.tp_rand_player]

tag @a remove event.tp_player
tag @a remove event.tp_rand_player