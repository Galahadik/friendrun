title @a title {"text":"Бомбардировка","color":"green"}
title @a subtitle {"text":"Дождь из динамита","color":"green"}

tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Событие начнется через 5 секунд.",color:gray}]

schedule function events:event/20_tnt_rain/tnt_summon 5s append
schedule function events:event/20_tnt_rain/tnt_summon 10s append
schedule function events:event/20_tnt_rain/tnt_summon 15s append