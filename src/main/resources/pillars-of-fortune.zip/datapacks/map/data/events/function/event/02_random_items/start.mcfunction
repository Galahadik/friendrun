title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Случайные предметы",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Вам выдали инвентарь предметов","color":"green"}

execute if data storage minecraft:settings {give_items_on_floor:false} run data merge storage minecraft:temp {give_items_on_floor:false}
execute if data storage minecraft:settings {give_items_on_floor:false} run data merge storage minecraft:settings {give_items_on_floor:true}

scoreboard players set #items_give_count .temp 36
function cmd:give_items/start

execute if data storage minecraft:temp {give_items_on_floor:false} run data merge storage minecraft:settings {give_items_on_floor:false}

data remove storage minecraft:temp give_items_on_floor