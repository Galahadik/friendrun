title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Растяпа",color:green,bold:false}," ⚡"]
title @a subtitle {"text":"Вы потеряли броню и предметы в руке","color":"green"}

item replace entity @a weapon.offhand with air
item replace entity @a weapon.mainhand with air

item replace entity @a armor.head with air
item replace entity @a armor.chest with air
item replace entity @a armor.legs with air
item replace entity @a armor.feet with air