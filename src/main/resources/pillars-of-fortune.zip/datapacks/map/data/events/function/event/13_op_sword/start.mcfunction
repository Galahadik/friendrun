execute unless entity @a[tag=target,tag=alive] run tag @r[tag=alive] add event.op_sword
execute if entity @a[tag=target,tag=alive] run tag @r[tag=alive,tag=target] add event.op_sword

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Экскалибур?",color:green,bold:false}," ⚡"]
execute if data storage minecraft:settings {events:{who_got_op_sword:false}} run title @a subtitle {text:"Случайный игрок получает меч на 1 удар",color:green}
execute if data storage minecraft:settings {events:{who_got_op_sword:true}} run title @a subtitle [{selector:"@a[tag=event.op_sword]",color:gold},{text:" получает меч на 1 удар",color:green}]

execute as @r[tag=event.op_sword] run function items:events/op_sword

tag @a remove event.op_sword
tag @a remove target