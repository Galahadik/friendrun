execute if score #players_count.alive settings matches 2 run return run function events:random_event

title @a title [{text:"⚡ ",color:yellow,bold:true},{text:"Магия жизни",color:green,bold:false}," ⚡"]
title @a subtitle [{"text":"Кто последний напишет ",color:green},{text:"/trigger life",color:yellow,bold:true}," — умрет"]

tellraw @a ["<",{text:"Столбы",color:gold},"> ",[{text:"Кто последний введет команду ",color:gray},{text:"/trigger life",color:yellow,bold:true}," — умрет. Если по истечении 30-секундного таймера никто не введёт команду, то все, кто её не ввёл, умрут."]]

scoreboard objectives add life trigger
scoreboard players enable @a[tag=alive] life
tag @a[tag=alive] add event.last_write_life_die

scoreboard players set $event.last_write_life_die timer 601
scoreboard players set $event.last_write_life_die.s timer 31

function events:event/28_last_write_life_die/timer
function events:event/28_last_write_life_die/timer_s