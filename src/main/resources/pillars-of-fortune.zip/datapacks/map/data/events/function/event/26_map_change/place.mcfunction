data merge storage temp {disable_empty:true}
function maps:random_map
data remove storage minecraft:temp disable_empty