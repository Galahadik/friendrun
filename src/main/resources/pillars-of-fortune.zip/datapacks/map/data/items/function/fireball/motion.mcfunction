execute positioned 0.0 0.0 0.0 run tp @s ^ ^ ^0.1
data modify storage temp Motion set from entity @s Pos
tp @s ~ ~ ~
data modify entity @s Motion set from storage temp Motion

tag @s add motion