summon minecraft:fireball ~ ~0.5 ~ {Tags:["player"],ExplosionPower:3}
kill @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_data":{fireball:1b}}}},sort=nearest,limit=1]
