clear @s written_book[custom_data={lobby_item:true}]
scoreboard players reset @s info

kill @e[type=item, nbt={Item:{id:"minecraft:written_book",components:{"minecraft:custom_data":{lobby_item:true}}}}]

execute as @s[nbt=!{Inventory:[{tag:{lobby_item:true}}]}] run give @s minecraft:written_book[custom_data={lobby_item:true},written_book_content={author:"Карта",title:"Особенности карты",generation:1,pages:[ \
["",{text:"1. ",color:dark_gray},{text:"Кастомные Крафты",color:gold},"\n\nНезеритовую броню/инструменты теперь можно скрафтить в верстаке, как и другие. Удочку с (морковкой/грибом) теперь можно разобрать в сетке крафта, получив обратно обычную удочку."], \
    [{text:"", color:white}, {text:"1.1 ",color:dark_gray}, {text:"Рецепты",color:gold}, {text:" (1/1)\n",color:dark_gray}, \
    {text:"Удочки:\n   ",color:black}, \
    {atlas:items,sprite:"item/carrot_on_a_stick"}," ",{atlas:gui,sprite:"container/villager/trade_arrow"}," ",{atlas:items,sprite:"item/fishing_rod"}, "\n   ", \
    {atlas:items,sprite:"item/warped_fungus_on_a_stick"}," ",{atlas:gui,sprite:"container/villager/trade_arrow"}," ",{atlas:items,sprite:"item/fishing_rod"}, "\n\n", \
    {text:"Нез. броня/инстр.\n    ",color:black}, \
        {atlas:items,sprite:"item/netherite_ingot"}, "  ", {atlas:items,sprite:"item/netherite_ingot"}, "\n    ", \
        {atlas:items,sprite:"item/netherite_ingot"}, {atlas:items,sprite:"item/netherite_ingot"}, {atlas:items,sprite:"item/netherite_ingot"}, " ", {atlas:gui,sprite:"container/villager/trade_arrow"}, " ", {atlas:items,sprite:"item/netherite_chestplate"}, "\n    ", \
        {atlas:items,sprite:"item/netherite_ingot"}, {atlas:items,sprite:"item/netherite_ingot"}, {atlas:items,sprite:"item/netherite_ingot"}, "\n"], \
["",{text:"2. ",color:dark_gray},{text:"ИИ Монстров",color:gold},"\n\nРазозлённый моб атакует ближайшего игрока, а после его смерти — следующую ближайшую цель. Например, если игрок 1 ударит железного голема, но ближе стоит игрок 2, голем нападёт на игрока 2"], \
["",{text:"3. ",color:dark_gray},{text:"Головы Игроков",color:gold},"\n\nТеперь при смерти игроков с них выпадет их голова. Что может пригодиться для событий."], \
["",{text:"4. ",color:dark_gray},{text:"Мошочки",color:gold},"\n\nТеперь в мешочках могут появляться случайные предметы.\nШансы: 50%, 40%, 30%, 20% и 10%"],\
["",{text:"5. ",color:dark_gray},{text:"Динамит (Виды)",color:gold},"\n\nТеперь есть 3 разновидности динамита:\n\n1. Обычный.\n\n2. Нестабильный — взрывается при разрушении блока.\n\n3. Бросаемый — можно бросить, нажав ПКМ."], \
["",{text:"6. ",color:dark_gray},{text:"Огненые заряды",color:gold},"\n\nТеперь, помимо обычного огненного заряда, может выпасть метаемый огненный заряд. Его можно запустить, но будьте осторожны: есть шанс, что он взорвётся у вас в руках."], \
["",{text:"7. ",color:dark_gray},{text:"Кирпичи",color:gold},"\n   ",[{atlas:items,sprite:"item/brick",color:white}," ",{atlas:items,sprite:"item/nether_brick"}," ",{atlas:items,sprite:"item/resin_brick"}],"\nВсе из перечисленных кирпичей можно бросать. При использовании с умом они помогут отвлечь хранителя, взорвать кристалл или натравить нейтрального моба на противника (смотрите стр. 2)."]]}]