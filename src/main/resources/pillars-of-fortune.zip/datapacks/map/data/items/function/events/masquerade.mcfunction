give @s paper[item_model="minecraft:bone",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Хороший мальчик",color:light_purple}," ⚡"],lore=["",{text:"Призывает неубиваемую собаку,",color:gray,italic:false},{text:"когда кость одета на голову",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:end_rod",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Единорог",color:light_purple}," ⚡"],lore=["",{text:"Призывает неубиваемую собаку,",color:gray,italic:false},{text:"когда кость одета на голову",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:honeycomb_block",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Золотой ошейник",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор инструментов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:honey_block",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Яйцо",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор инструментов.",color:gray,italic:false},""],enchantments={binding_curse:1}]


give @s paper[item_model="minecraft:dragon_egg",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:cactus",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:chest",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:observer",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:spawner",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:red_bed",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:lightning_rod",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:glass",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:lead",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:ice",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:slime_block",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:flowering_azalea",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:decorated_pot",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:lime_banner",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:mangrove_roots",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:copper_golem_statue",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"123",color:light_purple}," ⚡"],lore=["",{text:"123",color:gray,italic:false},""],enchantments={binding_curse:1}]