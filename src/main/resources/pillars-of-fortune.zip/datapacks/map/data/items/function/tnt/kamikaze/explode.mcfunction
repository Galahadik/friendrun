advancement revoke @s only items:kamikaze_tnt

execute unless predicate events:check_in_game_zone_all run return fail
execute if entity @s[tag=!alive] run return fail
execute unless data storage minecraft:map {game_running:true} run return fail

summon tnt ~ ~ ~ {fuse:0,explosion_power:4}
execute if entity @s[tag=alive] run damage @s 1000000 explosion by @s