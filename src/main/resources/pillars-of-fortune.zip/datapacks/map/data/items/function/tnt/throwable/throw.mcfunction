summon tnt ^ ^ ^1 {fuse:40,Tags:["player"]}

playsound minecraft:entity.tnt.primed player @a ~ ~ ~ 0.5 0.5

kill @e[type=snowball,nbt={Item:{components:{"minecraft:custom_data":{tnt:1b}}}},sort=nearest,limit=1]