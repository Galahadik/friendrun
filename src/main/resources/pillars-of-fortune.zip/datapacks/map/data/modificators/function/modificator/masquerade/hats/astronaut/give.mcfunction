item replace entity @s armor.head with paper[item_model="minecraft:blue_stained_glass",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Космонавт",color:light_purple}," ⚡"],lore=["",{text:"У вас понижена гравитация.",color:gray,italic:false},""],enchantments={binding_curse:1}]

attribute @s minecraft:gravity base set 0.05
attribute @s minecraft:fall_damage_multiplier base set 0.75