item replace entity @s armor.head with paper[item_model="minecraft:flowering_azalea",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Цветок пустоты",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор инструментов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

item replace entity @s armor.chest with leather_chestplate[dyed_color=15513187]
item replace entity @s armor.legs with leather_leggings[dyed_color=11064360]
item replace entity @s armor.feet with leather_boots[dyed_color=11894459]

give @s dirt
give @s dandelion
give @s golden_dandelion
give @s poppy
give @s blue_orchid
give @s allium
give @s azure_bluet
give @s red_tulip
give @s orange_tulip
give @s white_tulip
give @s pink_tulip
give @s oxeye_daisy
give @s cornflower
give @s lily_of_the_valley
give @s torchflower
give @s cactus_flower
give @s open_eyeblossom
give @s wither_rose
give @s spore_blossom
give @s sunflower
give @s lilac
give @s rose_bush
give @s peony
give @s pitcher_plant