title @a[tag=alive] actionbar [{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"x0.5 размер игрока","color":"gold"}]
tellraw @a ["<",{"text":"Столбы","color":"gray"},"> ",{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"x0.5 размер игрока","color":"gold"}]

execute as @a[tag=alive] at @s run attribute @s minecraft:scale base set 0.5
execute as @a[tag=alive] at @s run attribute @s minecraft:jump_strength base set 0.390
execute as @a[tag=alive] at @s run attribute @s minecraft:movement_speed base set 0.08
execute as @a[tag=alive] at @s run attribute @s minecraft:safe_fall_distance base set 2.5
execute as @a[tag=alive] at @s run attribute @s minecraft:max_health base set 16
execute as @a[tag=alive] at @s run attribute @s minecraft:attack_speed base set 3.6
execute as @a[tag=alive] at @s run attribute @s minecraft:entity_interaction_range base set 2
execute as @a[tag=alive] at @s run attribute @s minecraft:block_interaction_range base set 2.35

data modify storage minecraft:map modificators.modificators append value "x0.5_scale"