execute store result score #modificator.random_heaths rng run random value 1..30

execute if score #modificator.random_heaths rng matches 1 as @a run attribute @s minecraft:max_health base set 1
execute if score #modificator.random_heaths rng matches 2 as @a run attribute @s minecraft:max_health base set 2
execute if score #modificator.random_heaths rng matches 3 as @a run attribute @s minecraft:max_health base set 3
execute if score #modificator.random_heaths rng matches 4 as @a run attribute @s minecraft:max_health base set 4
execute if score #modificator.random_heaths rng matches 5 as @a run attribute @s minecraft:max_health base set 5
execute if score #modificator.random_heaths rng matches 6 as @a run attribute @s minecraft:max_health base set 6
execute if score #modificator.random_heaths rng matches 7 as @a run attribute @s minecraft:max_health base set 7
execute if score #modificator.random_heaths rng matches 8 as @a run attribute @s minecraft:max_health base set 8
execute if score #modificator.random_heaths rng matches 9 as @a run attribute @s minecraft:max_health base set 9
execute if score #modificator.random_heaths rng matches 10 as @a run attribute @s minecraft:max_health base set 10

execute if score #modificator.random_heaths rng matches 11 as @a run attribute @s minecraft:max_health base set 11
execute if score #modificator.random_heaths rng matches 12 as @a run attribute @s minecraft:max_health base set 12
execute if score #modificator.random_heaths rng matches 13 as @a run attribute @s minecraft:max_health base set 13
execute if score #modificator.random_heaths rng matches 14 as @a run attribute @s minecraft:max_health base set 14
execute if score #modificator.random_heaths rng matches 15 as @a run attribute @s minecraft:max_health base set 15
execute if score #modificator.random_heaths rng matches 16 as @a run attribute @s minecraft:max_health base set 16
execute if score #modificator.random_heaths rng matches 17 as @a run attribute @s minecraft:max_health base set 17
execute if score #modificator.random_heaths rng matches 18 as @a run attribute @s minecraft:max_health base set 18
execute if score #modificator.random_heaths rng matches 19 as @a run attribute @s minecraft:max_health base set 19
execute if score #modificator.random_heaths rng matches 20 as @a run attribute @s minecraft:max_health base set 20

execute if score #modificator.random_heaths rng matches 21 as @a run attribute @s minecraft:max_health base set 21
execute if score #modificator.random_heaths rng matches 22 as @a run attribute @s minecraft:max_health base set 22
execute if score #modificator.random_heaths rng matches 23 as @a run attribute @s minecraft:max_health base set 23
execute if score #modificator.random_heaths rng matches 24 as @a run attribute @s minecraft:max_health base set 24
execute if score #modificator.random_heaths rng matches 25 as @a run attribute @s minecraft:max_health base set 25
execute if score #modificator.random_heaths rng matches 26 as @a run attribute @s minecraft:max_health base set 26
execute if score #modificator.random_heaths rng matches 27 as @a run attribute @s minecraft:max_health base set 27
execute if score #modificator.random_heaths rng matches 28 as @a run attribute @s minecraft:max_health base set 28
execute if score #modificator.random_heaths rng matches 29 as @a run attribute @s minecraft:max_health base set 29
execute if score #modificator.random_heaths rng matches 30 as @a run attribute @s minecraft:max_health base set 30

execute if score #modificator.random_heaths rng matches 31 as @a run attribute @s minecraft:max_health base set 31
execute if score #modificator.random_heaths rng matches 32 as @a run attribute @s minecraft:max_health base set 32
execute if score #modificator.random_heaths rng matches 33 as @a run attribute @s minecraft:max_health base set 33
execute if score #modificator.random_heaths rng matches 34 as @a run attribute @s minecraft:max_health base set 34
execute if score #modificator.random_heaths rng matches 35 as @a run attribute @s minecraft:max_health base set 35
execute if score #modificator.random_heaths rng matches 36 as @a run attribute @s minecraft:max_health base set 36
execute if score #modificator.random_heaths rng matches 37 as @a run attribute @s minecraft:max_health base set 37
execute if score #modificator.random_heaths rng matches 38 as @a run attribute @s minecraft:max_health base set 38
execute if score #modificator.random_heaths rng matches 39 as @a run attribute @s minecraft:max_health base set 39
execute if score #modificator.random_heaths rng matches 40 as @a run attribute @s minecraft:max_health base set 40
