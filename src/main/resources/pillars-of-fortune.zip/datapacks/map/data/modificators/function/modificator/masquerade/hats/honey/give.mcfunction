item replace entity @s armor.head with paper[item_model="minecraft:honey_block",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Bzz-zzz-Bzz Bzz-zz",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор ресурсов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s golden_hoe[max_damage=12]
give @s wheat_seeds 64
give @s rooted_dirt 4
give @s water_bucket
give @s crafting_table
give @s golden_carrot[!max_stack_size] 3
give @s golden_apple