item replace entity @s armor.head with paper[item_model="minecraft:ice",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Холод",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор ресурсов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

item replace entity @s armor.chest with minecraft:leather_chestplate[dyed_color=47083]
item replace entity @s armor.legs with minecraft:leather_leggings[dyed_color=47083]
item replace entity @s armor.feet with minecraft:leather_boots[dyed_color=47083,enchantments={frost_walker:2}]

give @s oak_boat
give @s ice 6
give @s snowball[!max_stack_size] 16