item replace entity @s armor.head with paper[item_model="minecraft:test_block",block_state={mode:accept},equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Весельчак",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор ресурсов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s creeper_spawn_egg 8