title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Старое PVP",color:gold}]
tellraw @a ["<",{text:"Столбы",color:"gray"},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Старое PVP",color:gold}]

execute as @a[tag=alive] at @s run attribute @s minecraft:attack_speed base set 25