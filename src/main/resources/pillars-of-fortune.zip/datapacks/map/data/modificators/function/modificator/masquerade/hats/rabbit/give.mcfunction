item replace entity @s armor.head with paper[item_model="minecraft:slime_block",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Кролик",color:light_purple}," ⚡"],lore=["",{text:"Вы можете взбираться на высоту 10 блоков",color:gray,italic:false},{text:"без прыжков. У вас пониженый урон от падения.",color:gray,italic:false},""],enchantments={binding_curse:1}]

attribute @s minecraft:step_height base set 10
attribute @s minecraft:fall_damage_multiplier base set 0.2