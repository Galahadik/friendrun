title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Быстрая граница",color:gold}]
tellraw @a ["<",{text:"Столбы",color:"gray"},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Быстрая граница",color:gold}]

worldborder set 1 225s
schedule clear cmd:map/deathmatch/time_to_match
schedule function cmd:map/deathmatch/time_to_match 180s

data modify storage minecraft:map modificators.modificators append value "faster_border"