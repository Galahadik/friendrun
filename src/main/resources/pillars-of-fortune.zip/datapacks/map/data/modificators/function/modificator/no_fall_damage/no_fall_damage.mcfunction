title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без урона от паделния",color:gold}]
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без урона от падения",color:gold}]

data modify storage minecraft:map modificators.modificators append value "no_fall_damage"

function settings:changes/game/fall_damage/disable