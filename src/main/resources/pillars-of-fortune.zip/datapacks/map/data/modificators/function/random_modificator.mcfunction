execute store result score #random_modificator rng run random value 1..20

# scoreboard players set #random_modificator rng 20

execute if score #random_modificator rng matches 1 run return run function modificators:modificator/no_knockback/no_knockback
execute if score #random_modificator rng matches 2 run return run function modificators:modificator/moon_gravity/moon_gravity
execute if score #random_modificator rng matches 3 run return run function modificators:modificator/x2_scale/x2_scale
execute if score #random_modificator rng matches 4 run return run function modificators:modificator/x0_5_scale/x0_5_scale
execute if score #random_modificator rng matches 5 run return run function modificators:modificator/random_hearths_one/random_hearths
execute if score #random_modificator rng matches 6 run return run function modificators:modificator/deadly_sun/deadly_sun
execute if score #random_modificator rng matches 7 run return run function modificators:modificator/sand_pillars/sand_pillars
execute if score #random_modificator rng matches 8 run return run function modificators:modificator/end_crystals_on_pillars/end_crystals_on_pillars
execute if score #random_modificator rng matches 9 run return run function modificators:modificator/random_hearths_all/random_hearths
execute if score #random_modificator rng matches 10 run return run function modificators:modificator/no_fall_damage/no_fall_damage
execute if score #random_modificator rng matches 11 run return run function modificators:modificator/old_pvp/old_pvp
execute if score #random_modificator rng matches 12 run return run function modificators:modificator/without_sprint/without_sprint
execute if score #random_modificator rng matches 13 run return run function modificators:modificator/faster_border/faster_border
execute if score #random_modificator rng matches 14 run return run function modificators:modificator/peaceful_gamemode/peaceful_gamemode
execute if score #random_modificator rng matches 15 run return run function modificators:modificator/without_jumps/without_jumps
execute if score #random_modificator rng matches 16 run return run function modificators:modificator/no_tile_drops/no_tile_drops
execute if score #random_modificator rng matches 17 run return run function modificators:modificator/no_natural_regeneration/no_natural_regeneration
execute if score #random_modificator rng matches 18 run return run function modificators:modificator/far_block_interaction_range/far_block_interaction_range
execute if score #random_modificator rng matches 19 run return run function modificators:modificator/masquerade/masquerade
execute if score #random_modificator rng matches 20 run return run function modificators:modificator/identical_items/identical_items
