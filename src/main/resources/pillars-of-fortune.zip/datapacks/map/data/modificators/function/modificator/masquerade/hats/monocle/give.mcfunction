item replace entity @s armor.head with paper[item_model="minecraft:lead",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Монокль",color:light_purple}," ⚡"],lore=["",{text:"Дает позорную трубу.",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s spyglass
loot give @s loot items:all_items/custom/tnt