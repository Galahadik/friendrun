title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Бесконечная досягаемость блоков",color:gold}]

tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Большая",color:blue,underlined:true,hover_event:{action:"show_text",value:{text:"20 блоков",color:gray}}},{text:" досягаемость блоков",color:gold}]

execute as @a[tag=alive] at @s run attribute @s minecraft:block_interaction_range base set 20