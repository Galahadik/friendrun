title @a[tag=alive] actionbar [{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"Случайные сердца для каждого","color":"gold"}]
tellraw @a ["<",{"text":"Столбы","color":"gray"},"> ",{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"Случайные сердца для каждого (у всех разное)","color":"gold"}]

execute as @a run function modificators:modificator/random_hearths_all/random

data modify storage minecraft:map modificators.modificators append value "random_hp_all"

scoreboard objectives setdisplay list