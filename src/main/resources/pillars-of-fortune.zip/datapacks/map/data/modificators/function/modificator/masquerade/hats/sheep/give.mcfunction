item replace entity @s armor.head with paper[item_model="minecraft:end_rod",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Единорог",color:light_purple}," ⚡"],lore=["",{text:"Дает пак предметов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s white_bundle[item_name={text:"Набор \"Единорог\"",color:green},bundle_contents=[\
{id:"sheep_spawn_egg",components:{entity_data:{id:"minecraft:sheep",CustomName:"jeb_"}}},\
{id:"minecraft:smooth_stone",count:8},{id:"minecraft:smooth_stone_slab",count:2},\
{id:"minecraft:oak_boat"},{id:"minecraft:sticky_piston"},{id:"minecraft:lever"},{id:"minecraft:end_rod"}]]