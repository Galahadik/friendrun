title @a[tag=alive] actionbar [{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"Случайные сердца для всех","color":"gold"}]
tellraw @a ["<",{"text":"Столбы","color":"gray"},"> ",{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"Случайные сердца для всех (у всех одинаковое)","color":"gold"}]

data modify storage minecraft:map modificators.modificators append value "random_hp_one"

function modificators:modificator/random_hearths_one/random