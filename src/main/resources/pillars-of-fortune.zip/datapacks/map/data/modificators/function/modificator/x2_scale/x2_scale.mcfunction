title @a[tag=alive] actionbar [{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"x2 размер игрока","color":"gold"}]
tellraw @a ["<",{"text":"Столбы","color":"gray"},"> ",{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ","bold":true,"color":"gray"},{"text":"x2 размер игрока","color":"gold"}]

execute as @a[tag=alive] at @s run attribute @s minecraft:scale base set 2
execute as @a[tag=alive] at @s run attribute @s minecraft:jump_strength base set 0.555
execute as @a[tag=alive] at @s run attribute @s minecraft:movement_speed base set 0.125
execute as @a[tag=alive] at @s run attribute @s minecraft:safe_fall_distance base set 5
execute as @a[tag=alive] at @s run attribute @s minecraft:max_health base set 40
execute as @a[tag=alive] at @s run attribute @s minecraft:attack_speed base set 5
execute as @a[tag=alive] at @s run attribute @s minecraft:entity_interaction_range base set 4.15
execute as @a[tag=alive] at @s run attribute @s minecraft:block_interaction_range base set 5.25

data modify storage minecraft:map modificators.modificators append value "x2_scale"
