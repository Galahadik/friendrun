title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Отключение дропа с блоков",color:gold}]

tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Отключение дропа с блоков",color:gold}]

gamerule mob_drops false
gamerule block_drops false
gamerule entity_drops false