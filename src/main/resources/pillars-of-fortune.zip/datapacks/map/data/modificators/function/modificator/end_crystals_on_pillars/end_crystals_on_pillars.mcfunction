title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Кристаллы энда",color:gold}]
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Кристаллы энда ",color:gold}]

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function modificators:modificator/end_crystals_on_pillars/solo_summon
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run function modificators:modificator/end_crystals_on_pillars/team_summon