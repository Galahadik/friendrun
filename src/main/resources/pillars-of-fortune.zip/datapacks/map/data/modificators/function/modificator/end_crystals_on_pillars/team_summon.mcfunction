execute if score #teams.teams_count settings matches 2.. run summon end_crystal -16 42 0 {ShowBottom:false}
execute if score #teams.teams_count settings matches 2.. run summon end_crystal 16 42 0 {ShowBottom:false}
execute if score #teams.teams_count settings matches 3.. run summon end_crystal 0 42 -16 {ShowBottom:false}
execute if score #teams.teams_count settings matches 4.. run summon end_crystal 0 42 16 {ShowBottom:false}
execute if score #teams.teams_count settings matches 5.. run summon end_crystal 0 42 0 {ShowBottom:false}
