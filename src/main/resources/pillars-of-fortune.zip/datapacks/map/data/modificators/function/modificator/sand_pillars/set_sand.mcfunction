execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"bridges"}}} run fill -17 37 17 17 37 -17 sandstone replace minecraft:bedrock

fill -17 39 -17 17 -58 17 sand replace minecraft:bedrock
fill -17 -59 -17 17 -59 17 sandstone replace minecraft:bedrock
