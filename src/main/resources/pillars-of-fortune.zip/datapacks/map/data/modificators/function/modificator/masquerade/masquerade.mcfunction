title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Шапочки",color:gold}]
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Шапочки",color:gold}]

data modify storage minecraft:map modificators.modificators append value "masquerade"

execute as @a[tag=alive] run function modificators:modificator/masquerade/give