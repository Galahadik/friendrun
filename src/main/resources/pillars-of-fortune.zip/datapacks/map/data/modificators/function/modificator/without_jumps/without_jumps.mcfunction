title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без прыжков",color:gold}]
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без прыжков",color:gold}]

execute as @a run function modificators:modificator/without_jumps/disable_jumps
data modify storage minecraft:map modificators.modificators append value "without_jumps"