item replace entity @s armor.head with paper[item_model="minecraft:anvil",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Толстяк",color:light_purple}," ⚡"],lore=["",{text:"Вы быстрее падаете и медленее,",color:gray,italic:false},{text:"но не получаете урон от падения",color:gray,italic:false},""],enchantments={binding_curse:1}]

attribute @s gravity base set 0.16
attribute @s movement_speed base set 0.075
attribute @s minecraft:safe_fall_distance base set 10000