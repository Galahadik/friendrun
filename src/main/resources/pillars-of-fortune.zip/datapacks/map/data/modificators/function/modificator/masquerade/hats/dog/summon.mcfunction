execute store result score #modificator.masquerade.dog rng run random value 1..9

summon wolf ~ ~ ~ {Tags:["masquerade.dog"],active_effects:[{id:"resistance",duration:2147483647,amplifier:255,show_particles:false},{id:"regeneration",duration:2147483647,amplifier:255,show_particles:false}]}
data modify entity @n[type=wolf,tag=masquerade.dog] Owner set from entity @s UUID

execute if score #modificator.masquerade.dog rng matches 1 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "pale"
execute if score #modificator.masquerade.dog rng matches 2 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "woods"
execute if score #modificator.masquerade.dog rng matches 3 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "ashen"
execute if score #modificator.masquerade.dog rng matches 4 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "black"
execute if score #modificator.masquerade.dog rng matches 5 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "chestnut"
execute if score #modificator.masquerade.dog rng matches 6 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "rusty"
execute if score #modificator.masquerade.dog rng matches 7 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "spotted"
execute if score #modificator.masquerade.dog rng matches 8 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "striped"
execute if score #modificator.masquerade.dog rng matches 9 run return run data modify entity @n[type=wolf,tag=masquerade.dog] variant set value "snowy"