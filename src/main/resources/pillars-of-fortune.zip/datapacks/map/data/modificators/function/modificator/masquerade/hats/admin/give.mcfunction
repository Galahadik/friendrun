item replace entity @s armor.head with paper[item_model="minecraft:command_block",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Кляп специально для тебя)",color:light_purple,obfuscated:true}," ⚡"],lore=["",{text:"дает админские блоки.",color:gray,italic:false},{text:"\"Самая бесполезная шляпа\"",color:gray,italic:false},""],enchantments={binding_curse:1}]

item replace entity @s armor.chest with debug_stick[equippable={slot:"chest"}]
item replace entity @s armor.legs with test_instance_block[equippable={slot:"legs"}]
item replace entity @s armor.feet with light[equippable={slot:"feet"},block_state={level:"0"}]

give @s command_block
give @s chain_command_block
give @s repeating_command_block
give @s command_block_minecart
give @s jigsaw
give @s structure_block
give @s structure_void
give @s barrier
give @s test_block[block_state={mode:"start"}]
give @s test_block[block_state={mode:"log"}]
give @s test_block[block_state={mode:"fail"}]
give @s test_block[block_state={mode:"accept"}]
give @s light[block_state={level:"15"}]
give @s light[block_state={level:"14"}]
give @s light[block_state={level:"13"}]
give @s light[block_state={level:"12"}]
give @s light[block_state={level:"11"}]
give @s light[block_state={level:"10"}]
give @s light[block_state={level:"9"}]
give @s light[block_state={level:"8"}]
give @s light[block_state={level:"7"}]
give @s light[block_state={level:"6"}]
give @s light[block_state={level:"5"}]
give @s light[block_state={level:"4"}]
give @s light[block_state={level:"3"}]
give @s light[block_state={level:"2"}]
give @s light[block_state={level:"1"}]