item replace entity @s armor.head with paper[item_model="minecraft:honeycomb_block",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Золотой ошейник",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор инструментов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

item replace entity @s armor.chest with minecraft:golden_chestplate[max_damage=2]
item replace entity @s armor.legs with minecraft:golden_leggings[max_damage=25]
item replace entity @s armor.feet with minecraft:golden_boots[max_damage=25]

give @s minecraft:golden_sword[max_damage=25]
give @s minecraft:golden_shovel[max_damage=25]
give @s minecraft:golden_hoe[max_damage=25]