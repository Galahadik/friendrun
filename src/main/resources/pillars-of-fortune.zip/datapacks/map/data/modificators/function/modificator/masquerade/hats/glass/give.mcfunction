item replace entity @s armor.head with paper[item_model="minecraft:glass",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Светлячок",color:light_purple}," ⚡"],lore=["",{text:"Вы светитесь.",color:gray,italic:false},""],enchantments={binding_curse:1}]

effect give @s glowing infinite 255 true