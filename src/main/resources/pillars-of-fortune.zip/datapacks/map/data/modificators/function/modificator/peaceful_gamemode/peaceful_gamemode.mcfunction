title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Мирный режим",color:gold}]
tellraw @a ["<",{text:"Столбы",color:"gray"},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Мирный режим",color:gold}]

difficulty peaceful

data modify storage minecraft:map modificators.modificators append value "peaceful"