item replace entity @s armor.head with paper[item_model="minecraft:spawner",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Клетка",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор инструментов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s paper[item_model="minecraft:trident",swing_animation={type:stab},item_name={text:"Затупленная вилка"},rarity=rare,lore=[{text:"Не лучшее оружие.",color:gray,italic:false}],attack_range={max_reach:3},enchantments={sharpness:1}]

give @s minecraft:trial_key[item_name={text:"Ключ"},lore=[{text:"незнаю от чего он.",color:gray,italic:false}],rarity=epic]

give @s wooden_pickaxe