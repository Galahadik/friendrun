title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Измененная гравитация",color:gold}]
tellraw @a ["<",{text:"Столбы",color:"gray"},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Измененная гравитация ",color:gold},{text:"(Урон от падения все еще существует)",color:gray}]

execute as @a[tag=alive] at @s run attribute @s minecraft:gravity base set 0.02
execute as @a[tag=alive] at @s run attribute @s minecraft:safe_fall_distance base set 5
execute as @a[tag=alive] at @s run attribute @s minecraft:fall_damage_multiplier base set 0.65