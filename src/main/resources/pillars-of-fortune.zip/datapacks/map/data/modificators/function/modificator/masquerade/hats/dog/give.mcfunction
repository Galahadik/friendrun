execute if items entity @s armor.head * run item replace entity @s player.crafting.0 from entity @s armor.head

item replace entity @s armor.head with paper[item_model="minecraft:bone",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Хороший мальчик",color:light_purple}," ⚡"],lore=["",{text:"Призывает неубиваемую собаку,",color:gray,italic:false},{text:"когда кость одета на голову",color:gray,italic:false},""],enchantments={binding_curse:1}]

execute at @s run function modificators:modificator/masquerade/hats/dog/summon