execute store result score #modificator.masquerade rng run random value 1..19

execute if score #modificator.masquerade rng matches 1 run return run function modificators:modificator/masquerade/hats/dog/give
execute if score #modificator.masquerade rng matches 2 run return run function modificators:modificator/masquerade/hats/sheep/give
execute if score #modificator.masquerade rng matches 3 run return run function modificators:modificator/masquerade/hats/gold/give
execute if score #modificator.masquerade rng matches 4 run return run function modificators:modificator/masquerade/hats/honey/give
execute if score #modificator.masquerade rng matches 5 run return run function modificators:modificator/masquerade/hats/admin/give
execute if score #modificator.masquerade rng matches 6 run return run function modificators:modificator/masquerade/hats/jailer/give
execute if score #modificator.masquerade rng matches 7 run return run function modificators:modificator/masquerade/hats/astronaut/give
execute if score #modificator.masquerade rng matches 8 run return run function modificators:modificator/masquerade/hats/endermite/give
execute if score #modificator.masquerade rng matches 9 run return run function modificators:modificator/masquerade/hats/ice/give
execute if score #modificator.masquerade rng matches 10 run return run function modificators:modificator/masquerade/hats/rabbit/give
execute if score #modificator.masquerade rng matches 11 run return run function modificators:modificator/masquerade/hats/talker/give
execute if score #modificator.masquerade rng matches 12 run return run function modificators:modificator/masquerade/hats/unhappy/give
execute if score #modificator.masquerade rng matches 13 run return run function modificators:modificator/masquerade/hats/happy/give
execute if score #modificator.masquerade rng matches 14 run return run function modificators:modificator/masquerade/hats/flower/give
execute if score #modificator.masquerade rng matches 15 run return run function modificators:modificator/masquerade/hats/storager/give
execute if score #modificator.masquerade rng matches 16 run return run function modificators:modificator/masquerade/hats/glass/give
execute if score #modificator.masquerade rng matches 17 run return run function modificators:modificator/masquerade/hats/aquarium/give
execute if score #modificator.masquerade rng matches 18 run return run function modificators:modificator/masquerade/hats/anvil/give
execute if score #modificator.masquerade rng matches 19 run return run function modificators:modificator/masquerade/hats/monocle/give