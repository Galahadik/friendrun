execute store result score #modificator.random_heaths rng run random value 1..20

execute if score #modificator.random_heaths rng matches 1 run return run attribute @s minecraft:max_health base set 1
execute if score #modificator.random_heaths rng matches 2 run return run attribute @s minecraft:max_health base set 2
execute if score #modificator.random_heaths rng matches 3 run return run attribute @s minecraft:max_health base set 3
execute if score #modificator.random_heaths rng matches 4 run return run attribute @s minecraft:max_health base set 4
execute if score #modificator.random_heaths rng matches 5 run return run attribute @s minecraft:max_health base set 5
execute if score #modificator.random_heaths rng matches 6 run return run attribute @s minecraft:max_health base set 6
execute if score #modificator.random_heaths rng matches 7 run return run attribute @s minecraft:max_health base set 7
execute if score #modificator.random_heaths rng matches 8 run return run attribute @s minecraft:max_health base set 8
execute if score #modificator.random_heaths rng matches 9 run return run attribute @s minecraft:max_health base set 9
execute if score #modificator.random_heaths rng matches 10 run return run attribute @s minecraft:max_health base set 10
execute if score #modificator.random_heaths rng matches 11 run return run attribute @s minecraft:max_health base set 11
execute if score #modificator.random_heaths rng matches 12 run return run attribute @s minecraft:max_health base set 12
execute if score #modificator.random_heaths rng matches 13 run return run attribute @s minecraft:max_health base set 13
execute if score #modificator.random_heaths rng matches 14 run return run attribute @s minecraft:max_health base set 14
execute if score #modificator.random_heaths rng matches 15 run return run attribute @s minecraft:max_health base set 15
execute if score #modificator.random_heaths rng matches 16 run return run attribute @s minecraft:max_health base set 16
execute if score #modificator.random_heaths rng matches 17 run return run attribute @s minecraft:max_health base set 17
execute if score #modificator.random_heaths rng matches 18 run return run attribute @s minecraft:max_health base set 18
execute if score #modificator.random_heaths rng matches 19 run return run attribute @s minecraft:max_health base set 19
execute if score #modificator.random_heaths rng matches 20 run return run attribute @s minecraft:max_health base set 20