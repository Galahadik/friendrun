title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без естественной регенерации",color:gold}]

tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без ",color:gold},{text:"естественной регенерации",color:blue,underlined:true,hover_event:{action:"show_text",value:{text:"Определяет может ли игрок восстанавливать\nздоровье, если его голод достаточен\nдля этого (не влияет на внешнее лечение).",color:gray}}}]

gamerule natural_health_regeneration false