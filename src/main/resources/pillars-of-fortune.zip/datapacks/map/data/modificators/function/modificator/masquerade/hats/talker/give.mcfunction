item replace entity @s armor.head with paper[item_model="minecraft:test_block",block_state={mode:log},equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Болтун",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор ресурсов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

loot give @s loot items:all_items/minecraft_packs/horn
give @s oak_sign 6
give @s map 2
give @s writable_book 3
loot give @s loot items:all_items/custom/music_disc