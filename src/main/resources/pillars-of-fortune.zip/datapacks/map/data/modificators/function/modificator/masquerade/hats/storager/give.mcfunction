item replace entity @s armor.head with paper[item_model="minecraft:ender_chest",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Хранитель семени",color:light_purple}," ⚡"],lore=["",{text:"Дает мешочки со случайным лутом.",color:gray,italic:false},""],enchantments={binding_curse:1}]

loot give @s loot items:all_items/minecraft_packs/bundle
loot give @s loot items:all_items/minecraft_packs/bundle
loot give @s loot items:all_items/minecraft_packs/bundle
loot give @s loot items:all_items/minecraft_packs/bundle
loot give @s loot items:all_items/minecraft_packs/bundle