item replace entity @s armor.head with paper[item_model="minecraft:light_blue_stained_glass",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Космонавт",color:light_purple}," ⚡"],lore=["",{text:"Вы моментально перестаете",color:gray,italic:false},{text:"гореть и не тонете в воде.",color:gray,italic:false},""],enchantments={binding_curse:1}]

attribute @s minecraft:burning_time base set 0
attribute @s minecraft:oxygen_bonus base set 10000