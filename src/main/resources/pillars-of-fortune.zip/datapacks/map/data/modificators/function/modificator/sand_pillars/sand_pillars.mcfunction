title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Песчаные столбы",color:gold}]
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Песчаные столбы",color:gold}]

function modificators:modificator/sand_pillars/set_sand