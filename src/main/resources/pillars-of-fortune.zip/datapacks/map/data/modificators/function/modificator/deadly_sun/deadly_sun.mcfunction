execute if data storage minecraft:settings {modificators:{sun_burning_modificator:false}} run return run function modificators:random_modificator

title @a[tag=alive] actionbar [{"text":"Игровой модификатор ","color":"yellow"},{"text":"» ",bold:true,color:gray},{"text":"Горение под солнцем","color":"gold"}]
tellraw @a ["<",{text:"Столбы",color:"gray"},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ","bold":true,"color":"gray"},{"text":"Горение под солнцем","color":"gold"}]

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} as @a[tag=alive] at @s run setblock ~ ~3 ~ minecraft:smooth_stone

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} as @a[tag=alive] at @s run fill ~-1 ~3 ~-1 ~1 ~3 ~1 smooth_stone

data merge storage minecraft:map {events:{sun_damage:true}}
