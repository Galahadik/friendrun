item replace entity @s armor.head with paper[item_model="minecraft:test_block",block_state={mode:fail},equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Помидор",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор ресурсов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs
loot give @s loot items:all_items/minecraft_packs/spawn_eggs