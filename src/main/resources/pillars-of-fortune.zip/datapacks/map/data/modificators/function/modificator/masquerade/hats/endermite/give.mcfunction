item replace entity @s armor.head with paper[item_model="minecraft:chorus_flower",equippable={slot:"head"},item_name=[{text:"⚡ ",color:yellow,bold:true},{text:"Эндермит",color:light_purple}," ⚡"],lore=["",{text:"Дает стартовый набор инструментов.",color:gray,italic:false},""],enchantments={binding_curse:1}]

give @s chorus_fruit 14
give @s ender_pearl 2