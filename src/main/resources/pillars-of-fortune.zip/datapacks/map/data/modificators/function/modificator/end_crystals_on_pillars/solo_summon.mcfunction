
execute if score #players_count settings matches 13.. run summon end_crystal 8 42 0 {ShowBottom:false}
execute if score #players_count settings matches 12.. run summon end_crystal -8 42 0 {ShowBottom:false}
execute if score #players_count settings matches 11.. run summon end_crystal 0 42 -8 {ShowBottom:false}
execute if score #players_count settings matches 10.. run summon end_crystal 0 42 8 {ShowBottom:false}
execute if score #players_count settings matches 9.. run summon end_crystal -11 42 11 {ShowBottom:false}
execute if score #players_count settings matches 8.. run summon end_crystal 11 42 -11 {ShowBottom:false}
execute if score #players_count settings matches 7.. run summon end_crystal 11 42 11 {ShowBottom:false}
execute if score #players_count settings matches 6.. run summon end_crystal -11 42 -11 {ShowBottom:false}
execute if score #players_count settings matches 5.. run summon end_crystal 0 42 0 {ShowBottom:false}
execute if score #players_count settings matches 4.. run summon end_crystal 0 42 16 {ShowBottom:false}
execute if score #players_count settings matches 3.. run summon end_crystal 0 42 -16 {ShowBottom:false}
execute if score #players_count settings matches 2.. run summon end_crystal 16 42 0 {ShowBottom:false}
execute if score #players_count settings matches 1.. run summon end_crystal -16 42 0 {ShowBottom:false}