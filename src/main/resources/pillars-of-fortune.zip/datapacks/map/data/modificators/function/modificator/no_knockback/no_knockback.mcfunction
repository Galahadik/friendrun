title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без отталкивания",color:gold}]

tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без отталкивания",color:gold}]

execute as @a[tag=alive] at @s run attribute @s minecraft:knockback_resistance base set 1
execute as @a[tag=alive] at @s run attribute @s minecraft:attack_knockback base set 0.000001

data modify storage minecraft:map modificators.modificators append value "no_knockback"