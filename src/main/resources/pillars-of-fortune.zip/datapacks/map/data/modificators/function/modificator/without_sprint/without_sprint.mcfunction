title @a[tag=alive] actionbar [{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без спринта",color:gold}]
tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Игровой модификатор ",color:yellow},{text:"» ",bold:true,color:gray},{text:"Без спринта",color:gold}]

data modify storage minecraft:map modificators.modificators append value "without_sprint"