fill -5 31 -90 -10 27 -90 air
fill -5 32 -92 -10 32 -92 minecraft:polished_blackstone_button
fill -5 32 -88 -10 32 -88 air