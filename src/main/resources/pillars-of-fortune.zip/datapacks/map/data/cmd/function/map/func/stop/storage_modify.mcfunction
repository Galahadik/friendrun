data merge storage minecraft:map {events:{events:[]}}
data merge storage minecraft:map {modificators:{modificators:[]}}
data merge storage minecraft:map {event_countdown:false}
data merge storage minecraft:map {events:{sun_damage:false}}
data merge storage minecraft:map {events:{hot_potato:false}}
data merge storage minecraft:map {events:{music:false}}
data merge storage minecraft:map {victory:false}
data merge storage minecraft:map {game_running:false}
data merge storage minecraft:map {deathmatch_running:false}
data merge storage minecraft:map {remove_barrier:false}

data merge storage minecraft:map {speedup_game:false}

execute if data storage minecraft:map {teams_count:1} run scoreboard players set #teams.teams_count settings 1
execute if data storage minecraft:map {teams_count:1} run data merge storage minecraft:map {teams_count:0}

data remove storage minecraft:temp disable_empty