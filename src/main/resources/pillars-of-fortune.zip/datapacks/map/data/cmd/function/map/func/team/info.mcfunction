tellraw @s ["<",[{strikethrough:true,text:"          "},{strikethrough:false,text:"<< Ваша Команда >>"},"          "],">"]
tellraw @s {text:"(Написать команде: \"/teammsg\")\n",color:gray}
$tellraw @a[team=$(team)] [{text:"   [",color:gray},{selector:"@s",color:green},"]"]