
execute if data storage minecraft:map {modificators:{modificators:["identical_items"]}} run data merge block 6 21 -87 {Items:[]}

scoreboard players set #item settings 0