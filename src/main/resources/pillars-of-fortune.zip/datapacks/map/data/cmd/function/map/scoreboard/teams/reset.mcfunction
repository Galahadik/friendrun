
scoreboard players reset scb.#01 scb.Teams
scoreboard players reset scb.#02 scb.Teams
scoreboard players reset scb.#03 scb.Teams
scoreboard players reset scb.#04 scb.Teams
scoreboard players reset scb.#05 scb.Teams
scoreboard players reset scb.#06 scb.Teams
scoreboard players reset scb.#07 scb.Teams
scoreboard players reset scb.#08 scb.Teams
scoreboard players reset scb.#09 scb.Teams
scoreboard players reset scb.#10 scb.Teams
scoreboard players reset scb.#11 scb.Teams
scoreboard players reset scb.#12 scb.Teams
scoreboard players reset scb.#13 scb.Teams
scoreboard players reset scb.#14 scb.Teams

scoreboard objectives setdisplay sidebar

team empty Alpha
team empty Beta
team empty Gamma
team empty Delta
team empty Omega

team join lobby @a