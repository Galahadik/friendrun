kill @e[tag=start_holo]
kill @e[tag=start_holo.interaction]

summon minecraft:text_display 22.9375 28.75 -98.5 {\
Tags:["lobby","start_holo"], \
Rotation:[90.0f, 10.0f], \
shadow:true,}

summon minecraft:interaction 24.0 28.75 -98.5 {response:true,height:1.75,width:3,Tags:["lobby","start_holo.interaction"],Rotation:[90.0f,0.0f]}