scoreboard players remove $deathmatch timer 1

title @a[tag=alive] actionbar [{"text":"Осталось ","color":"red"},{"text":"» ","color":"gray"},{score:{name:"$deathmatch",objective:"timer"},color:blue},{text:" секунд",color:red}]

execute if score $deathmatch timer matches ..0 run return run function cmd:map/deathmatch/match_start
execute if score $deathmatch timer matches 1.. run schedule function cmd:map/deathmatch/timer 1s