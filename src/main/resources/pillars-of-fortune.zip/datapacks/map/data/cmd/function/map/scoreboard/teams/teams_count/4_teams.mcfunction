function cmd:map/scoreboard/teams/setting {team:"Альфа",color:blue,scb:"01",count_alive:"#teams.alpha_count.alive"}
function cmd:map/scoreboard/teams/setting_players {team:Alpha,scb:"02"}
function cmd:map/scoreboard/teams/setting {team:"Бета",color:red,scb:"04",count_alive:"#teams.beta_count.alive"}
function cmd:map/scoreboard/teams/setting_players {team:Beta,scb:"05"}
function cmd:map/scoreboard/teams/setting {team:"Гамма",color:green,scb:"07",count_alive:"#teams.gamma_count.alive"}
function cmd:map/scoreboard/teams/setting_players {team:Gamma,scb:"08"}
function cmd:map/scoreboard/teams/setting {team:"Дельта",color:yellow,scb:"10",count_alive:"#teams.delta_count.alive"}
function cmd:map/scoreboard/teams/setting_players {team:Delta,scb:"11"}

scoreboard players display name scb.#03 scb.Teams ""
scoreboard players display name scb.#06 scb.Teams ""
scoreboard players display name scb.#09 scb.Teams ""
scoreboard players display name scb.#12 scb.Teams ""

scoreboard players display numberformat scb.#01 scb.Teams blank
scoreboard players display numberformat scb.#02 scb.Teams blank
scoreboard players display numberformat scb.#03 scb.Teams blank
scoreboard players display numberformat scb.#04 scb.Teams blank
scoreboard players display numberformat scb.#05 scb.Teams blank
scoreboard players display numberformat scb.#06 scb.Teams blank
scoreboard players display numberformat scb.#07 scb.Teams blank
scoreboard players display numberformat scb.#08 scb.Teams blank
scoreboard players display numberformat scb.#09 scb.Teams blank
scoreboard players display numberformat scb.#10 scb.Teams blank
scoreboard players display numberformat scb.#11 scb.Teams blank
scoreboard players display numberformat scb.#12 scb.Teams blank