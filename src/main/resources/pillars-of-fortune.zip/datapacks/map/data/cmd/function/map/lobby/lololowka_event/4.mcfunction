tellraw @a ["",{text:"<",color:gray},{text:"MrRaven___",color:gold},{text:"> ",color:gray},{text:"На этом всё."}]

playsound minecraft:entity.villager.ambient master @a 18 28 -103 100

schedule function cmd:map/lobby/lololowka_event/5 1s