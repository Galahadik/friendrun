execute if data storage map {game_running:true} run return fail

scoreboard players reset @a stop_pre_start.trigger
function cmd:map/func/team/pvp/disable
scoreboard players operation #players_count.old settings = #players_count settings

stopwatch create game_timer

data merge storage minecraft:map {game_running:true}
data merge storage minecraft:map {pre_start:false}
data merge storage minecraft:map {all_selected_team:false}

function cmd:map/stats/create
function cmd:map/player/remove_attributes
function cmd:map/teleportation/remove_tags

tag @a add alive
execute unless data storage minecraft:settings {gamemodes:{gamemode:teams}} run team join player @a
execute if data storage minecraft:settings {maps:{enable:true}} run function maps:random_map

scoreboard players set $teleport timer 0
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run function cmd:map/func/team/start

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function cmd:map/game/players_count

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function cmd:map/teleportation/solo/give_tags

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function cmd:map/teleportation/solo/summon

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function cmd:map/teleportation/solo/teleport

execute unless data storage minecraft:settings {gamemodes:{gamemode:teams}} run function cmd:map/stats/modify

spawnpoint @a 0 50 0
kill @e[tag=lobby]
clear @a
effect clear @a
gamemode survival @a
advancement revoke @a everything

xp set @a 30 levels
xp set @a 0 points

scoreboard players reset @a teams.join_alpha
scoreboard players reset @a teams.join_beta
scoreboard players reset @a teams.join_gamma
scoreboard players reset @a teams.join_delta
scoreboard players reset @a teams.join_omega
scoreboard players reset @a teams.join_cant
scoreboard players reset @a teams.join_random
scoreboard players reset @a teams.leave

schedule function cmd:map/func/remove_barrier 5s
fill -25 42 24 24 42 -25 minecraft:barrier

schedule function cmd:map/func/start_sound 10t

fill -25 100 24 24 100 -25 barrier

# DEATHMATCH
schedule function cmd:map/deathmatch/time_to_match 360s

effect give @a[tag=alive] minecraft:invisibility 10 255 true

# Ивенты

execute if data storage minecraft:settings {events:{activation_method:"timer"}} run schedule function events:random_event 60s

execute if data storage minecraft:settings {events:{activation_method:"button"}} if data storage minecraft:settings {events:{enable:true}} run setblock 0 60 0 minecraft:gold_block
execute if data storage minecraft:settings {events:{activation_method:"button"}} if data storage minecraft:settings {events:{enable:true}} run setblock 0 59 0 minecraft:polished_blackstone_button[face=ceiling]

execute as @a[tag=alive] at @s run scoreboard players set @s canGetItems 1
