execute unless score #items_give_timer settings matches ..0 if score #giveItems settings matches 1 store result bossbar minecraft:item.timer max run scoreboard players get #items_give_timer settings
execute if score #giveItems settings matches 1 store result bossbar minecraft:item.timer value run scoreboard players get #items_give_timer.Time settings

scoreboard players add #items_give_timer.Time settings 1
execute if score #items_give_timer.Time settings >= #items_give_timer settings run scoreboard players set #item settings 1
execute if score #items_give_timer.Time settings >= #items_give_timer settings run scoreboard players set #items_give_timer.Time settings 0

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run function cmd:map/game/running/team_running
execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function cmd:map/game/running/solo_running

# ADMIN
execute as @a[tag=ghost,predicate=!admin:player_ride] run function admin:fun/ride/funcs/dismount
execute as @a[scores={force_stop.trigger=1..}] run function admin:panel/funcs/force_stop

# ВЫДАЧА ПРЕДМЕТОВ
execute if score #item settings matches 1.. run function cmd:give_items/give

# Бросаемый огненный заряд
execute as @e[type=minecraft:snowball,nbt={Item:{components:{"minecraft:custom_data":{fireball:1b}}}}] at @s anchored eyes run function items:fireball/throw
execute as @e[type=fireball,tag=player,tag=!motion] at @s rotated as @p run function items:fireball/motion
execute as @e[type=snowball,nbt={Item:{components:{"minecraft:custom_data":{tnt:1b}}}}] at @s anchored eyes run function items:tnt/throwable/throw
execute as @e[type=tnt,tag=player,tag=!motion] at @s rotated as @p run function items:tnt/throwable/motion

# Ивенты
execute if data storage minecraft:map {event_countdown:false} if block 0 59 0 minecraft:polished_blackstone_button[powered=true] run function cmd:map/game/event_button

execute if data storage minecraft:map {events:{sun_damage:true}} run function events:event/21_deadly_sun/damage
execute if data storage minecraft:map {events:{events:["no_void_death"]}} run function events:event/09_no_void_death/fall_void
execute if data storage minecraft:map {events:{events:["no_hunger"]}} run function events:event/18_no_hunger/effect_give
execute if data storage minecraft:map {events:{events:["glowing"]}} run function events:event/24_glowing/effect
execute if data storage minecraft:settings {mobs:{burning:false}} run function settings:changes/game/mob_burning/no_burn_entity

# Модификаторы
execute if data storage minecraft:map {modificators:{modificators:["without_sprint"]}} as @a[tag=alive] run function modificators:modificator/without_sprint/disable
execute if data storage minecraft:map {modificators:{modificators:["no_knockback"]}} as @e[tag=!lobby,type=!player] run function modificators:modificator/no_knockback/disable_knockback_mobs

# Death
execute as @a[tag=!alive,tag=!ghost,tag=!Admin,tag=!dev_mode,gamemode=!spectator,team=!lobby] run function cmd:map/player/death
execute unless data storage settings {gamemodes:{gamemode:teams}} as @a[tag=!alive,team=!death,tag=!ghost,team=!lobby] at @s run function cmd:map/player/death
execute as @a[scores={deaths=1..}] run function cmd:map/player/death

execute as @a run execute as @s unless score @s canGetItems matches 0..1 run scoreboard players set @s canGetItems 1


# Убийство при перезаходе
execute as @a[scores={lefts=1..},tag=alive] run function cmd:map/player/kill_rejoin

# Тп если игрок снизу в дезматче
execute if data storage minecraft:map {deathmatch_running:true} as @a at @s if entity @s[predicate=events:check_in_game_zone] run spreadplayers 0 0 0 16 under 110 true @s

# Партиклы умерших игроков
execute as @a[tag=!alive,gamemode=spectator] at @s run particle minecraft:crit ~ ~1.6 ~ 0.05 -0.05 0.05 0.05 1 normal @a[distance=3..]

# victory
execute unless entity @a[tag=dev_mode] if data storage minecraft:map {victory:false} if score #players_count.alive settings matches ..0 run function cmd:map/player/victory/nobody_won
execute if data storage minecraft:map {victory:true} as @a[tag=alive] at @s anchored feet run particle minecraft:totem_of_undying ~ ~ ~ 0.1 0 0.1 0.05 5

# Ускорение игры
execute unless data storage minecraft:map {victory:true} if score #players_count.alive settings matches 2 unless score #players_count.old settings matches ..2 if data storage minecraft:map {speedup_game:false} unless data storage minecraft:map {deathmatch_running:true} run function cmd:map/game/speedup/query
# execute if entity @a[tag=1] if data storage minecraft:map {speedup_game:false} if score #players_count.alive settings matches 2 run function cmd:map/game/speedup/query