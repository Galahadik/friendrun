title @a title ""
title @a subtitle {text:"Удачи!",color:red}

execute as @a at @s run playsound minecraft:entity.ender_dragon.ambient master @s ~ ~ ~ 0.2 1.25

schedule function cmd:map/lobby/lololowka_event/end 1s