execute at @s run playsound minecraft:entity.villager.no hostile @s ~ ~ ~ 0.85

tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"Сначала ",color:red},{text:"используйте кликер",bold:true},{text:" прежде чем начать!"}]]
