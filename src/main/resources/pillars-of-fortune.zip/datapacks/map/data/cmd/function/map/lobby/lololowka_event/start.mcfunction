function cmd:map/lobby/clicker/unlock_all
scoreboard players remove &lobby_clicker2 settings 1

execute positioned 18 28 -103 run summon minecraft:lightning_bolt


kill @e[type=item]

summon mannequin 18 27 -103 {profile:{name:"MrRaven___"},Tags:["lololowka_event"],description:{color:gold,text:"MrRaven___"},CustomName:{text:"Создатель карты",color:yellow},CustomNameVisible:true,immovable:false,Invulnerable:true}

function cmd:map/lobby/lololowka_event/loop
schedule function cmd:map/lobby/lololowka_event/1 5s