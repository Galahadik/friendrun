scoreboard players set @s canGetItems 0
tag @s remove alive
execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run team join death @s
gamemode spectator @s
scoreboard players reset @s deaths
title @s title {text:"☠",color:red}
tp @s @r[tag=alive]
execute at @s run playsound entity.ender_dragon.growl hostile @s ~ ~ ~ 0.1

title @s actionbar {"text":"Вы погибли!","color":"red"}