setworldspawn 10 27 -99
spawnpoint @a 10 27 -99

bossbar add item.timer {"text":"Таймер Предмета","color":"red"}
bossbar set minecraft:item.timer color red

worldborder center 0.0 0.0
worldborder damage amount 0.25
worldborder warning distance 0
worldborder warning time 5
worldborder damage buffer 0

time set 6000
weather clear