schedule clear cmd:map/func/stop


schedule clear cmd:map/game/restore_event_button
schedule clear events:random_event


schedule clear cmd:map/player/victory/victory
schedule clear cmd:map/player/victory/team_victory
schedule clear cmd:map/player/victory/nobody_won


schedule clear cmd:map/deathmatch/time_to_match
schedule clear cmd:map/deathmatch/lava
schedule clear cmd:map/deathmatch/worldbarrier_move
schedule clear cmd:map/deathmatch/match_start
schedule clear cmd:map/deathmatch/worldbarrier_move_warn
schedule clear cmd:map/deathmatch/timer


schedule clear events:event/14_force_deathmatch/timer
schedule clear events:event/14_force_deathmatch/start
schedule clear events:event/08_anvil_rain/summon
schedule clear events:event/19_hot_potato/potato
schedule clear events:event/20_tnt_rain/tnt_summon
schedule clear events:event/25_arrow_rain/loop
schedule clear events:event/25_arrow_rain/loop2
schedule clear events:event/25_arrow_rain/loop3
schedule clear events:event/25_arrow_rain/timer
schedule clear events:event/28_last_write_life_die/timer
schedule clear events:event/28_last_write_life_die/timer_s



# schedule clear modificators:modificator/masquerade/tick