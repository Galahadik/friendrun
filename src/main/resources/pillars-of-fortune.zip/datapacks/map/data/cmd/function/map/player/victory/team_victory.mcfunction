$scoreboard players add @a[team=$(team)] wins 1

$team modify $(team) friendlyFire true

$tag @a[team=$(team)] add alive
scoreboard players add @a[tag=!alive,tag=!dev_mode] losses 1

function cmd:map/player/victory/funcs

$title @a[team=$(team)] title [{text:"Поздравляем вашу команду с победой!",color:green}]
title @a[tag=!alive] title [{text:"Ваша команда потерпела поражение!",color:red}]
$title @a subtitle [{text:"Победитель",color:green},{text:" >> ",color:gray,bold:true},"Команда ",{text:"$(team)",color:$(color)}]



$execute as @a[team=$(team)] run team join none @s
tellraw @a ["\n<",[{text:"                ",strikethrough:true},[{text:">> Статистика Победителей <<",strikethrough:false}],"                 "],">\n"]
execute as @a[team=none] run tellraw @a [{text:"Игрок ",color:green},{selector:"@s",color:gold}," ",{score:{name:"@s",objective:"Health"},color:red,bold:true},{text:"❤",color:red}," победил уже ",{text:"— ",color:gray,bold:true},{score:{name:"@s",objective:"wins"},color:yellow,bold:true}," раз! ",[{text:"(x",color:yellow},{score:{name:"@s",objective:wins_streak}},")"]]
$execute as @a[team=none] run team join $(team) @s
tellraw @a ["\n<",{text:"                                                                        ",strikethrough:true},">\n"]

$execute if entity @a[tag=alive] run tag @r[tag=alive,team=$(team)] add winner
$execute unless entity @a[tag=alive] run tag @r[team=$(team)] add winner

execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.75

$execute as @a[team=$(team)] at @s run playsound minecraft:ui.toast.challenge_complete ambient @s ~ ~ ~ 0.1 1.8




schedule function cmd:map/func/stop 10s