fill -15 39 -1 -17 -59 1 minecraft:bedrock replace air
fill 15 39 -1 17 -59 1 minecraft:bedrock replace air

execute if score #teams.teams_count settings matches 3.. run fill -1 39 -17 1 -59 -15 minecraft:bedrock replace air
execute if score #teams.teams_count settings matches 4.. run fill -1 39 15 1 -59 17 minecraft:bedrock replace air
execute if score #teams.teams_count settings matches 5.. run fill -1 39 -1 1 -59 1 minecraft:bedrock replace air