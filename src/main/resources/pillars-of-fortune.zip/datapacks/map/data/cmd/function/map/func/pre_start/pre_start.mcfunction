execute if data storage map {game_running:true} run return fail

data merge storage minecraft:map {pre_start:true}

execute unless entity @a[tag=dev_mode] run scoreboard players set $pre_start timer 15
execute if entity @a[tag=dev_mode] run scoreboard players set $pre_start timer 5

execute as @a at @s run playsound minecraft:entity.experience_orb.pickup hostile @s ~ ~ ~ 0.85

schedule function cmd:map/func/pre_start/timer 1s

title @a title ""
title @a subtitle [{text:"Игра начнется через ",color:green},{text:"15",bold:true,italic:true}," секунд..."]


fill -25 150 24 24 -64 -25 air
gamerule mob_drops false
execute as @e[type=minecraft:slime] at @s run data merge entity @s {Size:0}
execute as @e[type=minecraft:magma_cube] at @s run data merge entity @s {Size:0}
kill @e[type=!player,tag=!lobby]
kill @e[type=!player,tag=!lobby]
gamerule mob_drops true

tellraw @a[tag=Admin] ["\n",{text:"[Нажмите чтобы остановить отсчет]",color:red,hover_event:{action:"show_text",value:{text:"Нажмите, чтобы остановить\n15-ти секундный отсчет перед\nначалом игры",color:red}},click_event:{action:"run_command",command:"/trigger stop_pre_start.trigger"}},"\n"]