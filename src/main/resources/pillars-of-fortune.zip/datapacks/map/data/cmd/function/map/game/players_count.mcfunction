
execute if score #players_count settings matches 1.. run fill -16 39 0 -16 -59 0 minecraft:bedrock replace air
execute if score #players_count settings matches 2.. run fill 16 39 0 16 -59 0 minecraft:bedrock replace air
execute if score #players_count settings matches 3.. run fill 0 39 -16 0 -59 -16 minecraft:bedrock replace air
execute if score #players_count settings matches 4.. run fill 0 39 16 0 -59 16 minecraft:bedrock replace air
execute if score #players_count settings matches 5.. run fill 0 39 0 0 -59 0 minecraft:bedrock replace air
execute if score #players_count settings matches 6.. run fill -11 39 -11 -11 -59 -11 minecraft:bedrock replace air
execute if score #players_count settings matches 7.. run fill 11 39 11 11 -59 11 minecraft:bedrock replace air
execute if score #players_count settings matches 8.. run fill 11 39 -11 11 -59 -11 minecraft:bedrock replace air
execute if score #players_count settings matches 9.. run fill -11 39 11 -11 -59 11 minecraft:bedrock replace air
execute if score #players_count settings matches 10.. run fill 0 39 8 0 -59 8 minecraft:bedrock replace air
execute if score #players_count settings matches 11.. run fill 0 39 -8 0 -59 -8 minecraft:bedrock replace air
execute if score #players_count settings matches 12.. run fill -8 39 0 -8 -59 0 minecraft:bedrock replace air
execute if score #players_count settings matches 13.. run fill 8 39 0 8 -59 0 minecraft:bedrock replace air