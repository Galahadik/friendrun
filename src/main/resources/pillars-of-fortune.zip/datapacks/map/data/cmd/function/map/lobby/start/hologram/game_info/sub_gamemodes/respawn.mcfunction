kill @e[tag=game_info_sub_gamemode_holo]

summon minecraft:text_display 15.75 31 -94.0 {Tags:["lobby","game_info_sub_gamemode_holo","background"],text:\
[{text:"          Подрежим          ",color:gold},"\n",\
[{text:"",color:yellow},"  Подрежим:\n"]]}

execute at @e[type=text_display,tag=game_info_sub_gamemode_holo,tag=background] run function cmd:map/lobby/start/hologram/game_info/sub_gamemodes/respawn_lines