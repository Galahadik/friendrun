execute if data storage minecraft:map {pre_start:true} run return run function cmd:map/lobby/start/hologram/modify_text_pre_start

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if data storage minecraft:settings {lobby:{perm_to_start:false}} if score #players_count settings matches 2..13 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if data storage minecraft:settings {lobby:{perm_to_start:false}} unless score #players_count settings matches 2..13 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:red},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if data storage minecraft:settings {lobby:{perm_to_start:true}} if score #players_count settings matches 2..13 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n(Требуются права)",color:dark_gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if data storage minecraft:settings {lobby:{perm_to_start:true}} unless score #players_count settings matches 2..13 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n(Требуются права)",color:dark_gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:red},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]





execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if data storage minecraft:settings {lobby:{perm_to_start:false}} if score #players_count settings matches 3..30 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if data storage minecraft:settings {lobby:{perm_to_start:false}} unless score #players_count settings matches 3..30 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:red},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if data storage minecraft:settings {lobby:{perm_to_start:true}} if score #players_count settings matches 3..30 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n(Требуются права)",color:dark_gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if data storage minecraft:settings {lobby:{perm_to_start:true}} unless score #players_count settings matches 3..30 if data storage minecraft:map {pre_start:false} run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n",\
{text:"Начать Игру\n",color:gold},\
{text:"(Нажмите, чтобы начать)",color:gray},\
{text:"\n(Требуются права)",color:dark_gray},\
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:red},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]