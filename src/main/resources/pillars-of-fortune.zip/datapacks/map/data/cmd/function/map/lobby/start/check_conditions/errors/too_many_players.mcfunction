execute as @a at @s run playsound minecraft:entity.villager.no hostile @s ~ ~ ~ 0.85

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run return run tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"Слишком ",color:red},{text:"много игроков",bold:true},", чтобы начать игру!"]]