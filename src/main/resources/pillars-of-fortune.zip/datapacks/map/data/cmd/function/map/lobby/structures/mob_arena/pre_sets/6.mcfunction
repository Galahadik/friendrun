summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zoglin 21 27 -77 {DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}

summon minecraft:ravager 15 27 -82 {attributes:[{id:"minecraft:max_health",base:375d}],Health:375.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}