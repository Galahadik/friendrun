scoreboard players set &lobby_clicker settings 5000
scoreboard players set &lobby_clicker2 settings 5000




execute unless data storage minecraft:map {clicker:["slime"]} run function settings:changes/lobby/clicker/unlock_lock/slime/unlock

execute unless score &lobby.chair settings matches 1.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless score &lobby.chair settings matches 2.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless data storage minecraft:map {clicker:["game_info"]} run function settings:changes/lobby/clicker/unlock_lock/game_info/unlock

execute unless score &lobby.chair settings matches 3.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless score &lobby.chair settings matches 4.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless data storage minecraft:map {clicker:["throne"]} run function settings:changes/lobby/clicker/unlock_lock/chairs/king/unlock

execute unless score &lobby.chair settings matches 5.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless score &lobby.chair settings matches 6.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless score &lobby.parkour settings matches 1.. run function settings:changes/lobby/clicker/unlock_lock/parkour/unlock

execute unless score &lobby.chair settings matches 7.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless score &lobby.chair settings matches 8.. run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute unless data storage minecraft:map {clicker:["mob_arena"]} run function settings:changes/lobby/clicker/unlock_lock/mob_arena/unlock

execute unless score &lobby.parkour settings matches 2.. run function settings:changes/lobby/clicker/unlock_lock/parkour/unlock

execute unless data storage minecraft:map {clicker:["connect_4"]} run function settings:changes/lobby/clicker/unlock_lock/connect_4/unlock

execute unless score &lobby.parkour settings matches 3.. run function settings:changes/lobby/clicker/unlock_lock/parkour/unlock

execute unless data storage minecraft:map {clicker:["death_hole"]} run function settings:changes/lobby/clicker/unlock_lock/death_hole/unlock

execute unless data storage minecraft:map {clicker:["bar"]} run function settings:changes/lobby/clicker/unlock_lock/bar/unlock