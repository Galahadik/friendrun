kill @e[tag=clicker_stats]

summon text_display 16 28.00 -105 {Tags:["lobby","clicker_stats","background"],text:[{text:"                               \n\n\n\n\n\n\n\n\n\n(Открытие — 250)",color:dark_gray}]}

execute at @e[type=text_display,tag=clicker_stats,tag=background] run function cmd:map/lobby/clicker/stats/respawn_lines

function cmd:map/lobby/clicker/stats/modify_text
function cmd:map/lobby/clicker/stats/modify_text_clicks