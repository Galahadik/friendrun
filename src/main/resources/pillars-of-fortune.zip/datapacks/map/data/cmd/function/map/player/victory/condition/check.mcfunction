data merge storage minecraft:map {victory:true}

schedule function cmd:map/player/victory/condition/func 3s