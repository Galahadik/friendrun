scoreboard players add &lobby_clicker settings 1


function cmd:map/lobby/clicker/check
function cmd:map/lobby/clicker/stats/modify_text_clicks
setblock 18 28 -103 minecraft:lever[powered=false,facing=south] replace

execute if score &lobby_clicker settings matches 250.. unless data storage minecraft:map {clicker:["slime"]} run return run function settings:changes/lobby/clicker/unlock_lock/slime/unlock

execute if score &lobby_clicker settings matches 500.. unless score &lobby.chair settings matches 1.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 750.. unless score &lobby.chair settings matches 2.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 1000.. unless data storage minecraft:map {clicker:["game_info"]} run return run function settings:changes/lobby/clicker/unlock_lock/game_info/unlock

execute if score &lobby_clicker settings matches 1250.. unless score &lobby.chair settings matches 3.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 1500.. unless score &lobby.chair settings matches 4.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 1750.. unless data storage minecraft:map {clicker:["throne"]} run return run function settings:changes/lobby/clicker/unlock_lock/chairs/king/unlock

execute if score &lobby_clicker settings matches 2000.. unless score &lobby.chair settings matches 5.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 2250.. unless score &lobby.chair settings matches 6.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 2500.. unless score &lobby.parkour settings matches 1.. run return run function settings:changes/lobby/clicker/unlock_lock/parkour/unlock

execute if score &lobby_clicker settings matches 2750.. unless score &lobby.chair settings matches 7.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 3000.. unless score &lobby.chair settings matches 8.. run return run function settings:changes/lobby/clicker/unlock_lock/chairs/default/unlock

execute if score &lobby_clicker settings matches 3250.. unless data storage minecraft:map {clicker:["mob_arena"]} run return run function settings:changes/lobby/clicker/unlock_lock/mob_arena/unlock

execute if score &lobby_clicker settings matches 3500.. unless score &lobby.parkour settings matches 2.. run return run function settings:changes/lobby/clicker/unlock_lock/parkour/unlock

execute if score &lobby_clicker settings matches 3750.. unless data storage minecraft:map {clicker:["connect_4"]} run return run function settings:changes/lobby/clicker/unlock_lock/connect_4/unlock

execute if score &lobby_clicker settings matches 4000.. unless score &lobby.parkour settings matches 3.. run return run function settings:changes/lobby/clicker/unlock_lock/parkour/unlock

execute if score &lobby_clicker settings matches 4250.. unless data storage minecraft:map {clicker:["death_hole"]} run return run function settings:changes/lobby/clicker/unlock_lock/death_hole/unlock

execute if score &lobby_clicker settings matches 4500.. unless data storage minecraft:map {clicker:["bar"]} run return run function settings:changes/lobby/clicker/unlock_lock/bar/unlock