function cmd:map/lobby/start/hologram/respawn

scoreboard players enable @a[tag=Admin] force_start.trigger
scoreboard players enable @a[tag=Mod] force_start.trigger



execute if entity @a[name=Lololowka] unless data storage map {lololowka_event:true} run return run function cmd:map/lobby/start/check_conditions/errors/before_use_clicker


execute if score $lobby_time_before_start timer matches 1.. run return run function cmd:map/lobby/start/check_conditions/errors/wait_before_start

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if score #players_count settings matches ..1 run return run function cmd:map/lobby/start/check_conditions/errors/not_enough_players
execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if score #players_count settings matches 14.. run return run function cmd:map/lobby/start/check_conditions/errors/too_many_players

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score #players_count settings matches 31.. run return run function cmd:map/lobby/start/check_conditions/errors/too_many_players
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score #players_count settings matches ..2 run return run function cmd:map/lobby/start/check_conditions/errors/not_enough_players

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if score #players_count settings matches 2..13 as @s run return run function cmd:map/lobby/start/check_conditions/successful
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score #players_count settings matches 3..30 as @s run return run function cmd:map/lobby/start/check_conditions/successful