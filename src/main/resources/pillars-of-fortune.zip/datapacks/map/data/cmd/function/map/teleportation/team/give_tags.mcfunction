execute as @a[team=Alpha] run tag @s add teleported1
execute as @a[team=Beta] run tag @s add teleported2
execute as @a[team=Gamma] run tag @s add teleported3
execute as @a[team=Delta] run tag @s add teleported4
execute as @a[team=Omega] run tag @s add teleported5