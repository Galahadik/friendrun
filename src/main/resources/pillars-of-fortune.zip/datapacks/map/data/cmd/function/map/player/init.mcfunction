execute unless score @s kills_stat matches 0.. run scoreboard players set @s kills_stat 00
execute unless score @s deaths_stat matches 0.. run scoreboard players set @s deaths_stat 0
execute unless score @s wins matches 0.. run scoreboard players set @s wins 0
execute unless score @s losses matches 0.. run scoreboard players set @s losses 0
execute unless score @s itemsReceived matches 0.. run scoreboard players set @s itemsReceived 0

tag @s add inited