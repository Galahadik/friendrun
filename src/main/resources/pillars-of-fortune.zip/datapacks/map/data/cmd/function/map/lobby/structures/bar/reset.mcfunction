clone -13 23 -91 -15 23 -85 -15 29 -91

clone -13 25 -91 -15 25 -85 -15 32 -91

# barrels

data remove block -13 32 -91 lock
data remove block -13 32 -90 lock
data remove block -13 32 -89 lock
data remove block -13 32 -88 lock
data remove block -13 32 -87 lock
data remove block -13 32 -86 lock

data remove block -14 32 -85 lock
data remove block -15 32 -85 lock

# brewing stands

data remove block -13 29 -91 lock
data remove block -13 29 -90 lock
data remove block -13 29 -89 lock
data remove block -13 29 -88 lock
data remove block -13 29 -87 lock
data remove block -13 29 -86 lock
data remove block -13 29 -85 lock
data remove block -14 29 -85 lock
data remove block -15 29 -85 lock
