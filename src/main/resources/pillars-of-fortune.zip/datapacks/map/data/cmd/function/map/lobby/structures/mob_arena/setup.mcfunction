execute store result score &lobby.mob_arena rng run random value 1..4

kill @e[tag=mob_arena]

execute if score &lobby.mob_arena rng matches 1 run return run function cmd:map/lobby/structures/mob_arena/pre_sets/1
execute if score &lobby.mob_arena rng matches 2 run return run function cmd:map/lobby/structures/mob_arena/pre_sets/2
execute if score &lobby.mob_arena rng matches 3 run return run function cmd:map/lobby/structures/mob_arena/pre_sets/3
execute if score &lobby.mob_arena rng matches 4 run return run function cmd:map/lobby/structures/mob_arena/pre_sets/4
execute if score &lobby.mob_arena rng matches 5 run return run function cmd:map/lobby/structures/mob_arena/pre_sets/5
execute if score &lobby.mob_arena rng matches 6 run return run function cmd:map/lobby/structures/mob_arena/pre_sets/6