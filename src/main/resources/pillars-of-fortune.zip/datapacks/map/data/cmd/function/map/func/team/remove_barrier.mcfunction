function cmd:map/func/team/particles

execute as @a[team=Alpha] run function cmd:map/func/team/info {team:Alpha}
execute as @a[team=Beta] run function cmd:map/func/team/info {team:Beta}
execute as @a[team=Gamma] run function cmd:map/func/team/info {team:Gamma}
execute as @a[team=Delta] run function cmd:map/func/team/info {team:Delta}
execute as @a[team=Omega] run function cmd:map/func/team/info {team:Omega}


execute as @a run tellraw @s ["\n<",{text:"                                             ",strikethrough:true},">"]