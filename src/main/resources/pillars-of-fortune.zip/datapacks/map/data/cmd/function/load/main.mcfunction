function cmd:load/teams
function cmd:load/gamerules
function cmd:load/world
function cmd:load/objectives

execute unless data storage map {first_load:true} run function cmd:load/first_load

tellraw @a {text:"Датапак успешно загружен!",color:green}