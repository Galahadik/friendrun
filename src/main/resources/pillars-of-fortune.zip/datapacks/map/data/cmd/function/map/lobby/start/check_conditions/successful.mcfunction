execute if data storage minecraft:settings {lobby:{perm_to_start:true}} run execute unless entity @s[tag=start.perm] run return run function cmd:map/lobby/start/check_conditions/errors/player_has_no_perm


scoreboard players reset @a force_start.trigger
scoreboard players enable @a[tag=Admin] stop_pre_start.trigger
scoreboard players enable @a[tag=Mod] stop_pre_start.trigger


tellraw @a ["<",{text:"Столбы",color:gray},"> ",{selector:"@s",color:gold},{text:" — ",color:gray},{text:"Запустил игру",color:yellow}]

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run return run function cmd:map/func/pre_start/pre_start
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run return run function gamemodes:team/funcs/start/start