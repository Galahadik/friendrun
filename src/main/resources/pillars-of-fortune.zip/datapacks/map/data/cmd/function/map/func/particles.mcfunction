execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.5

execute if score #players_count settings matches 13.. run particle minecraft:flame 8 40 0 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 12.. run particle minecraft:flame -8 40 0 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 11.. run particle minecraft:flame 0 40 -8 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 10.. run particle minecraft:flame 0 40 8 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 9.. run particle minecraft:flame -11 40 11 0.5 1.5 0.5 0.2 2
execute if score #players_count settings matches 8.. run particle minecraft:flame 11 40 -11 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 7.. run particle minecraft:flame 11 40 11 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 6.. run particle minecraft:flame -11 40 -11 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 5.. run particle minecraft:flame 0 40 0 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 4.. run particle minecraft:flame 0 40 16 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 3.. run particle minecraft:flame 0 40 -16 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 2.. run particle minecraft:flame 16 40 0 0.5 1.5 0.5 0.2 20
execute if score #players_count settings matches 1.. run particle minecraft:flame -16 40 0 0.5 1.5 0.5 0.2 20