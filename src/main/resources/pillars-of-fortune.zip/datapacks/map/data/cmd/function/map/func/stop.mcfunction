function cmd:map/func/team/pvp/enable
function cmd:map/func/stop/storage_modify
function cmd:map/player/remove_tags
function cmd:map/player/remove_attributes
function cmd:map/teleportation/remove_tags
function cmd:give_items/pause_giving
function cmd:map/func/stop/schedule_clear
function cmd:map/scoreboard/teams/reset

scoreboard objectives remove life

gamerule mob_griefing false
gamerule tnt_explodes false
gamerule mob_drops true
gamerule block_drops true
gamerule entity_drops true
gamerule natural_health_regeneration true
gamerule fire_spread_radius_around_player 0


execute if data storage minecraft:settings {lobby:{pvp:false}} run gamerule pvp false

execute as @e[type=!player,tag=!lobby] run data merge entity @s {NoAI:true}

# LOBBY
function cmd:map/lobby/lobby_entities
function cmd:map/lobby/structures/reset

scoreboard players set $lobby_time_before_start timer 6
function cmd:map/lobby/start/check_conditions/countdown_before_start

scoreboard objectives setdisplay list Health

clone -3 30 -110 -3 27 -112 -3 28 -106

###############################

execute as @a[tag=Mod] run function admin:panel/show_panel
execute as @a[tag=Admin] run function admin:panel/show_panel

scoreboard players enable @a[tag=Admin] force_start.trigger
scoreboard players enable @a[tag=Mod] force_start.trigger
scoreboard players reset @a force_stop.trigger

###############################

function cmd:map/func/stop/reset_player

stopwatch remove game_timer

function settings:changes/game/fall_damage/disable
worldborder center 0.0 0.0
worldborder set 750
difficulty normal

execute if data storage minecraft:map {clicker:["throne"]} run ride @r[tag=winner,tag=alive] mount @e[tag=king_seat,limit=1]
execute if data storage minecraft:map {clicker:["throne"]} run tag @r[tag=winner] add throne.seat
execute if data storage minecraft:map {clicker:["throne"]} if entity @a[tag=winner] as @a[tag=!throne.seat] run function cmd:map/lobby/entities/throne/mount

execute if data storage minecraft:map {clicker:["mob_arena"]} run function cmd:map/lobby/structures/mob_arena/setup

tag @a remove winner

stopsound @a
execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ambient @s 10 27 -99 1
