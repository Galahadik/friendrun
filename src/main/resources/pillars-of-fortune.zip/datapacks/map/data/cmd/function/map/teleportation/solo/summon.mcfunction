# CREATE TELEPORT ARMOR STAND
execute if score #players_count settings matches 1.. run summon minecraft:text_display -16 40 0 {Rotation:[-90f,0f],Tags:["Teleport","Teleport1"]}
execute if score #players_count settings matches 2.. run summon minecraft:text_display 16 40 0 {Rotation:[90f,0f],Tags:["Teleport","Teleport2"]}
execute if score #players_count settings matches 3.. run summon minecraft:text_display 0 40 -16 {Rotation:[0f,0f],Tags:["Teleport","Teleport3"]}
execute if score #players_count settings matches 4.. run summon minecraft:text_display 0 40 16 {Rotation:[-180f,0f],Tags:["Teleport","Teleport4"]}
execute if score #players_count settings matches 5.. run summon minecraft:text_display 0 40 0 {Rotation:[0f,0f],Tags:["Teleport","Teleport5"]}
execute if score #players_count settings matches 6.. run summon minecraft:text_display -11 40 -11 {Rotation:[-45f,0f],Tags:["Teleport","Teleport6"]}
execute if score #players_count settings matches 7.. run summon minecraft:text_display 11 40 11 {Rotation:[135f,0f],Tags:["Teleport","Teleport7"]}
execute if score #players_count settings matches 8.. run summon minecraft:text_display 11 40 -11 {Rotation:[45f,0f],Tags:["Teleport","Teleport8"]}
execute if score #players_count settings matches 9.. run summon minecraft:text_display -11 40 11 {Rotation:[-135f,0f],Tags:["Teleport","Teleport9"]}
execute if score #players_count settings matches 10.. run summon minecraft:text_display 0 40 8 {Rotation:[180f,0f],Tags:["Teleport","Teleport10"]}
execute if score #players_count settings matches 11.. run summon minecraft:text_display 0 40 -8 {Rotation:[0f,0f],Tags:["Teleport","Teleport11"]}
execute if score #players_count settings matches 12.. run summon minecraft:text_display -8 40 0 {Rotation:[-90f,0f],Tags:["Teleport","Teleport12"]}
execute if score #players_count settings matches 13.. run summon minecraft:text_display 8 40 0 {Rotation:[90f,0f],Tags:["Teleport","Teleport13"]}