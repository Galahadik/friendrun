execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["plus"]}}}}} run function cmd:map/game/sub_gamemodes/bridges/plus
execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{params:{bridges:{structure:["circle"]}}}}} run function cmd:map/game/sub_gamemodes/bridges/circle

