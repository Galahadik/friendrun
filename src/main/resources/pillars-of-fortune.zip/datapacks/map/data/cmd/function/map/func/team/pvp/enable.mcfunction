team modify Alpha friendlyFire true
team modify Beta friendlyFire true
team modify Gamma friendlyFire true
team modify Delta friendlyFire true
team modify Omega friendlyFire true