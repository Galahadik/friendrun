function cmd:map/scoreboard/teams/setting {team:"Альфа",color:blue,scb:"01",count_alive:"#teams.alpha_count.alive"}
function cmd:map/scoreboard/teams/setting_players {team:Alpha,scb:"02"}
function cmd:map/scoreboard/teams/setting {team:"Бета",color:red,scb:"04",count_alive:"#teams.beta_count.alive"}
function cmd:map/scoreboard/teams/setting_players {team:Beta,scb:"05"}
function cmd:map/scoreboard/teams/setting {team:"Гамма",color:green,scb:"07",count_alive:"#teams.gamma_count.alive"}
function cmd:map/scoreboard/teams/setting_players {team:Gamma,scb:"08"}

scoreboard players display name scb.#03 scb.Teams ""
scoreboard players display name scb.#06 scb.Teams ""
scoreboard players display name scb.#09 scb.Teams ""

scoreboard players display numberformat scb.#01 scb.Teams blank
scoreboard players display numberformat scb.#02 scb.Teams blank
scoreboard players display numberformat scb.#03 scb.Teams blank
scoreboard players display numberformat scb.#04 scb.Teams blank
scoreboard players display numberformat scb.#05 scb.Teams blank
scoreboard players display numberformat scb.#06 scb.Teams blank
scoreboard players display numberformat scb.#07 scb.Teams blank
scoreboard players display numberformat scb.#08 scb.Teams blank
scoreboard players display numberformat scb.#09 scb.Teams blank