worldborder center 100.0 100.0
schedule function cmd:map/player/victory/nobody_won 35s
worldborder damage amount 0.05