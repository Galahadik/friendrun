gamemode adventure @a[tag=!Admin,tag=!dev_mode]
gamemode adventure @a[gamemode=survival,tag=!dev_mode]

clear @a[tag=!dev_mode,tag=!Admin] *[!custom_data={lobby_item:true}]

execute as @a[tag=!dev_mode] if data entity @s {foodSaturationLevel:0.0f} run effect give @s saturation 1 0 true

execute unless entity @a[tag=dev_mode] if data storage minecraft:map {pre_start:false} run team join lobby @a

execute as @a[scores={force_start.trigger=1..}] run function admin:panel/funcs/force_start

scoreboard players reset @a deaths
scoreboard players reset @a lefts

# tp
execute as @a[x=-4,y=42,z=-92,dx=28,dy=24,dz=-21,tag=!dev_mode,tag=!Admin,gamemode=!spectator,gamemode=!creative] run tp @s 10 27 -99

#parkour
execute as @a[predicate=cmd:lobby/check_parkour] run effect give @s weakness 1 255 true

# black hole
execute if data storage minecraft:map {clicker:["death_hole"]} as @e[x=-2,y=18,z=-95,dy=1] run damage @s 1.25 minecraft:freeze

# INTERACTIONS
# sit on seats
execute as @e[tag=seat.temp,type=minecraft:interaction] at @s on target run function cmd:map/lobby/entities/seats/mount
execute as @e[tag=seat.temp,type=minecraft:interaction] run data remove entity @s interaction

# start 
execute if data storage minecraft:map {pre_start:false} as @e[tag=start_holo.interaction,type=interaction] on target as @s run function cmd:map/lobby/start/check_conditions/check
execute if data storage minecraft:map {pre_start:true} as @e[tag=start_holo.interaction,type=interaction] on target as @s run function cmd:map/lobby/start/check_conditions/errors/game_already_starting
execute as @e[tag=start_holo.interaction,type=interaction] run data remove entity @s interaction

# Information in lobby
execute as @e[tag=events_list,type=interaction] on target as @s run function settings:pages/lobby/info/events/list
execute as @e[tag=maps_list,type=interaction] on target as @s run function settings:pages/lobby/info/maps/list
execute as @e[tag=modificators_list,type=interaction] on target as @s run function settings:pages/lobby/info/modificators/list
execute as @e[tag=game_features,type=interaction] on target as @s run trigger info
execute as @e[tag=info_list,type=interaction] run data remove entity @s interaction

# Start
function cmd:map/lobby/start/hologram/modify_text
execute if data storage minecraft:map {clicker:["game_info"]} run function cmd:map/lobby/start/hologram/game_info/modify_text
execute if data storage minecraft:map {clicker:["game_info"]} if data storage minecraft:settings {gamemodes:{gamemode:"teams"}} run function cmd:map/lobby/start/hologram/game_info/teams/modify_text
execute if data storage minecraft:map {clicker:["game_info"]} unless data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"none"}}} run function cmd:map/lobby/start/hologram/game_info/sub_gamemodes/modify_text

# Clicker
execute if block 18 28 -103 lever[powered=true] run function cmd:map/lobby/clicker/clicker
data merge entity @e[type=text_display,limit=1,tag=clicker_hud] {text:[{"color":"gold","text":"\n Нажатий » \n"},{"bold":true,"color":"yellow","score":{"name":"&lobby_clicker","objective":"settings"}},{"text":"\n"}]}

execute as @a run execute as @s unless score @s canGetItems matches 0..1 run scoreboard players set @s canGetItems 0


# stop pre start timer
execute as @a[scores={stop_pre_start.trigger=1..}] run function cmd:map/func/pre_start/stop
