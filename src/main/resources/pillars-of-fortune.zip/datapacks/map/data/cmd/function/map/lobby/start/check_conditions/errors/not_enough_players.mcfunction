execute as @a at @s run playsound minecraft:entity.villager.no hostile @s ~ ~ ~ 0.85

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run return run tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"Слишком ",color:red},{text:"мало игроков",bold:true}," чтобы начать игру!"]]

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"Невозможно начать игру в \"",color:red},{text:"Командном",bold:true},"\" режиме. Недостаточно игроков. Минимальное кол-во игроков: 3. Режим был сменен автоматически на \"Обычный\"."]]

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run kill @e[tag=game_info_teams_holo]
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run data modify storage minecraft:settings gamemodes.gamemode set value default
