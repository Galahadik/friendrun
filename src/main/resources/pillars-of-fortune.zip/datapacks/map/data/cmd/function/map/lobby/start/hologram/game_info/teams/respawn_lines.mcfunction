summon minecraft:text_display ~-1 ~0.50 ~.45 {\
Tags:["lobby","game_info_teams_holo","line_1"]}
summon minecraft:text_display ~-1 ~0.25 ~.45 {\
Tags:["lobby","game_info_teams_holo","line_2"]}

execute as @e[type=text_display,tag=game_info_teams_holo,tag=!background] run data merge entity @s {background:0}
# execute as @e[type=text_display,tag=game_info_teams_holo] run data merge entity @s {Rotation:[-180.0f, 0.0f],shadow:true,alignment:left}
execute as @e[type=text_display,tag=game_info_teams_holo] run data merge entity @s {Rotation:[155.0f, 0.0f],shadow:true,alignment:left}