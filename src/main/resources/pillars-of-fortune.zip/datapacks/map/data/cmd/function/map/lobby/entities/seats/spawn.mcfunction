kill @e[tag=seat.temp]
kill @e[tag=seat]
kill @e[tag=king_seat]

execute if data storage minecraft:map {clicker:["throne"]} if entity @a[tag=winner] run summon minecraft:interaction 10 29.95 -110 {height:0.1,width:0.75,Tags:["lobby","king_seat"]}

execute if data storage minecraft:map {clicker:["throne"]} if entity @a[tag=winner] run function cmd:map/lobby/entities/throne/spawn

execute if score &lobby.chair settings matches 1.. run summon interaction 0 27.3 -105 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}
execute if score &lobby.chair settings matches 2.. run summon interaction 16 27.3 -90 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}
execute if score &lobby.chair settings matches 3.. run summon interaction 12 27.3 -90 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}
execute if score &lobby.chair settings matches 4.. run summon interaction 4 27.3 -90 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}
execute if score &lobby.chair settings matches 5.. run summon interaction 1 27.3 -93 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}
execute if score &lobby.chair settings matches 6.. run summon interaction 18 27.3 -93 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}
execute if score &lobby.chair settings matches 7.. run summon interaction 10 27.3 -93 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}
execute if score &lobby.chair settings matches 8.. run summon interaction 7 27.3 -93 {response:true,width:1.26,height:0.5,Tags:["lobby","seat.temp"]}

execute if data storage minecraft:map {clicker:["bar"]} run summon interaction -16 27.95 -94 {response:true,width:1.15,height:0.25,Tags:["lobby","seat.temp"]}
execute if data storage minecraft:map {clicker:["bar"]} run summon interaction -18 27.95 -92 {response:true,width:1.15,height:0.25,Tags:["lobby","seat.temp"]}
execute if data storage minecraft:map {clicker:["bar"]} run summon interaction -18 27.95 -89 {response:true,width:1.15,height:0.25,Tags:["lobby","seat.temp"]}
execute if data storage minecraft:map {clicker:["bar"]} run summon interaction -18 27.95 -86 {response:true,width:1.15,height:0.25,Tags:["lobby","seat.temp"]}

execute at @e[type=interaction,tag=seat.temp] run summon interaction ~ ~0.25 ~ {width:0.01,height:0.01,Tags:["lobby","seat"]}