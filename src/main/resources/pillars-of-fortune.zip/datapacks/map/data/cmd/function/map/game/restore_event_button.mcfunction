data merge storage minecraft:map {event_countdown:false}
setblock 0 60 0 minecraft:gold_block
setblock 0 59 0 minecraft:polished_blackstone_button[face=ceiling]
title @a actionbar {"text":"Кнопка активации событий восстановлена!","color":"gold"}
execute as @a at @s run playsound entity.experience_orb.pickup hostile @s ~ ~ ~ 0.75