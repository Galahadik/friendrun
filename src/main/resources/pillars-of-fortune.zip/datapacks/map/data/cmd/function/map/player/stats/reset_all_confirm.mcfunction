scoreboard players reset * kills_stat
scoreboard players reset * deaths_stat
scoreboard players reset * itemsReceived
scoreboard players reset * wins
scoreboard players reset * losses
scoreboard players reset * wins_streak

scoreboard players set @a kills_stat 0
scoreboard players set @a deaths_stat 0
scoreboard players set @a itemsReceived 0
scoreboard players set @a wins 0
scoreboard players set @a losses 0
scoreboard players set @a wins_streak 0

tellraw @a ["<",{text:"Столбы",color:gold},"> ",{selector:"@s",color:blue},{text:" — ",color:gray},{text:"очистил статистику всех игроков",color:red}]