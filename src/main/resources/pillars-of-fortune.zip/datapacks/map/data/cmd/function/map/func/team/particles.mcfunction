execute as @a at @s run playsound minecraft:entity.experience_orb.pickup ambient @s ~ ~ ~ 0.5

particle minecraft:flame -16 40 0 0.5 1.5 0.5 0.2 20
particle minecraft:flame 16 40 0 0.5 1.5 0.5 0.2 20
execute if score #teams.teams_count settings matches 3.. run particle minecraft:flame 0 40 -16 0.5 1.5 0.5 0.2 20
execute if score #teams.teams_count settings matches 4.. run particle minecraft:flame 0 40 16 0.5 1.5 0.5 0.2 20
execute if score #teams.teams_count settings matches 5.. run particle minecraft:flame 0 40 0 0.5 1.5 0.5 0.2 20
