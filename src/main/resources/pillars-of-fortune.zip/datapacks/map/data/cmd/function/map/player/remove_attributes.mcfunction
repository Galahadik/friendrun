execute as @a run attribute @s minecraft:armor base reset
execute as @a run attribute @s minecraft:armor_toughness base reset
execute as @a run attribute @s minecraft:attack_damage base reset
execute as @a run attribute @s minecraft:attack_knockback base reset
execute as @a run attribute @s minecraft:attack_speed base reset
execute as @a run attribute @s minecraft:block_break_speed base reset
execute as @a run attribute @s minecraft:block_interaction_range base reset
execute as @a run attribute @s minecraft:burning_time base reset
execute as @a run attribute @s minecraft:camera_distance base reset
execute as @a run attribute @s minecraft:entity_interaction_range base reset
execute as @a run attribute @s minecraft:explosion_knockback_resistance base reset
execute as @a run attribute @s minecraft:fall_damage_multiplier base reset
execute as @a run attribute @s minecraft:gravity base reset
execute as @a run attribute @s minecraft:jump_strength base reset
execute as @a run attribute @s minecraft:knockback_resistance base reset
execute as @a run attribute @s minecraft:luck base reset
execute as @a run attribute @s minecraft:max_absorption base reset
execute as @a run attribute @s minecraft:max_health base reset
execute as @a run attribute @s minecraft:mining_efficiency base reset
execute as @a run attribute @s minecraft:movement_efficiency base reset
execute as @a run attribute @s minecraft:movement_speed base reset
execute as @a run attribute @s minecraft:oxygen_bonus base reset
execute as @a run attribute @s minecraft:safe_fall_distance base reset
execute as @a run attribute @s minecraft:scale base reset
execute as @a run attribute @s minecraft:sneaking_speed base reset
execute as @a run attribute @s minecraft:step_height base reset
execute as @a run attribute @s minecraft:submerged_mining_speed base reset
execute as @a run attribute @s minecraft:sweeping_damage_ratio base reset
execute as @a run attribute @s minecraft:water_movement_efficiency base reset
execute as @a run attribute @s minecraft:waypoint_receive_range base reset
execute as @a run attribute @s minecraft:waypoint_transmit_range base reset

execute as @a run attribute @s minecraft:max_health modifier remove minecraft:rebirth

execute as @a run attribute @s minecraft:scale modifier remove fun_ride