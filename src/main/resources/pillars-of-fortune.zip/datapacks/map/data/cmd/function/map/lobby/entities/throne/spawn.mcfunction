execute unless data storage minecraft:map {clicker:["throne"]} run return fail

summon minecraft:interaction 7 27 -105 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 7 27 -104 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 7 27 -103 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 8 27 -102 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 9 27 -102 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 10 27 -102 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 11 27 -102 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 12 27 -102 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 13 27 -102 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 14 27 -103 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 14 27 -104 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}
summon minecraft:interaction 14 27 -105 {height:0.25,width:0.75,Tags:["lobby","throne.seat"]}