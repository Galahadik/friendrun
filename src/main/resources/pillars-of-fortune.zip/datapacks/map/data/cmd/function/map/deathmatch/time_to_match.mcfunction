title @a title ["",{text:"Через 25 секунд ",color:red},{atlas:items,sprite:"item/clock_19"}]
title @a subtitle {"text":"Оставшихся игроков телепортирует на арену","color":"red"}
execute as @a at @s run playsound minecraft:entity.wither.death ambient @s ~ ~ ~ 0.32 1.5

scoreboard players set $deathmatch timer 26

function cmd:map/deathmatch/timer

schedule function settings:changes/game/fall_damage/disable 24s