execute if data storage settings {gamemodes:{gamemode:default}} run return run data modify entity @s text set value {text:"     Одиночный",color:aqua}

execute if data storage settings {gamemodes:{gamemode:teams}} run return run data modify entity @s text set value {text:"     Командный",color:aqua}