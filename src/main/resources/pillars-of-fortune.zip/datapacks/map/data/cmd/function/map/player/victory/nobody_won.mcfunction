title @a title [{"text":"Поражение!","color":"red"}]
title @a subtitle {"text":"Ничья. Победила дружба!!!","color":red}

function cmd:map/player/victory/funcs

schedule function cmd:map/func/stop 10s