scoreboard players set #items_give_timer.Time settings 0
scoreboard players set #item settings 0

function cmd:give_items/give

bossbar set minecraft:item.timer players @a
bossbar set minecraft:item.timer visible true

scoreboard players set #giveItems settings 1