
execute unless data storage minecraft:map {modificators:{modificators:["identical_items"]}} as @a at @s if data storage minecraft:settings {give_items_on_floor:false} unless score #random_map rng matches -1..0 unless predicate events:check_on_floor if score #items_give_count .temp matches 1.. if score @s canGetItems matches 1 run loot give @s loot items:all_items/item

execute unless data storage minecraft:map {modificators:{modificators:["identical_items"]}} as @a at @s if data storage minecraft:settings {give_items_on_floor:false} if score #random_map rng matches -1..0 if score #items_give_count .temp matches 1.. if score @s canGetItems matches 1 run loot give @s loot items:all_items/item

execute unless data storage minecraft:map {modificators:{modificators:["identical_items"]}} as @a at @s if data storage minecraft:settings {give_items_on_floor:true} if score #items_give_count .temp matches 1.. if score @s canGetItems matches 1 run loot give @s loot items:all_items/item


execute if data storage minecraft:map {modificators:{modificators:["identical_items"]}} run loot insert 6 21 -87 loot items:all_items/item


execute if data storage minecraft:map {modificators:{modificators:["identical_items"]}} if score #items_give_count .temp matches 1 as @a at @s if data storage minecraft:settings {give_items_on_floor:false} unless score #random_map rng matches -1..0 unless predicate events:check_on_floor if score #items_give_count .temp matches 1.. if score @s canGetItems matches 1 run loot give @s mine 6 21 -87 stick[custom_data={drop_contents:true}]

execute if data storage minecraft:map {modificators:{modificators:["identical_items"]}} if score #items_give_count .temp matches 1 as @a at @s if data storage minecraft:settings {give_items_on_floor:false} if score #random_map rng matches -1..0 if score #items_give_count .temp matches 1.. if score @s canGetItems matches 1 run loot give @s mine 6 21 -87 stick[custom_data={drop_contents:true}]

execute if data storage minecraft:map {modificators:{modificators:["identical_items"]}} if score #items_give_count .temp matches 1 as @a at @s if data storage minecraft:settings {give_items_on_floor:true} if score #items_give_count .temp matches 1.. if score @s canGetItems matches 1 run loot give @s mine 6 21 -87 stick[custom_data={drop_contents:true}]


scoreboard players remove #items_give_count .temp 1
execute unless score #items_give_count .temp matches 1.. run return run function cmd:give_items/end
function cmd:give_items/start