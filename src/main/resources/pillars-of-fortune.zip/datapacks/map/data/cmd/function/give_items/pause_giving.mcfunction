scoreboard players set #giveItems settings 0

bossbar set minecraft:item.timer visible false