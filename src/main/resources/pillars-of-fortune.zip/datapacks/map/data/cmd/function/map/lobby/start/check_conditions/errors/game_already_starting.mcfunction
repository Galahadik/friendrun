execute at @s run playsound minecraft:entity.villager.no hostile @s ~ ~ ~ 0.85

tellraw @s ["<",{text:"Столбы",color:gray},"> ",[{text:"Игра ",color:red},{text:"уже запускается!",bold:true}]]