summon minecraft:iron_golem 21 27 -77 {DeathLootTable:"",attributes:[{id:"minecraft:scale",base:0.5d},{id:"max_health",base:190.0d}],Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:iron_golem 21 27 -77 {DeathLootTable:"",attributes:[{id:"minecraft:scale",base:0.5d},{id:"max_health",base:190.0d}],Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:iron_golem 21 27 -77 {DeathLootTable:"",attributes:[{id:"minecraft:scale",base:0.5d},{id:"max_health",base:190.0d}],Silent:true,Tags:["mob_arena","lobby"]}

summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}
summon minecraft:zombie 15 27 -82 {attributes:[{id:"minecraft:max_health",base:200d}],Health:90.0f,DeathLootTable:"",Silent:true,Tags:["mob_arena","lobby"]}