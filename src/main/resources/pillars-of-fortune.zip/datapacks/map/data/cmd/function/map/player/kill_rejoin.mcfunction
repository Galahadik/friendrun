clear @s
tag @s remove alive
tellraw @a[distance=0.001..] ["<",{text:"Столбы",color:gray},"> ",{text:"Игрок ",color:green},{selector:"@s",color:gold},{text:" - ",color:gray},{text:"был(а) убит(а) из-за присоеденения на сервер во время матча",color:green}]
tellraw @s ["<",{text:"Столбы",color:gray},"> ",{text:"Вы были убиты из-за присоеденения на сервер во время матча",color:green}]

scoreboard players reset @s lefts