execute if score #teams.teams_count settings matches 2 run function cmd:map/scoreboard/teams/teams_count/2_teams
execute if score #teams.teams_count settings matches 3 run function cmd:map/scoreboard/teams/teams_count/3_teams
execute if score #teams.teams_count settings matches 4 run function cmd:map/scoreboard/teams/teams_count/4_teams
execute if score #teams.teams_count settings matches 5 run function cmd:map/scoreboard/teams/teams_count/5_teams

scoreboard objectives setdisplay sidebar scb.Teams