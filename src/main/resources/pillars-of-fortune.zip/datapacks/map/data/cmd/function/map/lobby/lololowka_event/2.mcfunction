tellraw @a ["",{"text":"<","color":"gray"},{"text":"MrRaven___","color":"gold"},{"text":"> ","color":"gray"},{"text":"Надеюсь, вам и вашим друзьям она понравится! Я начал создавать эту карту, как только режим \"Столбы\" начал набирать популярность, но выложить её получилось только сейчас ("},{"text":"15.06.26","color":"aqua"},{"text":")."}]

playsound minecraft:entity.villager.ambient master @a 18 28 -103 100

schedule function cmd:map/lobby/lololowka_event/3 8s