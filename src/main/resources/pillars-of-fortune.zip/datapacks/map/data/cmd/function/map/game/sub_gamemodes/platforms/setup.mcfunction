fill -16 39 -16 16 -59 16 air replace minecraft:bedrock

execute if data storage minecraft:settings {gamemodes:{gamemode:"teams"}} run spreadplayers 0 0 0 16 under 99 true @a
execute if data storage minecraft:settings {gamemodes:{gamemode:"default"}} run spreadplayers 0 0 0 16 under 99 false @a