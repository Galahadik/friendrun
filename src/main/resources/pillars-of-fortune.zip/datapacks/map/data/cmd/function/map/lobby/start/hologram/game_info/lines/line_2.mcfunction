execute if data storage minecraft:settings {kits:{enable:false}} run return run data modify entity @s text set value {text:"             Выкл",color:aqua}

execute if data storage minecraft:settings {kits:{enable:true}} if data storage minecraft:settings {kits:{kit:1}} run return run data modify entity @s text set value {text:"        Вкл (1/5)",color:aqua}
execute if data storage minecraft:settings {kits:{enable:true}} if data storage minecraft:settings {kits:{kit:2}} run return run data modify entity @s text set value {text:"        Вкл (2/5)",color:aqua}
execute if data storage minecraft:settings {kits:{enable:true}} if data storage minecraft:settings {kits:{kit:3}} run return run data modify entity @s text set value {text:"        Вкл (3/5)",color:aqua}
execute if data storage minecraft:settings {kits:{enable:true}} if data storage minecraft:settings {kits:{kit:4}} run return run data modify entity @s text set value {text:"        Вкл (4/5)",color:aqua}
execute if data storage minecraft:settings {kits:{enable:true}} if data storage minecraft:settings {kits:{kit:5}} run return run data modify entity @s text set value {text:"        Вкл (5/5)",color:aqua}