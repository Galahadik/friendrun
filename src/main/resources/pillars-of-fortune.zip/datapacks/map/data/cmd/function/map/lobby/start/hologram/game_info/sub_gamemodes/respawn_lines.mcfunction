summon minecraft:text_display ~-0.5 ~0.25 ~-.15 {\
Tags:["lobby","game_info_sub_gamemode_holo","line_1"]}
summon minecraft:text_display ~-0.5 ~0.00 ~-.15 {\
Tags:["lobby","game_info_sub_gamemode_holo","line_2"]}

execute as @e[type=text_display,tag=game_info_sub_gamemode_holo,tag=!background] run data merge entity @s {background:0}
execute as @e[type=text_display,tag=game_info_sub_gamemode_holo] run data merge entity @s {Rotation:[-165.0f, 0.0f],shadow:true,alignment:left}