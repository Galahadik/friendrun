fill 14 149 -15 -15 149 14 lava
title @a[tag=!alive] title ""
title @a[tag=alive] title {"text":"МЕДЛИТЕ!","color":"red"}
title @a subtitle {"text":"Лава уже на подходе","color":"gold"}
execute as @a at @s run playsound minecraft:entity.wither.ambient ambient @s ~ ~ ~ 0.35 1.8