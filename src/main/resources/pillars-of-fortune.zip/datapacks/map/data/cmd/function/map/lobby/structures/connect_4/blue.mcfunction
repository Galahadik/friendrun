fill -10 32 -88 -5 32 -88 air

setblock ~ ~-1 ~-1 blue_concrete_powder

schedule function cmd:map/lobby/structures/connect_4/check_blue 1s
