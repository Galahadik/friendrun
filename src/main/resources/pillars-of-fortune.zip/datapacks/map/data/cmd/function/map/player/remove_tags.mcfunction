tag @a remove ghost
tag @a remove have_team
tag @a remove not_have_team

tag @a remove event.get_potato
tag @a remove event.give_potato
tag @a remove event.tp_rand_player
tag @a remove event.tp_player
tag @a remove event.op_sword
tag @a remove event.last_write_life_die

# tag @a remove alive
tag @a remove target
tag @a remove throne.seat

tag @a remove team.alpha
tag @a remove team.beta
tag @a remove team.gamma
tag @a remove team.delta
tag @a remove team.omega
