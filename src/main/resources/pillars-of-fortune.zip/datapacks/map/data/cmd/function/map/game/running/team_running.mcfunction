
# Показ неведимок
execute if data storage minecraft:settings {show_invisibles:true} if data storage minecraft:map {remove_barrier:true} run execute as @a[tag=alive] if entity @s[nbt={active_effects:[{id:"minecraft:invisibility"}]}] run effect give @s glowing 5 255 true


function cmd:map/scoreboard/teams/setup

execute store result score #teams.alpha_count.alive settings if entity @a[team=Alpha,tag=alive]
execute store result score #teams.beta_count.alive settings if entity @a[team=Beta,tag=alive]
execute store result score #teams.gamma_count.alive settings if entity @a[team=Gamma,tag=alive]
execute store result score #teams.delta_count.alive settings if entity @a[team=Delta,tag=alive]
execute store result score #teams.omega_count.alive settings if entity @a[team=Omega,tag=alive]

execute unless entity @a[team=Alpha,tag=alive] run data modify storage minecraft:map teams.Alpha_has_alive set value 0
execute unless entity @a[team=Beta,tag=alive] run data modify storage minecraft:map teams.Beta_has_alive set value 0
execute unless entity @a[team=Gamma,tag=alive] run data modify storage minecraft:map teams.Gamma_has_alive set value 0
execute unless entity @a[team=Delta,tag=alive] run data modify storage minecraft:map teams.Delta_has_alive set value 0
execute unless entity @a[team=Omega,tag=alive] run data modify storage minecraft:map teams.Omega_has_alive set value 0

execute unless entity @a[tag=dev_mode] if data storage minecraft:map {victory:false} if data storage minecraft:map {teams:{Beta_has_alive:0, Gamma_has_alive:0, Delta_has_alive:0, Omega_has_alive:0}} run function cmd:map/player/victory/team_victory {team:Alpha,color:"blue"}

execute unless entity @a[tag=dev_mode] if data storage minecraft:map {victory:false} if data storage minecraft:map {teams:{Alpha_has_alive:0, Gamma_has_alive:0, Delta_has_alive:0, Omega_has_alive:0}} run function cmd:map/player/victory/team_victory {team:Beta,color:"red"}

execute unless entity @a[tag=dev_mode] if data storage minecraft:map {victory:false} if data storage minecraft:map {teams:{Alpha_has_alive:0, Beta_has_alive:0, Delta_has_alive:0, Omega_has_alive:0}} run function cmd:map/player/victory/team_victory {team:Gamma,color:"green"}

execute unless entity @a[tag=dev_mode] if data storage minecraft:map {victory:false} if data storage minecraft:map {teams:{Alpha_has_alive:0, Beta_has_alive:0, Gamma_has_alive:0, Omega_has_alive:0}} run function cmd:map/player/victory/team_victory {team:Delta,color:"yellow"}

execute unless entity @a[tag=dev_mode] if data storage minecraft:map {victory:false} if data storage minecraft:map {teams:{Alpha_has_alive:0, Beta_has_alive:0, Gamma_has_alive:0, Delta_has_alive:0}} run function cmd:map/player/victory/team_victory {team:Omega,color:"light_purple"}
