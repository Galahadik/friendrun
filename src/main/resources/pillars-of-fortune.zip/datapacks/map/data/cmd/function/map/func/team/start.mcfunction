function cmd:map/teleportation/team/give_tags

function cmd:map/game/teams_count


function cmd:map/teleportation/team/summon

scoreboard players set $teleport timer 0

function cmd:map/teleportation/team/teleport


function cmd:map/scoreboard/teams/setup



data modify storage minecraft:map teams.Alpha_has_alive set value 1
data modify storage minecraft:map teams.Beta_has_alive set value 1
execute if score #teams.teams_count settings matches 3.. run data modify storage minecraft:map teams.Gamma_has_alive set value 1
execute if score #teams.teams_count settings matches 4.. run data modify storage minecraft:map teams.Delta_has_alive set value 1
execute if score #teams.teams_count settings matches 5.. run data modify storage minecraft:map teams.Omega_has_alive set value 1
execute unless score #teams.teams_count settings matches 3.. run data modify storage minecraft:map teams.Gamma_has_alive set value 0
execute unless score #teams.teams_count settings matches 4.. run data modify storage minecraft:map teams.Delta_has_alive set value 0
execute unless score #teams.teams_count settings matches 5.. run data modify storage minecraft:map teams.Omega_has_alive set value 0
