scoreboard objectives add canGetItems dummy

scoreboard objectives add .temp dummy
scoreboard objectives add rng dummy
scoreboard objectives add settings dummy
scoreboard objectives add timer dummy
scoreboard objectives add const dummy

# TRIGGERS
scoreboard objectives add panel.trigger trigger
scoreboard objectives add force_stop.trigger trigger
scoreboard objectives add force_start.trigger trigger
scoreboard objectives add stop_pre_start.trigger trigger

scoreboard objectives add info trigger

# STATS
scoreboard objectives add wins dummy
scoreboard objectives add losses dummy
scoreboard objectives add wins_streak dummy
scoreboard objectives add itemsReceived dummy {text:"Предметов",color:gold}
scoreboard objectives add Health health
scoreboard objectives add deaths_stat deathCount
scoreboard objectives add kills_stat minecraft.custom:minecraft.player_kills
scoreboard objectives add kills_stat.temp minecraft.custom:minecraft.player_kills

scoreboard objectives add deaths deathCount
scoreboard objectives add lefts minecraft.custom:minecraft.leave_game

# Константы
scoreboard players set 1 const 1
scoreboard players set 2 const 2
scoreboard players set 3 const 3
scoreboard players set 4 const 4
scoreboard players set 5 const 5

# КОМАНДЫЙ
scoreboard objectives add teams.join_cant trigger
scoreboard objectives add teams.leave trigger

scoreboard objectives add teams.join_random trigger
scoreboard objectives add teams.join_alpha trigger
scoreboard objectives add teams.join_beta trigger
scoreboard objectives add teams.join_gamma trigger
scoreboard objectives add teams.join_delta trigger
scoreboard objectives add teams.join_omega trigger
# # # # # # # # # # # # # #

# SCOREBOARD
scoreboard objectives add scb.Teams dummy [{text:" Команды ",color:green,bold:true}]