kill @e[tag=creator_title]
kill @e[tag=stats]