fill -5 32 -92 -10 32 -92 air

setblock ~ ~-1 ~1 red_concrete_powder

schedule function cmd:map/lobby/structures/connect_4/check_red 1s
