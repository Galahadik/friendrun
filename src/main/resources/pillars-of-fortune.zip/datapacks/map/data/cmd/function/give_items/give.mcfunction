execute store result score #items_give_count .temp run scoreboard players get #items_give_count settings

# Звук выдачи предмета
execute as @a at @s if score #giveItems settings matches 1 if data storage minecraft:settings {give_items_on_floor:false} unless score #random_map rng matches 0 unless predicate events:check_on_floor if score @s canGetItems matches 1 run playsound entity.item.pickup ambient @s

execute as @a if score #giveItems settings matches 1 if data storage minecraft:settings {give_items_on_floor:false} if score #random_map rng matches 0 run execute if score @s canGetItems matches 1 at @s run playsound entity.item.pickup ambient @s

execute as @a if score #giveItems settings matches 1 if data storage minecraft:settings {give_items_on_floor:true} run execute if score @s canGetItems matches 1 at @s run playsound entity.item.pickup ambient @s

execute as @a if score #giveItems settings matches 1 run execute if score @s canGetItems matches 1 run scoreboard players operation @s itemsReceived += #items_give_count .temp
execute if score #giveItems settings matches 1 run function cmd:give_items/start