summon text_display ~ ~2.50 ~ {Tags:["lobby","clicker_stats","clicks_count"]}
summon text_display ~-0.175 ~2.25 ~-0.25 {Tags:["lobby","clicker_stats","line_1"]}
summon text_display ~-0.175 ~2.00 ~-0.25 {Tags:["lobby","clicker_stats","line_2"]}
summon text_display ~-0.175 ~1.75 ~-0.25 {Tags:["lobby","clicker_stats","line_3"]}
summon text_display ~-0.175 ~1.50 ~-0.25 {Tags:["lobby","clicker_stats","line_4"]}
summon text_display ~-0.175 ~1.25 ~-0.25 {Tags:["lobby","clicker_stats","line_5"]}
summon text_display ~-0.175 ~1.00 ~-0.25 {Tags:["lobby","clicker_stats","line_6"]}
summon text_display ~-0.175 ~0.75 ~-0.25 {Tags:["lobby","clicker_stats","line_7"]}
summon text_display ~-0.175 ~0.50 ~-0.25 {Tags:["lobby","clicker_stats","line_8"]}
summon text_display ~-0.175 ~0.25 ~-0.25 {Tags:["lobby","clicker_stats","line_9"]}

execute as @e[type=text_display,tag=clicker_stats,tag=!background] run data merge entity @s {background:0,alignment:"left"}
execute as @e[tag=clicker_stats,type=text_display] run data merge entity @s {Rotation:[55.0f,0.0f],shadow:true}