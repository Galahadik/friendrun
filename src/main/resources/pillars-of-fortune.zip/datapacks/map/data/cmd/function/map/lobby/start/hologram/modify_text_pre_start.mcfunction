scoreboard players add $pre_start_holo timer 1

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if score $pre_start_holo timer matches 0..10 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if score $pre_start_holo timer matches 11..20 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры.\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]



execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if score $pre_start_holo timer matches 21..30 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры..\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]



execute if data storage minecraft:settings {gamemodes:{gamemode:default}} if score $pre_start_holo timer matches 31..40 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры...\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"13\n",color:gray}]












execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score $pre_start_holo timer matches 0..10 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]

execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score $pre_start_holo timer matches 11..20 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры.\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]



execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score $pre_start_holo timer matches 21..30 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры..\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]



execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score $pre_start_holo timer matches 31..40 run return run data modify entity @e[limit=1,type=text_display,tag=start_holo] text set value \
["                                        \n\n", \
{text:"Запуск игры...\n",color:gold}, \
{text:"\n\nИгроков ",color:aqua},\
{score:{name:"#players_count",objective:"settings"},color:green},\
{text:"/",color:dark_gray},{text:"30\n",color:gray}]



execute if score $pre_start_holo timer matches 41.. run return run scoreboard players set $pre_start_holo timer 0