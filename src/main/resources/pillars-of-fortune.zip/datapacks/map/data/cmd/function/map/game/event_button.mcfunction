execute unless data storage minecraft:map {event_countdown:false} run return fail

title @a times 0.75s 4s 0.75s

data merge storage minecraft:map {event_countdown:true}
fill 0 59 0 0 60 0 air
execute as @a at @s run playsound minecraft:entity.player.levelup hostile @s ~ ~ ~ 0.2 1.2
function events:random_event
schedule function cmd:map/game/restore_event_button 60s replace

schedule function settings:changes/game/title/reset 6s