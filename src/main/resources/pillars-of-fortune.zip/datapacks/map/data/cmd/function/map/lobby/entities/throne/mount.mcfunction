ride @s mount @e[type=interaction,limit=1,sort=random,tag=throne.seat]
rotate @s facing entity @n[tag=king_seat]
tag @n[type=interaction,tag=throne.seat] remove throne.seat
tag @s add throne.seat

# execute if entity @a[tag=!throne.seat] as @r[tag=!throne.seat] run return run function cmd:map/lobby/entities/throne/mount
execute if entity @a[tag=throne.seat] run return run tag @a remove throne.seat