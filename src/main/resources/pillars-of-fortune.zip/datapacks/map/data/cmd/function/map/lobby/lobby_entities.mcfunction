kill @e[tag=lobby]

## Start
function cmd:map/lobby/start/hologram/respawn
function cmd:map/lobby/clicker/stats/respawn
execute if data storage minecraft:map {clicker:["game_info"]} run function cmd:map/lobby/start/hologram/game_info/respawn
execute if data storage minecraft:map {clicker:["game_info"]} if data storage minecraft:settings {gamemodes:{gamemode:"teams"}} run function cmd:map/lobby/start/hologram/game_info/teams/respawn
execute if data storage minecraft:map {clicker:["game_info"]} unless data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"none"}}} run function cmd:map/lobby/start/hologram/game_info/sub_gamemodes/respawn

## Clicker
summon text_display 18.5 29.0 -104 {Rotation:[0.0f, 20.0f],shadow:1b,Tags:["clicker_hud","lobby"]}

# ## SLIME
execute if data storage minecraft:map {clicker:["slime"]} if data storage minecraft:settings {lobby:{slime:true}} run summon slime 6 27.5 -104 {CustomNameVisible:1b,DeathLootTable:"",Health:1024f,Size:0,Tags:["lobby","lobby_slime"],CustomName:{"bold":true,"color":"green","text":"Слайми"},attributes:[{id:"minecraft:armor",base:30},{id:"minecraft:fall_damage_multiplier",base:0},{id:"minecraft:max_health",base:1024},{id:"minecraft:scale",base:1.65}],PersistenceRequired:true}

# DEATH HOLE
execute if data storage minecraft:map {clicker:["death_hole"]} run summon minecraft:block_display -2.0 22 -95.0 {block_state:{Name:"black_wool"},Tags:["lobby"]}

################### DECORATIONS
# paintings
summon minecraft:painting 3.50 30.00 -111.97 {variant:"minecraft:prairie_ride",Invulnerable:1b,Tags:["lobby","decoration"]}
summon minecraft:painting 5.50 30.00 -111.97 {variant:"minecraft:prairie_ride",Invulnerable:1b,Tags:["lobby","decoration"]}

summon painting 9.50 30.00 -85.03 {variant:"minecraft:wanderer",Invulnerable:1b,facing:2b,Rotation: [180.0f, 0.0f],Tags:["lobby","decoration"]}
summon painting 11.50 30.00 -85.03 {variant:"minecraft:graham",Invulnerable:1b,facing:2b,Rotation: [180.0f, 0.0f],Tags:["lobby","decoration"]}

summon minecraft:painting 15.00 28.00 -79.03 {variant:"minecraft:finding",Invulnerable:1b,facing:2b,Rotation:[180.0f,0.0f],Tags:["lobby","decoration"]}

# books
summon item_display -1.375 28.5625 -103.625 {item:{id:"minecraft:feather"},transformation:{left_rotation:[-0.14180474f,0.23490137f,-0.5477153f,0.79039276f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.7500001f, 0.7500007f, 0.9999998f],translation:[0.0f,0.0f,0.0f]},Tags:["lobby","decoration"]}
summon item_display -1.4375 28.0 -105.4375 {item:{id:"minecraft:writable_book"},transformation:{left_rotation:[-0.61237246f,0.3535534f, 0.3535534f,0.61237246f],right_rotation:[0.0f,0.0f,0.0f,1.0f],scale:[0.7499963f,0.7500032f,0.9999996f],translation:[0.0f,0.0f,0.0f]},Tags:["lobby","decoration"]}

################## USABLE ENTITIES
# seats
function cmd:map/lobby/entities/seats/spawn

# info_lists
summon minecraft:text_display -2.0 30.75 -105.0 {text:[{text:"\n Список событий ",color:gold},{text:"\n(Тык)\n",color:gray}],shadow:true,Rotation:[-90.0f,2.0f],Tags:["lobby","info_list"]}
summon interaction -2.5 30.75 -105.0 {response:true,width:1.35,height:0.65,Tags:["lobby","info_list","events_list"]}

summon minecraft:text_display -2.0 30.125 -103.775 {text:[{text:"\n Список платформ ",color:gold},{text:"\n(Тык)\n",color:gray}],shadow:true,Rotation:[-90.0f,2.0f],Tags:["lobby","info_list"]}
summon interaction -2.35 30.125 -103.775 {response:true,width:1.05,height:0.65,Tags:["lobby","info_list","maps_list"]}

summon minecraft:text_display -2.0 29.0 -104.75 {text:[{text:"\n Список модификаторов ",color:gold},{text:"\n(Тык)\n",color:gray}],shadow:true,Rotation:[-90.0f,2.0f],Tags:["lobby","info_list"]}
summon interaction -2.75 29.0 -104.75 {response:true,width:1.85,height:0.65,Tags:["lobby","info_list","modificators_list"]}

summon minecraft:text_display -1.375 28.0625 -105.375 {Rotation:[-50.0f,-90.0f],Tags:["lobby"],background:0,shadow:true,text:{text:"Тык",color:green}}
summon interaction -1.4375 27.95 -105.4375 {width:0.75,height:0.15,response:true,Tags:["lobby","info_list","game_features"]}


execute as @e[tag=info_list,type=text_display] run data modify entity @s transformation.scale set value [0.65f,0.65f,0.65f]


################### DISABLE USAGE
# Door
summon minecraft:interaction -3.5 27.95 -98.5 {height:3.1,width:1.1,Tags:["lobby","usage_disabler"]}

summon minecraft:mannequin 20.8 35.5 -99 {profile:"MrRaven___",Invulnerable:true,immovable:true,CustomName:{text:"Создатель карты",color:yellow},description:{text:"MrRaven___",color:gold},CustomNameVisible:true,Rotation:[90.0f,20.0f],pose:"crouching",Tags:["lobby"]}