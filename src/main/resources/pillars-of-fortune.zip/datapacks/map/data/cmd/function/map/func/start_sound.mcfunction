execute as @a at @s run playsound minecraft:item.goat_horn.sound.1 hostile @s ~ ~ ~ 100
worldborder set 50