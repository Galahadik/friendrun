# Players
# execute if entity @a[tag=dev_mode] run scoreboard players set #players_count settings 5

execute unless entity @a[tag=dev_mode] store result score #players_count settings if entity @a
execute unless entity @a[tag=dev_mode] store result score #players_count.alive settings if entity @a[tag=alive]


execute as @e[type=fireball] unless predicate events:check_in_game_zone_all run kill @s
execute as @e[type=tnt] unless predicate events:check_in_game_zone_all run kill @s
execute as @e[type=end_crystal] unless predicate events:check_in_game_zone_all run kill @s

# scoreboard players set #players_count settings 2

# Функции если игра не запущена
execute if data storage minecraft:map {game_running:false} run function cmd:map/lobby/lobby_func

# Функции если игра запущена
execute if data storage minecraft:map {game_running:true} run function cmd:map/game/running/running

scoreboard players enable @a[tag=Mod] panel.trigger
scoreboard players enable @a[tag=Admin] panel.trigger

execute as @a[scores={panel.trigger=1..}] run function admin:panel/show_panel

execute as @a[tag=!inited] run function cmd:map/player/init

# info_book
execute as @a unless score @s info matches 0.. run scoreboard players enable @a info
execute as @a[scores={info=1..}] run function items:lobby/info/map_info