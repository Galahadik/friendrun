execute if entity @a[name=Lololowka] unless data storage map {lololowka_event:true} run function cmd:map/lobby/lololowka_event/start


scoreboard players add &lobby_clicker2 settings 1

execute unless score &lobby_clicker settings = &lobby_clicker2 settings run tellraw @a ["<",{text:"Столбы",color:gray},"> ",{text:"Обнаружена попытка накрутки кликера! -1000 Кликов",color:red}]
execute unless score &lobby_clicker settings = &lobby_clicker2 settings run execute as @a at @s run playsound entity.villager.no hostile @s ~ ~ ~ 0.75
execute unless score &lobby_clicker settings = &lobby_clicker2 settings run scoreboard players remove &lobby_clicker2 settings 1000
execute unless score &lobby_clicker settings = &lobby_clicker2 settings run return run scoreboard players operation &lobby_clicker settings = &lobby_clicker2 settings