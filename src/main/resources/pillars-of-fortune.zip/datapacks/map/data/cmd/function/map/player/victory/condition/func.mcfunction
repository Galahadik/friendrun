schedule clear cmd:map/func/stop

execute if score #players_count.alive settings matches ..0 run return run function cmd:map/player/victory/nobody_won

execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run return run function cmd:map/player/victory/victory