scoreboard players add $teleport timer 1

tp @a[tag=teleported1] @e[tag=Teleport1,limit=1]
tp @a[tag=teleported2] @e[tag=Teleport2,limit=1]
tp @a[tag=teleported3] @e[tag=Teleport3,limit=1]
tp @a[tag=teleported4] @e[tag=Teleport4,limit=1]
tp @a[tag=teleported5] @e[tag=Teleport5,limit=1]


execute if score $teleport timer matches ..99 run schedule function cmd:map/teleportation/team/teleport 1t