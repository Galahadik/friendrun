scoreboard players remove $lobby_time_before_start timer 1

execute if score $lobby_time_before_start timer matches ..0 run return fail
schedule function cmd:map/lobby/start/check_conditions/countdown_before_start 1s