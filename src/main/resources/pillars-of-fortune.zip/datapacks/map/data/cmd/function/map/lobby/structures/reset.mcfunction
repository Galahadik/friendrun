execute if data storage minecraft:map {clicker:["mob_arena"]} run function cmd:map/lobby/structures/mob_arena/setup
# execute if data storage minecraft:map {clicker:["connect_4"]} run function cmd:map/lobby/structures/connect_4/reset
execute if data storage minecraft:map {clicker:["bar"]} run function cmd:map/lobby/structures/bar/reset