tellraw @s ["<",{text:"Столбы",color:gray},"> ",{text:"Вы не можете запустить игру. Недостаточно прав!",color:red}]
execute at @s run playsound entity.villager.no hostile @s ~ ~ ~ 0.75