# CREATE TELEPORT ARMOR STAND

summon minecraft:text_display -16 40 0 {Rotation:[-90f,0f],Tags:["Teleport1"]}
summon minecraft:text_display 16 40 0 {Rotation:[90f,0f],Tags:["Teleport2"]}

execute if score #teams.teams_count settings matches 3.. run summon minecraft:text_display 0 40 -16 {Rotation:[0f,0f],Tags:["Teleport3"]}
execute if score #teams.teams_count settings matches 4.. run summon minecraft:text_display 0 40 16 {Rotation:[-180f,0f],Tags:["Teleport4"]}
execute if score #teams.teams_count settings matches 5.. run summon minecraft:text_display 0 40 0 {Rotation:[0f,0f],Tags:["Teleport5"]}