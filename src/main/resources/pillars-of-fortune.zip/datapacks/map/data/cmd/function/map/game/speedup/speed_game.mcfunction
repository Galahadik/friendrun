data merge storage minecraft:map {speedup_game:true}

title @a title [{text:"Осталось ",color:yellow},{text:"2",bold:true}," игрока."]
title @a subtitle {text:"Игра ускоряется!",color:gold}
execute as @a at @s run playsound minecraft:block.bell.resonate master @s ~ ~ ~

schedule clear cmd:map/deathmatch/time_to_match

execute store result storage minecraft:temp game.worldborder_size int 1 run worldborder get
function cmd:map/deathmatch/worldborder_set with storage minecraft:temp game

execute unless data storage minecraft:map {modificators:{modificators:["faster_border"]}} run schedule function cmd:map/deathmatch/time_to_match 100s
execute unless data storage minecraft:map {modificators:{modificators:["faster_border"]}} run return run worldborder set 1 120s

execute if data storage minecraft:map {modificators:{modificators:["faster_border"]}} run schedule function cmd:map/deathmatch/time_to_match 75s
execute if data storage minecraft:map {modificators:{modificators:["faster_border"]}} run return run worldborder set 1 90s


execute if data storage minecraft:map {deathmatch_running:true} run say 1