execute at @e[type=mannequin,tag=lololowka_event] run particle minecraft:large_smoke ~ ~1 ~ 0 0 0 0.25 100
execute as @e[type=mannequin,tag=lololowka_event] at @s run tp @s ~ ~20 ~
execute as @a at @s run playsound minecraft:block.fire.extinguish master @s ~ ~ ~ 0.35 0.85


setblock 18 28 -103 minecraft:lever[facing=south]


schedule clear cmd:map/lobby/lololowka_event/loop

data merge storage minecraft:map {lololowka_event:true}

kill @e[type=mannequin,tag=lololowka_event]