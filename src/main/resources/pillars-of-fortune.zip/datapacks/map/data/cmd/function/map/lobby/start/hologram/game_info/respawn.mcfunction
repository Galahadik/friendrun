kill @e[tag=game_info_holo]

summon minecraft:text_display 19 28 -95 {\
Tags:["lobby","game_info_holo","background"], \
text:[{text:"               Настройки               ",color:gold},"\n",\
[{text:"  1. ",color:dark_gray},{text:"Игра",color:gold},\
[{text:"",color:yellow}, \
"\n   Режим:\n   Набор:\n   Показ невидимок:\n   Горение Монстров:\n", \
{text:"  2. ",color:dark_gray},{text:"Предметы",color:gold},\
"\n   Предмет раз в:\n   Получаемых предметов:\n   Получ. предметов внизу:\n",\
{text:"  3. ",color:dark_gray},{text:"Другое",color:gold},\
"\n   События:\n   Модификаторы:\n   Платформы:\n"]]]}

execute at @e[type=text_display,tag=game_info_holo,tag=background] run function cmd:map/lobby/start/hologram/game_info/respawn_lines