spawnpoint @a 10 27 -99
gamemode adventure @a
effect clear @a
clear @a
scoreboard players reset * kills_stat.temp
effect give @a minecraft:regeneration 3 255 true
tp @a 10 27 -99
