gamerule max_block_modifications 537500
gamerule command_block_output false
gamerule advance_time false
gamerule advance_weather false
gamerule fire_spread_radius_around_player 0
gamerule allow_entering_nether_using_portals false


gamerule random_tick_speed 250
gamerule immediate_respawn true
gamerule universal_anger true
gamerule respawn_radius 0