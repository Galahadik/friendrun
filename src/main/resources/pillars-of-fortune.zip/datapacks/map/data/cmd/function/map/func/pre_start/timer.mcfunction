scoreboard players remove $pre_start timer 1

execute if score $pre_start timer matches ..3 run title @a title ""
execute if score $pre_start timer matches ..3 run title @a subtitle {score:{name:"$pre_start",objective:timer},color:red}

execute if score $pre_start timer matches ..3 as @a at @s run playsound minecraft:entity.experience_orb.pickup hostile @s ~ ~ ~ 0.85

execute if score $pre_start timer matches 1.. run return run schedule function cmd:map/func/pre_start/timer 1s
execute if score $pre_start timer matches ..0 run title @a reset
execute if score $pre_start timer matches ..0 run return run function cmd:map/func/start