
scoreboard players set #items_give_timer settings 100
scoreboard players set #items_give_timer.sec settings 5
scoreboard players set #items_give_count settings 1
scoreboard players set #items_give_timer settings 100
scoreboard players set #items_give_timer.sec settings 5
scoreboard players set #teams.teams_count settings 1

scoreboard players set &lobby_clicker settings 0
scoreboard players set &lobby_clicker2 settings 0

time set 6000
weather clear

defaultgamemode spectator

forceload add -25 -25 25 25
forceload add -28 -110 30 -72

# KITS
fill 4 21 -89 0 21 -87 minecraft:yellow_shulker_box{Items:[],lock:{items:[]}}
fill 0 23 -89 4 23 -87 minecraft:orange_shulker_box[facing=down]{Items:[],lock:{items:[]}}

data merge storage minecraft:settings {gamemodes:{gamemode:"default",params:{assign_teams_method:"choice"}, \
                                        sub_gamemodes:{gamemode:"none",params:{bridges:{structure:["plus"]}}}}}
data merge storage minecraft:settings {give_items_on_floor:false}
data merge storage minecraft:settings {show_invisibles:false}
data merge storage minecraft:settings {kits:{enable:false,kit:1}}
data merge storage minecraft:settings {mobs:{burning:false,teleport_to_deathmatch:true}}

data merge storage minecraft:settings {maps:{enable:true,empty_maps:true}}
data merge storage minecraft:settings {modificators:{enable:true,sun_burning_modificator:true}}
data merge storage minecraft:settings {events:{enable:true,activation_method:"button",who_got_op_sword:false,sun_burning_event:true}}
data merge storage minecraft:settings {lobby:{pvp:true,perm_to_start:false,slime:true}}


data merge storage map {first_load:true} 