summon minecraft:text_display ~-1 ~3.00 ~.45 {\
Tags:["lobby","game_info_holo","line_1"]}
summon minecraft:text_display ~-1 ~2.75 ~.45 {\
Tags:["lobby","game_info_holo","line_2"]}
summon minecraft:text_display ~-1 ~2.50 ~.45 {\
Tags:["lobby","game_info_holo","line_3"]}
summon minecraft:text_display ~-1 ~2.25 ~.45 {\
Tags:["lobby","game_info_holo","line_4"]}
summon minecraft:text_display ~-1 ~1.75 ~.45 {\
Tags:["lobby","game_info_holo","line_5"]}
summon minecraft:text_display ~-1 ~1.50 ~.45 {\
Tags:["lobby","game_info_holo","line_6"]}
summon minecraft:text_display ~-1 ~1.25 ~.45 {\
Tags:["lobby","game_info_holo","line_7"]}
summon minecraft:text_display ~-1 ~0.75 ~.45 {\
Tags:["lobby","game_info_holo","line_8"]}
summon minecraft:text_display ~-1 ~0.50 ~.45 {\
Tags:["lobby","game_info_holo","line_9"]}
summon minecraft:text_display ~-1 ~0.25 ~.45 {\
Tags:["lobby","game_info_holo","line_10"]}

execute as @e[type=text_display,tag=game_info_holo,tag=!background] run data merge entity @s {background:0}
execute as @e[type=text_display,tag=game_info_holo] run data merge entity @s {Rotation:[155.0f, 0.0f],shadow:true,alignment:left}