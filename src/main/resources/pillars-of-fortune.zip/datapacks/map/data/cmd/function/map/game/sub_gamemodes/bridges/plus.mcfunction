fill -17 37 -1 17 39 1 minecraft:bedrock

execute if score #teams.teams_count settings matches 3.. run fill -1 37 -17 1 39 1 minecraft:bedrock
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} if score #teams.teams_count settings matches 4.. run return run fill -1 37 17 1 39 1 minecraft:bedrock


execute if score #players_count.old settings matches 3.. run fill -1 37 -17 1 39 1 minecraft:bedrock
execute if score #players_count.old settings matches 4.. run fill -1 37 17 1 39 1 minecraft:bedrock