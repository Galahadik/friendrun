team add Random {text:"Случайная",color:gold}
team modify Random color gold

team add Alpha {text:"Альфа",color:blue}
team modify Alpha color blue
team modify Alpha collisionRule pushOwnTeam
team modify Alpha friendlyFire false

team add Beta {text:"Бета",color:red}
team modify Beta color red
team modify Beta collisionRule pushOwnTeam
team modify Beta friendlyFire false

team add Gamma {text:"Гамма",color:green}
team modify Gamma color green
team modify Gamma collisionRule pushOwnTeam
team modify Gamma friendlyFire false

team add Delta {text:"Дельта",color:yellow}
team modify Delta color yellow
team modify Delta collisionRule pushOwnTeam
team modify Delta friendlyFire false

team add Omega {text:"Омега",color:light_purple}
team modify Omega color light_purple
team modify Omega collisionRule pushOwnTeam
team modify Omega friendlyFire false

team add lobby
team modify lobby color gray
team modify lobby collisionRule never

team add player
team modify player color green
team modify player suffix {"text":" ❤","color":"dark_green"}

team add death
team modify death color red
team modify death suffix {"text":" ☠","color":"dark_red"}

team add none