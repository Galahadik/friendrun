function cmd:map/player/victory/funcs

scoreboard players add @a[tag=alive] wins 1
scoreboard players add @a[tag=!alive,tag=!dev_mode] losses 1
title @a[tag=alive] title [{text:"Поздравляем вас с победой!",color:green}]
title @a[tag=alive] subtitle [{text:"Вы победили уже ",color:green},{score:{name:"@a[tag=alive,limit=1]",objective:"wins"},color:red},{text:" раз(а)",color:green}]
title @a[tag=!alive] title [{text:"Поражение!",color:red}]
title @a[tag=!alive] subtitle [{text:"Победитель",color:green},{text:" >> ",color:gray,bold:true},{selector:"@a[tag=alive]",color:gold}]

team join lobby @a[tag=alive]
tellraw @a ["<",{text:"Столбы",color:gray},"> ",[{text:"Игрок ",color:green},{selector:"@a[tag=alive]",color:gold}," ",{score:{name:"@a[tag=alive]",objective:"Health"},color:red,bold:true},{text:"❤",color:red}," победил уже ",{text:"- ",color:gray,bold:true},{score:{name:"@a[tag=alive]",objective:"wins"},color:yellow,bold:true}," раз! ",[{text:"(x",color:yellow},{score:{name:"@a[tag=alive]",objective:wins_streak}},")"]]]
team join player @a[tag=alive]

execute as @a[tag=alive] at @s run playsound minecraft:ui.toast.challenge_complete ambient @s ~ ~ ~ 0.1 1.8
tp @a[tag=!alive,gamemode=spectator,tag=!dev_mode] @r[tag=alive,sort=random]

tag @r[tag=alive] add winner



effect give @a[tag=alive] minecraft:resistance 10 255 true

schedule function cmd:map/func/stop 10s