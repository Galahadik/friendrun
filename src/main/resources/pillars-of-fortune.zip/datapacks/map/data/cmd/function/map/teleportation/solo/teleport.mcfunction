scoreboard players add $teleport timer 1

execute if score #players_count settings matches 1.. run tp @a[tag=teleported1] @e[tag=Teleport1,limit=1]
execute if score #players_count settings matches 2.. run tp @a[tag=teleported2] @e[tag=Teleport2,limit=1]
execute if score #players_count settings matches 3.. run tp @a[tag=teleported3] @e[tag=Teleport3,limit=1]
execute if score #players_count settings matches 4.. run tp @a[tag=teleported4] @e[tag=Teleport4,limit=1]
execute if score #players_count settings matches 5.. run tp @a[tag=teleported5] @e[tag=Teleport5,limit=1]
execute if score #players_count settings matches 6.. run tp @a[tag=teleported6] @e[tag=Teleport6,limit=1]
execute if score #players_count settings matches 7.. run tp @a[tag=teleported7] @e[tag=Teleport7,limit=1]
execute if score #players_count settings matches 8.. run tp @a[tag=teleported8] @e[tag=Teleport8,limit=1]
execute if score #players_count settings matches 9.. run tp @a[tag=teleported9] @e[tag=Teleport9,limit=1]
execute if score #players_count settings matches 10.. run tp @a[tag=teleported10] @e[tag=Teleport10,limit=1]
execute if score #players_count settings matches 11.. run tp @a[tag=teleported11] @e[tag=Teleport11,limit=1]
execute if score #players_count settings matches 12.. run tp @a[tag=teleported12] @e[tag=Teleport12,limit=1]
execute if score #players_count settings matches 13.. run tp @a[tag=teleported13] @e[tag=Teleport13,limit=1]


execute if score $teleport timer matches ..99 run schedule function cmd:map/teleportation/solo/teleport 1t