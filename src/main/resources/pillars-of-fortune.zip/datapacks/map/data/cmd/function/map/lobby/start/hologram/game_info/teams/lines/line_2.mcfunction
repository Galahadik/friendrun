execute if data storage settings {gamemodes:{params:{assign_teams_method:"random"}}} run return run data modify entity @s text set value {text:" Случайный",color:aqua}

execute if data storage settings {gamemodes:{params:{assign_teams_method:"choice"}}} run return run data modify entity @s text set value {text:"       Выбор",color:aqua}