title @a[tag=!alive] title ""
title @a[tag=alive] title {"text":"СУПЕР МЕДЛИТЕ!","color":"red"}
title @a subtitle {"text":"Через 15 секунд граница удалиться","color":"gold"}
execute as @a at @s run playsound minecraft:entity.wither.ambient ambient @s ~ ~ ~ 0.25 2

schedule function cmd:map/deathmatch/worldbarrier_move 15s