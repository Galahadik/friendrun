execute at @s run playsound minecraft:entity.villager.no hostile @s ~ ~ ~ 0.85

function cmd:map/lobby/start/check_conditions/countdown_before_start

return run tellraw @s ["<",{text:"Столбы",color:gray},"> ",{text:"Подождите перед запуском игры",color:red}]
