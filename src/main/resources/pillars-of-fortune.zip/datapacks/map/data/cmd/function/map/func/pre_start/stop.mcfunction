execute unless data storage minecraft:map {pre_start:true} run return fail

schedule clear cmd:map/func/start
schedule clear cmd:map/func/pre_start/timer

tellraw @a ["<",{text:"Столбы",color:gray},"> ",{selector:"@s",color:blue},{text:" — Остановил предварительный отсчёт",color:red}]
scoreboard players reset @a stop_pre_start.trigger

function cmd:map/stats/kill

data merge storage minecraft:map {pre_start:false}

scoreboard players set $lobby_time_before_start timer 6
function cmd:map/lobby/start/check_conditions/countdown_before_start

function admin:panel/show_panel

scoreboard players enable @a[tag=Admin] force_start.trigger
scoreboard players enable @a[tag=Mod] force_start.trigger