tellraw @a ["",{text:"<",color:gray},{text:"MrRaven___",color:gold},{text:"> ",color:gray},{text:"Здравствуйте, достопочтенный Роман. Я рад, что такой известный ютубер, как вы, посетил мою карту."}]

playsound minecraft:entity.villager.ambient master @a 18 28 -103 100

schedule function cmd:map/lobby/lololowka_event/2 7s