execute if score #players_count settings matches 1.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported1

execute if score #players_count settings matches 2.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported2

execute if score #players_count settings matches 3.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported3

execute if score #players_count settings matches 4.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported4

execute if score #players_count settings matches 5.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported5

execute if score #players_count settings matches 6.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported6

execute if score #players_count settings matches 7.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported7

execute if score #players_count settings matches 8.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported8

execute if score #players_count settings matches 9.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported9

execute if score #players_count settings matches 10.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported10

execute if score #players_count settings matches 11.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported11

execute if score #players_count settings matches 12.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported12

execute if score #players_count settings matches 13.. run execute as @a[tag=!teleported1,tag=!teleported2,tag=!teleported3,tag=!teleported4,tag=!teleported5,tag=!teleported6,tag=!teleported7,tag=!teleported8,tag=!teleported9,tag=!teleported10,tag=!teleported11,tag=!teleported12,tag=!teleported13,limit=1,sort=random] at @s run tag @s add teleported13