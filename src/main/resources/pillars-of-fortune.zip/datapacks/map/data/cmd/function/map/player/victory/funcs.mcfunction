scoreboard players add @a[tag=alive] wins_streak 1


execute as @a[tag=!alive,scores={wins_streak=1..}] run tellraw @s ["<",{text:"Столбы",color:gold},"> ",{text:"Вы потеряли серию побед! Ваш результат: ",color:red},{score:{name:"@s",objective:"wins_streak"},color:dark_red}]
scoreboard players reset @a[tag=!alive] wins_streak

data merge storage minecraft:map {victory:true}
data merge storage minecraft:map {events:{sun_damage:false}}