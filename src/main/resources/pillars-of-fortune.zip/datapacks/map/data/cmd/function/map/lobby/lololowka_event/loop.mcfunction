execute as @e[type=mannequin,tag=lololowka_event] at @s run tp @s ~ ~ ~ facing entity @p

setblock 18 28 -103 air destroy

execute unless data storage map {lololowka_event:true} run schedule function cmd:map/lobby/lololowka_event/loop 1t