kill @e[tag=game_info_teams_holo]

execute at @e[type=text_display,tag=game_info_holo,tag=background] run summon minecraft:text_display ~ ~4.00 ~ {Tags:["lobby","game_info_teams_holo","background"],text:\
[{text:"        Командный режим        ",color:gold},"\n",\
[{text:"",color:yellow},"\n   Кол-во команд:\n   Метод выбора:\n"]]}

# summon minecraft:text_display 15 30 -94 {Tags:["lobby","game_info_teams_holo","background"],text:\
# [{text:"        Настройки Режима        ",color:gold},"\n",\
# {text:"  1. ",color:dark_gray},{text:"Режим",color:gold},\
# [{text:"",color:yellow},"\n   Подрежим:\n   Кол-во команд:\n   Выбор команд:\n",{text:"  2. ",color:dark_gray},\
# {text:"Подрежим",color:gold},\
# "\n   Форма мостов:\n"]]}

execute at @e[type=text_display,tag=game_info_teams_holo,tag=background] run function cmd:map/lobby/start/hologram/game_info/teams/respawn_lines