team modify Alpha friendlyFire false
team modify Beta friendlyFire false
team modify Gamma friendlyFire false
team modify Delta friendlyFire false
team modify Omega friendlyFire false