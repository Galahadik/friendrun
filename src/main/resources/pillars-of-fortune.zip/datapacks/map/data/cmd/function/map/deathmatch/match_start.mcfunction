fill -25 101 24 24 101 -25 smooth_stone
playsound minecraft:entity.wither.death ambient @a 0 60 0 100000 2
worldborder set 50

execute unless data storage minecraft:map {modificators:{modificators:["faster_border"]}} if data storage minecraft:map {speedup_game:false} run worldborder set 1 210s
execute unless data storage minecraft:map {modificators:{modificators:["faster_border"]}} if data storage minecraft:map {speedup_game:true} run worldborder set 1 105s

execute if data storage minecraft:map {modificators:{modificators:["faster_border"]}} if data storage minecraft:map {speedup_game:false} run worldborder set 1 105s
execute if data storage minecraft:map {modificators:{modificators:["faster_border"]}} if data storage minecraft:map {speedup_game:true} run worldborder set 1 63s

fill 24 102 24 -25 149 24 minecraft:barrier
fill -25 149 24 -25 102 -25 minecraft:barrier
fill -25 102 -25 24 149 -25 minecraft:barrier
fill 24 149 -25 24 102 24 minecraft:barrier

execute if data storage settings {mobs:{teleport_to_deathmatch:true}} run spreadplayers 0.0 0.0 0 25 under 110 false @e[type=!player,tag=!player]
execute if data storage minecraft:settings {gamemodes:{gamemode:"default"}} run spreadplayers 0.0 0.0 5 25 under 110 false @a
execute if data storage minecraft:settings {gamemodes:{gamemode:"teams"}} run spreadplayers 0.0 0.0 5 25 under 110 true @a

fill 24 150 -25 -25 150 24 minecraft:barrier
execute unless data storage minecraft:map {modificators:{modificators:["no_fall_damage"]}} run schedule function settings:changes/game/fall_damage/enable 1s

execute if data storage minecraft:map {speedup_game:false} run schedule function cmd:map/deathmatch/lava 120s
execute if data storage minecraft:map {speedup_game:true} run schedule function cmd:map/deathmatch/lava 45s
execute if data storage minecraft:map {modificators:{modificators:["faster_border"]}} run schedule function cmd:map/deathmatch/lava 45s

execute if data storage minecraft:map {speedup_game:false} run schedule function cmd:map/deathmatch/worldbarrier_move_warn 175s
execute if data storage minecraft:map {speedup_game:true} run schedule function cmd:map/deathmatch/worldbarrier_move_warn 90s
execute if data storage minecraft:map {modificators:{modificators:["faster_border"]}} run schedule function cmd:map/deathmatch/worldbarrier_move_warn 90s

data merge storage minecraft:map {deathmatch_running:true}

data modify storage minecraft:map events.sun_damage set value false