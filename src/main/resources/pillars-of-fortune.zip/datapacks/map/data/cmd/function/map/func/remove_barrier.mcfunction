fill -25 42 24 24 42 -25 air

effect give @a minecraft:regeneration 3 255 true
effect give @a minecraft:saturation 3 255 true

effect clear @a minecraft:invisibility
execute if data storage minecraft:settings {gamemodes:{gamemode:default}} run function cmd:map/func/particles

gamerule fire_spread_radius_around_player 100
gamerule pvp true
gamerule mob_griefing true
gamerule tnt_explodes true


worldborder set 1 475s
worldborder center 0.0 0.0
worldborder damage amount 0.25

execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"deathmatches"}}} run schedule function events:event/14_force_deathmatch/start 1s
execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"platforms"}}} run function cmd:map/game/sub_gamemodes/platforms/setup
execute if data storage minecraft:settings {gamemodes:{sub_gamemodes:{gamemode:"bridges"}}} run function cmd:map/game/sub_gamemodes/bridges/setup

tellraw @a ["<",{text:"Столбы",color:gold},"> ",{text:"Справочник по механикам: ",color:green},{text:"/trigger info",color:yellow}]

kill @e[type=text_display,tag=Teleport]
function settings:changes/game/fall_damage/enable


execute as @a[tag=alive] run function settings:kits/load


function cmd:map/stats/kill
function cmd:give_items/unpause_giving

########
execute as @a[tag=Mod] run function admin:panel/game_panel
execute as @a[tag=Admin] run function admin:panel/game_panel

scoreboard players enable @a[tag=Mod] force_stop.trigger

scoreboard players enable @a[tag=Admin] force_stop.trigger
########

data merge storage map {remove_barrier:true}
execute if data storage minecraft:settings {gamemodes:{gamemode:teams}} run function cmd:map/func/team/remove_barrier

title @a[tag=alive] title ""
title @a[tag=alive] subtitle {text:"УДАЧИ!",color:dark_red,bold:true}

execute if data storage minecraft:settings {modificators:{enable:true}} run function modificators:random_modificator