fill -17 37 -17 -15 39 17 minecraft:bedrock

fill -17 37 15 17 39 17 minecraft:bedrock

fill 15 37 17 17 39 -17 minecraft:bedrock

fill 17 37 -15 -17 39 -17 minecraft:bedrock